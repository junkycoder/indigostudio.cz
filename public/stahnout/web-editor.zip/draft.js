/* Úložiště rozšíření komunikuje s jádrem jen uvnitř izolovaného světa. */

(() => {
  "use strict";

  const events = window.WeedCore.events ||= new EventTarget();

  const store = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
  if (!store) return;

  // Seznam patří webu, ne stránce a ne originu: `admin.x.cz` a `www.x.cz` jsou
  // jeden projekt (SPEC §0) a zadání z obou odchází v jednom balíčku.
  const KEY = `draft:${window.WeedCore.project(location.hostname, location.port)}`;

  // Uložení a čtení jdou za sebou — čtení nesmí předběhnout zápis, který přišel dřív.
  let chain = Promise.resolve();

  events.addEventListener("weed:draft:set", (e) => {
    let d;
    try { d = JSON.parse(e.detail); } catch (_) { return; }
    if (!d || typeof d !== "object") return;
    const list = Array.isArray(d.list) ? d.list : [];
    // Volba rychlosti (SPEC §4.6) patří webu stejně jako seznam, a příkaz změřit
    // musí přežít načtení, které si vyžádal — jinak se po reloadu ztratí.
    const keep = !!d.open || list.length > 0 || !!d.network || !!d.measure;
    chain = chain.then(() => (!keep
      ? store.remove(KEY)
      : store.set({ [KEY]: { open: !!d.open, list, network: !!d.network, measure: !!d.measure, at: Date.now() } }))).catch(() => {});
  });

  events.addEventListener("weed:draft:get", () => {
    chain = chain.then(async () => {
      const v = await store.get(KEY);
      events.dispatchEvent(new CustomEvent("weed:draft", { detail: JSON.stringify(v[KEY] || {}) }));
    }).catch(() => {});
  });
})();
