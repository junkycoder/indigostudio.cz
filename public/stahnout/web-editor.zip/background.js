/* Obal rozšíření: zkratka, ikona, nabídka a cesta seznamu na Worker. */

importScripts("capture.js", "connection.js");

/* Do stránek prohlížeče a do storu se skript vložit nedá. Klepnutí na ikonu
 * tam není chyba, jen se nic nestane — jádro na takové stránce neběží. */
const INJECTABLE = /^(https?|file):/;

async function toggleIn(tab) {
  if (!tab?.id || !INJECTABLE.test(tab.url || "")) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "ISOLATED",
      func: () => window.weed && window.weed.toggle(),
    });
  } catch (_) { /* stránka vložení odmítla */ }
}

chrome.action.onClicked.addListener(toggleIn);

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "toggle-palette") return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  toggleIn(tab);
});

/* Zrcadlení seznamu do vzdáleného Weed MCP (SPEC §9).
 *
 * Fetch dělá background, ne obsahový skript: z karty by šel na cizí původ
 * a odpověď by se nedala přečíst. Vypnuté napojení mlčí — nevrací chybu,
 * protože se nic nepokazilo (§11, výchozí stav je vypnuto).
 */
chrome.runtime.onMessage.addListener((message, _sender, reply) => {
  if (!message || message.type !== "weed:sync") return;
  (async () => {
    const conn = await Connection.read();
    if (!conn.on || !conn.endpoint || !conn.key) return reply({ ok: false, off: true });
    try {
      const res = await fetch(`${conn.endpoint.replace(/\/+$/, "")}/s/${conn.key}/list`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(message.payload),
      });
      // Adresa jde zpátky do stránky, aby ji jádro mohlo přibalit k balíčku
      // (§2.9): agent, kterému prompt někdo vloží ručně, se podle ní připojí
      // a odškrtne. Posílá se až po potvrzení — neodeslaný seznam by lhal.
      const mcp = `${conn.endpoint.replace(/\/+$/, "")}/s/${conn.key}/mcp`;
      reply(res.ok ? { ok: true, mcp } : { ok: false, error: `Worker odpověděl ${res.status}` });
    } catch (error) {
      // Nedostupný Worker není chyba zadání: seznam zůstal v zařízení a jde
      // do schránky jako vždycky. Pošle se příště.
      reply({ ok: false, error: error.message });
    }
  })();
  return true;
});

/* Odvolání souhlasu (SPEC §11). Vypnutý přepínač neznamená jen „dál se
 * neodesílá", ale i „co tam leží, se smaže" — souhlas, který jde přestat
 * dávat, ale ne vzít zpátky, není souhlas. Maže se adresou a klíčem, které
 * ještě platí, takže se volá dřív, než se přepínač uloží.
 *
 * Nedostupný Worker vypnutí neblokuje: uživatel, který chce přestat
 * odesílat, by zůstal rukojmím adresy, která nemusí odpovědět nikdy.
 * Nesplněné mazání se proto uloží jako úkol a zkusí znovu, kdykoliv
 * rozšíření nastartuje. Poslední záchranou je lhůta na Workeru (týden),
 * když se to nepovede ani potom — třeba proto, že rozšíření mezitím
 * někdo odinstaloval.
 */
const FORGET = "forget";

async function forgetAt(endpoint, key) {
  const res = await fetch(`${endpoint.replace(/\/+$/, "")}/s/${key}/list`, { method: "DELETE" });
  if (!res.ok) throw new Error(`Worker odpověděl ${res.status}`);
}

/* Úkol drží vlastní adresu a klíč, ne ty aktuální: mezitím si uživatel mohl
   nechat vygenerovat nový klíč a starý seznam by pak zůstal ležet bez toho,
   že by se k němu kdokoliv dostal. */
async function forgetPending() {
  const task = (await chrome.storage.local.get(FORGET))[FORGET];
  if (!task || !task.endpoint || !task.key) return false;
  try {
    await forgetAt(task.endpoint, task.key);
    await chrome.storage.local.remove(FORGET);
    return true;
  } catch (_) {
    return false;   // zkusí se při příštím startu
  }
}

chrome.runtime.onStartup.addListener(forgetPending);
forgetPending();

chrome.runtime.onMessage.addListener((message, _sender, reply) => {
  if (!message || message.type !== "weed:forget") return;
  (async () => {
    const conn = await Connection.read();
    if (!conn.endpoint || !conn.key) return reply({ ok: true, nothing: true });
    try {
      await forgetAt(conn.endpoint, conn.key);
      await chrome.storage.local.remove(FORGET);
      reply({ ok: true });
    } catch (error) {
      await chrome.storage.local.set({ [FORGET]: { endpoint: conn.endpoint, key: conn.key, since: Date.now() } });
      reply({ ok: false, queued: true, error: error.message });
    }
  })();
  return true;
});

/*
 * Vlastní položky v nabídce prohlížeče. Nad označeným textem i nad odkazem je
 * nabídka nativní věc prohlížeče a Weed do ní nesahá — jen si do ní přidá, co
 * s tím, na co se ukázalo, jde udělat: cíl se vybere a otevře se zadání (SPEC §2.1).
 */
const MENU = {
  "weed-quote": { title: "Web Editor — zadání k označenému textu", contexts: ["selection"] },
  "weed-link": { title: "Web Editor — zadání k odkazu", contexts: ["link"] },
};

chrome.runtime.onInstalled.addListener(() => {
  for (const [id, item] of Object.entries(MENU)) {
    chrome.contextMenus.create({ id, ...item }, () => void chrome.runtime.lastError);
  }
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!MENU[info.menuItemId] || !tab?.id) return;
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "ISOLATED",
    args: [{ id: info.menuItemId, href: info.linkUrl || "" }],
    func: (c) => {
      if (!window.weed) return;
      // Bez cíle se paleta neotevírá: výběr mezitím zmizel, nebo odkaz na stránce
      // není — otevřít prázdný řádek by bylo horší než neudělat nic.
      const picked = c.id === "weed-link" ? window.weed.link(c.href) : window.weed.quote();
      if (picked) window.weed.open();
    },
  });
});

/* Ořez cíle pro zadání (SPEC §7.6). Bitmapu smí pořídit jen background:
 * `captureVisibleTab` vidí na celou kartu a stránce se do rukou nedává.
 * Kotva přichází z izolovaného světa, kde běží jádro — ne z webu. */
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (!message || message.type !== "weed:shot") return;
  const target = { tabId: sender.tab?.id, documentId: sender.documentId };
  captureTarget(target, { anchor: message.anchor })
    .then((r) => reply(r.value ? { data: r.value.data } : { error: r.error }))
    .catch((error) => reply({ error: String(error?.message || error) }));
  return true;
});
