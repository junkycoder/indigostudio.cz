/* Ořez cíle jako příloha zadání (SPEC §7.6).
 *
 * Appka snímek umí sama, rozšíření ho dlouho nemělo — vznikal až na vyžádání
 * přes lokální MCP, a ten skončil. Zip z rozšíření tak byl prompt bez obrázku,
 * přestože právě obrázek řekne agentovi za odstavec textu, na co se kouká.
 *
 * Fotí se **v okamžiku zadání**, ne při balení: tehdy se uživatel na cíl dívá
 * a je jistě ve viewportu. Při balení už může být odscrollovaný nebo pryč,
 * a snímek pořízený naslepo by ukázal něco jiného než cíl (zásada 8).
 *
 * Drží se vedle seznamu, tedy u projektu a v úložišti rozšíření — ne v paměti
 * stránky. Seznam přechod na jinou stránku webu přežije (§2.6) a musí ho
 * přežít i příloha: jméno v promptu bez souboru pošle agenta hledat něco,
 * co nedostane.
 *
 * Bitmapu pořizuje background, ne stránka — ta ji nesmí dostat do rukou.
 */

(() => {
  "use strict";

  const events = window.WeedCore.events ||= new EventTarget();
  const store = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
  if (!store || !chrome.runtime) return;

  const KEY = `shots:${window.WeedCore.project(location.hostname, location.port)}`;
  const nameFor = (id) => `cil-${id}.png`;

  /* Strop, aby seznam zadání neutáhl úložiště rozšíření. Padesát ořezů je víc,
     než kolik má kdo rozepsaných zadání; přes to se nefotí, zadání odejde bez
     obrázku. */
  const MAX = 50;

  let chain = Promise.resolve();
  const read = async () => (await store.get(KEY))[KEY] || {};

  // Jádro čeká na snímek, než pustí prompt do schránky — ale jen tam, kde ho
  // někdo umí pořídit. Tohle je to přihlášení.
  try { window.weed.shots(true); } catch (_) { /* starší jádro o ořezu neví */ }

  /*
   * Fotí se na vyžádání jádra, které si na snímek počká. `weed:draft:set`
   * zůstává jako záloha: zadání může přibýt i mimo paletu (přes `add`) a ořez
   * k němu má vzniknout taky.
   */
  events.addEventListener("weed:shot:want", () => {
    chain = chain.then(take).catch(() => {}).finally(() => {
      events.dispatchEvent(new CustomEvent("weed:shot:done"));
    });
  });
  events.addEventListener("weed:draft:set", () => { chain = chain.then(take).catch(() => {}); });

  async function take() {
    let snapshot;
    try { snapshot = await window.weed.list(); } catch (_) { return; }
    const items = snapshot.items || [];
    const have = await read();

    // Co ze seznamu zmizelo, ať nezůstává v úložišti ani v zipu.
    const live = new Set(items.map((i) => nameFor(i.id)));
    let shots = Object.fromEntries(Object.entries(have).filter(([name]) => live.has(name)));

    for (const item of items) {
      const name = nameFor(item.id);
      if (shots[name]) continue;
      if (Object.keys(shots).length >= MAX) break;
      const anchor = (item.anchors || [])[0];
      if (!anchor) continue;
      let answer;
      try { answer = await chrome.runtime.sendMessage({ type: "weed:shot", anchor }); }
      catch (_) { return; }   // rozšíření se právě znovu načetlo
      // Neúspěch se nehlásí ani nezkouší znovu na téhle stránce: prvek mohl
      // odjet z viewportu, být zakrytý, nebo je zadání z jiné stránky webu.
      // Zadání odejde bez obrázku a to je pořád celé zadání (zásada 5).
      if (!answer || !answer.data) continue;
      shots[name] = answer.data;
      try { window.weed.attach(item.id, name); } catch (_) { /* zadání mezitím zmizelo */ }
    }

    if (JSON.stringify(shots) !== JSON.stringify(have)) {
      await (Object.keys(shots).length ? store.set({ [KEY]: shots }) : store.remove(KEY));
    }
  }

  events.addEventListener("weed:files:get", () => {
    chain = chain.then(async () => {
      const shots = await read();
      const files = Object.entries(shots).map(([name, data]) => ({ name, data }));
      events.dispatchEvent(new CustomEvent("weed:files", { detail: JSON.stringify(files) }));
    }).catch(() => {
      events.dispatchEvent(new CustomEvent("weed:files", { detail: "[]" }));
    });
  });
})();
