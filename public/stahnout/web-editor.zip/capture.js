/* Bitmapu pořizuje jen důvěryhodný background, nikdy zpráva z webu. */
async function captureTarget(target, elementTarget) {
  try {
    if (!target || !Number.isInteger(target.tabId) || target.tabId < 0 ||
        typeof target.documentId !== "string" || !target.documentId.trim()) {
      throw new Error("capture vyžaduje tabId a documentId");
    }
    if (!elementTarget?.anchor || typeof elementTarget.anchor !== "object" || Array.isArray(elementTarget.anchor)) {
      throw new Error("capture vyžaduje target s kotvou prvku");
    }
    const activeTab = async () => {
      const tab = await chrome.tabs.get(target.tabId);
      if (!tab.active || tab.status !== "complete") throw new Error("capture vyžaduje aktivní a načtenou kartu");
      return tab;
    };
    const measure = async () => {
      const [injection] = await chrome.scripting.executeScript({
        target: { tabId: target.tabId, documentIds: [target.documentId] },
        world: "ISOLATED",
        args: [elementTarget.anchor],
        func: (anchor) => {
          if (window !== window.top) return { error: "capture podporuje jen hlavní dokument" };
          if (!window.WeedCore) return { error: "Web Editor není v tomto dokumentu" };
          const el = window.WeedCore.resolve(anchor, document);
          if (!el) return { error: "prvek už v dokumentu není" };
          const rect = el.getBoundingClientRect();
          const viewport = window.visualViewport;
          if (viewport && (viewport.scale !== 1 || viewport.offsetLeft !== 0 || viewport.offsetTop !== 0)) {
            return { error: "capture nepodporuje přiblížený vizuální viewport" };
          }
          if (rect.width <= 0 || rect.height <= 0 || rect.left < 0 || rect.top < 0 ||
              rect.right > document.documentElement.clientWidth || rect.bottom > document.documentElement.clientHeight ||
              !el.checkVisibility({ checkOpacity: true, checkVisibilityCSS: true })) {
            return { error: "prvek musí být celý viditelný ve viewportu" };
          }
          for (let parent = el.parentElement; parent; parent = parent.parentElement) {
            const style = getComputedStyle(parent);
            const box = parent.getBoundingClientRect();
            const clipsX = /hidden|clip|scroll|auto/.test(style.overflowX);
            const clipsY = /hidden|clip|scroll|auto/.test(style.overflowY);
            if ((clipsX && (rect.left < box.left + parent.clientLeft || rect.right > box.left + parent.clientLeft + parent.clientWidth)) ||
                (clipsY && (rect.top < box.top + parent.clientTop || rect.bottom > box.top + parent.clientTop + parent.clientHeight))) {
              return { error: "prvek je oříznutý rodičem; musí být celý viditelný" };
            }
          }
          /*
           * Kolem cíle zůstane kousek stránky — tentýž, jaký uživatel viděl
           * vysvícený v cloně (`weed.pad`). Ořezaný na hranu prvku by agentovi
           * ukázal cíl bez místa, ve kterém stojí.
           */
          const pad = Number(window.weed?.pad) || 0;
          const left = Math.max(0, rect.x - pad);
          const top = Math.max(0, rect.y - pad);
          const right = Math.min(document.documentElement.clientWidth, rect.right + pad);
          const bottom = Math.min(document.documentElement.clientHeight, rect.bottom + pad);
          /*
           * Viewport bez posuvníku: `captureVisibleTab` fotí plochu, do které
           * se kreslí, kdežto `innerWidth` posuvník počítá. Na stránce, která
           * se scrolluje, se pak snímek s viewportem „nepotkal“ a ořez se
           * zbytečně zahodil.
           */
          return { x: left, y: top, width: right - left, height: bottom - top,
            viewportWidth: document.documentElement.clientWidth,
            viewportHeight: document.documentElement.clientHeight,
            scrollX, scrollY, dpr: devicePixelRatio, url: location.href };
        },
      });
      if (injection?.documentId !== target.documentId || injection.frameId !== 0) {
        throw new Error("dokument se během capture změnil");
      }
      if (!injection.result || injection.result.error) throw new Error(injection.result?.error || "chybí rozměry prvku");
      return injection.result;
    };
    const tab = await activeTab();
    const before = await measure();
    let changed = false;
    const onActivated = (info) => { if (info.windowId === tab.windowId) changed = true; };
    const onUpdated = (id, info) => { if (id === target.tabId && (info.status || info.url)) changed = true; };
    chrome.tabs.onActivated.addListener(onActivated);
    chrome.tabs.onUpdated.addListener(onUpdated);
    let png;
    const hiddenUI = {
      target: { tabId: target.tabId, documentIds: [target.documentId] },
      origin: "USER",
      /*
       * Clona ve snímku zůstává: ořez jde agentovi jako příloha a má na něm být
       * vidět, co je cíl (§7.6). Schová se jen paleta a vrstva, která odchytává
       * ťuknutí — ty do zadání nepatří. Stejně to dělá appka.
       */
      css: ":root > #weed-root, :root > #weed-overlay { visibility: hidden !important; }",
    };
    let uiHidden = false;
    try {
      await chrome.scripting.insertCSS(hiddenUI);
      uiHidden = true;
      const current = await activeTab();
      if (current.windowId !== tab.windowId) throw new Error("karta změnila okno");
      png = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
      const after = await measure();
      const finalTab = await activeTab();
      if (changed || finalTab.windowId !== tab.windowId || JSON.stringify(before) !== JSON.stringify(after)) {
        throw new Error("karta, dokument nebo rozměry se během capture změnily; opakuj snímek");
      }
    } finally {
      chrome.tabs.onActivated.removeListener(onActivated);
      chrome.tabs.onUpdated.removeListener(onUpdated);
      // Identita dokumentu brání odebrání CSS z jiné stránky po navigaci.
      if (uiHidden) await chrome.scripting.removeCSS(hiddenUI);
    }
    const bitmap = await createImageBitmap(await (await fetch(png)).blob());
    try {
      const sx = bitmap.width / before.viewportWidth;
      const sy = bitmap.height / before.viewportHeight;
      /*
       * Snímek a viewport si musí odpovídat poměrem, ne na pixel: prohlížeč
       * vrací plochu zaokrouhlenou a o jeden pixel se liší běžně. Kontrola je
       * tu proti snímku jiné stránky nebo jiného zvětšení — tam se poměry
       * rozejdou o desítky procent, ne o tisícinu. Rozměry jdou do hlášky,
       * protože bez nich se tahle chyba ladí naslepo.
       */
      if (!Number.isFinite(sx) || !Number.isFinite(sy) || sx <= 0 || sy <= 0 ||
          Math.abs(sx - sy) > 0.01 * Math.max(sx, sy)) {
        throw new Error(`rozměry snímku neodpovídají viewportu: snímek ${bitmap.width}×${bitmap.height}, viewport ${before.viewportWidth}×${before.viewportHeight}`);
      }
      const x = Math.floor(before.x * sx), y = Math.floor(before.y * sy);
      const width = Math.ceil((before.x + before.width) * sx) - x;
      const height = Math.ceil((before.y + before.height) * sy) - y;
      const canvas = new OffscreenCanvas(width, height);
      canvas.getContext("2d").drawImage(bitmap, x, y, width, height, 0, 0, width, height);
      const bytes = new Uint8Array(await (await canvas.convertToBlob({ type: "image/png" })).arrayBuffer());
      let binary = "";
      for (let i = 0; i < bytes.length; i += 32768) binary += String.fromCharCode(...bytes.subarray(i, i + 32768));
      return { value: { data: btoa(binary), mimeType: "image/png", width, height }, target };
    } finally {
      bitmap.close();
    }
  } catch (error) {
    return { error: String(error?.message || error), target };
  }
}
