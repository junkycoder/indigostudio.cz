/*
 * weed-core — jádro, které nepotřebuje prohlížeč ani model.
 *
 * Zadání se nepřekládá (SPEC §7.1): věta jde ven, jak ji uživatel řekl, a co
 * s ní, rozhoduje jeho agent. Jádro k ní přidává jen to, co vidí na stránce
 * a agent ne — kotvu a smysluplný prvek, místo přesunu, systém webu, škálu
 * písma a barvy — a kontrolu, jestli je z čeho zadání složit.
 *
 * Do stránky nesahá (§2.2).
 */

(function (root) {
  "use strict";

  // -------------------------------------------------------------- jazyk

  /*
   * Rozhraní mluví jazykem prohlížeče, stejně jako appka jazykem systému —
   * přepínač nikde není. Klíčem je česká věta, jak stojí v kódu (totéž dělá
   * `ios/Shared/Localizable.xcstrings`), takže čeština zůstává zdrojem pravdy
   * a angličtina je překlad vedle ní.
   *
   * Co v mapě není, projde beze změny: chybějící překlad ubere jazyk, ne
   * funkci (zásada 5). Jádro běží i mimo prohlížeč, proto ten test na
   * `navigator` — bez něj jsou testy v Node rozbité dřív, než se rozběhnou.
   *
   * Zadání uživatele tudy nikdy neprochází (§7.1). Tohle je jen naše
   * rozhraní kolem něj.
   */
  const EN = {
    "Prázdný příkaz.": "Nothing to do — the request is empty.",
    "Příkaz je moc dlouhý.": "That request is too long.",
    "Vybraný element už na stránce není.": "The element you picked is no longer on the page.",
    "Nejdřív vyber, co se má přesunout.": "Pick what to move first.",
    "Tam nic není.": "Nothing there.",
    "To je to, co přesouváš — ťukni jinam.": "That's what you're moving — tap somewhere else.",
    "Nic není vybráno — vyber elementy zaměřovačem.": "Nothing is picked — use the crosshair to pick elements.",
    " (vnitřní)": " (inner)",
    " (vnější)": " (outer)",
    "přesuň %s": "move %s",
    "dovnitř %s": "inside %s",
    "nad %s": "above %s",
    "pod %s": "below %s",
    "vlevo od %s": "to the left of %s",
    "vpravo od %s": "to the right of %s",
    "vyjmi jen nadpis, jeho obsah zůstane na místě": "take out the heading only; what sits under it stays where it is",
    // Jména prvků. Čeština je má ve čtvrtém a druhém pádě, angličtina pády
    // nemá — obojí tedy padne na totéž slovo.
    "tlačítko": "the button", "tlačítka": "the button",
    "odkaz": "the link", "odkazu": "the link",
    "obrázek": "the image", "obrázku": "the image",
    "odstavec": "the paragraph", "odstavce": "the paragraph",
    "položku": "the item", "položky": "the item",
    "seznam": "the list", "seznamu": "the list",
    "pole": "the field",
    "navigaci": "the navigation", "navigace": "the navigation",
    "sekci": "the section", "sekce": "the section",
    "hlavičku": "the header", "hlavičky": "the header",
    "patičku": "the footer", "patičky": "the footer",
    "formulář": "the form", "formuláře": "the form",
    "blok": "the block", "bloku": "the block",
    "obsah": "the main content", "obsahu": "the main content",
    "článek": "the article", "článku": "the article",
    "boční panel": "the sidebar", "bočního panelu": "the sidebar",
    "tabulku": "the table", "tabulky": "the table",
    "řádek tabulky": "the table row", "řádku tabulky": "the table row",
    "buňku": "the cell", "buňky": "the cell",
    "stránku": "the page", "stránky": "the page",
    "nadpis": "the heading", "nadpisu": "the heading",
    "prvek": "the element", "prvku": "the element",
    "položku menu": "the menu item", "položky menu": "the menu item",

    // Paleta v Shadow DOM (`core/palette.js`) — jediné rozhraní, které stojí
    // uvnitř cizí stránky.
    "co chceš na stránce změnit?": "what do you want changed on this page?",
    "vybrat prvek — přidá se k vybraným": "pick an element — it joins the ones already picked",
    "zaměřovač": "crosshair",
    "přidat k ostatním a zkopírovat všechna zadání (⏎)": "add to the rest and copy every request (⏎)",
    "do schránky": "to the clipboard",
    "zadání pro tvého agenta, stránku neměníme": "requests for your agent — we don't touch the page",
    "balíček ke stažení — prompt a přílohy v jednom souboru": "a bundle to download — prompt and attachments in one file",
    "přilepit k zadání rychlost stránky — přenos a co uživatel pocítil (§4.6)": "attach page speed to the request — the traffic and what a visitor feels (§4.6)",
    "rychlost": "speed",
    "načíst stránku znovu a změřit od čistého začátku — rozepsaná zadání zůstanou": "reload the page and measure from a clean start — unfinished requests stay",
    "změřit načtením": "measure by reloading",
    "změřeno načtením": "measured by reloading",
    "měření — čísla do schránky": "measurements — numbers to the clipboard",
    "měření": "measurements",
    "zahodit rozepsaná zadání": "discard unfinished requests",
    "zahodit": "discard",
    "Zadání k ručnímu zkopírování": "Requests to copy by hand",

    // Co se dá vzít zpět — popisek se ukáže i v appce („vráceno: …").
    "označený text": "text marked",
    "odznačený text": "text unmarked",
    "vybraný prvek": "element picked",
    "odznačený prvek": "element unpicked",
    "přidané zadání": "request added",
    "přepsané zadání": "request rewritten",

    // Stavový řádek
    "zabito": "killed",
    "doplň": "say more",
    "prompt": "prompt",
    "zadání zahozena": "requests discarded",
    "změřeno načtením — rychlost půjde se zadáním": "measured by reloading — speed will go with the request",
    "ještě jednou — přijdeš o rozepsané na stránce": "once more — you'll lose what you have going on the page",
    "Není co poslat — vyber elementy nebo napiš zadání.": "Nothing to send — pick elements or write a request.",
    "Není co balit — přidej zadání.": "Nothing to bundle — add a request.",
    "Balíček se nepodařilo složit.": "The bundle wouldn't come together.",
    "schránka odmítla — zkopíruj označený text ručně": "the clipboard refused — copy the marked text by hand",
    "měření se nepodařilo přečíst": "the measurements wouldn't read",
    "měření je prázdné — zatím žádné zadání": "nothing measured yet — no requests so far",
    "rychlost stránky se přilepí k zadání": "page speed will go with the request",
    "rychlost stránky se nepřilepí": "page speed won't go along",
    "zadání zůstanou; formulář a posun na stránce ne": "requests stay; the form and your scroll position don't",
    "balíček · %s soubory · %s znaků": "bundle · %s files · %s chars",
    "balíček · %s souborů · %s znaků": "bundle · %s files · %s chars",
    "%s zadání": "%s requests",
    "pro agenta · %s znaků": "for your agent · %s chars",
    "%s ve schránce · %s znaků": "%s in the clipboard · %s chars",

    // Měření do schránky
    "Web Editor — měření": "Web Editor — measurements",
    "zatím žádné zadání": "no requests yet",
    " (od %s)": " (since %s)",
    "zadání: %s": "requests: %s",
    "průměrná délka promptu: %s znaků": "average prompt length: %s chars",
    "průměrná velikost snímku: %s znaků": "average snapshot size: %s chars",
    "průměrně cílů na zadání: %s": "average targets per request: %s",
    "verdikty: %s": "verdicts: %s",
    "Obsah stránky se nezaznamenává a nikam odsud nic neodchází.": "Page content is never recorded and nothing leaves from here.",
  };

  const czech = typeof navigator !== "undefined"
    && /^cs\b/i.test(navigator.language || "");

  /** Text v jazyce prohlížeče. Klíčem je česká věta z kódu. */
  function t(text) {
    return czech ? text : (Object.prototype.hasOwnProperty.call(EN, text) ? EN[text] : text);
  }

  /** Doplní do přeložené věty, co do ní patří — `%s` po pořadí. */
  function fill(pattern, ...values) {
    let i = 0;
    return t(pattern).replace(/%s/g, () => values[i++]);
  }

  // ------------------------------------------------------------ kontrola

  /**
   * Kontrola. Čistý kód, žádný model. Vrací null, když je všechno v pořádku,
   * jinak důvod, proč se dál nejde — a co s tím má uživatel udělat.
   */
  function check(prompt, elements) {
    const text = (prompt || "").trim();
    if (!text) return { verdict: "kill", reason: t("Prázdný příkaz.") };
    if (text.length > 2000) return { verdict: "kill", reason: t("Příkaz je moc dlouhý.") };
    for (const el of elements || []) {
      if (!el.isConnected) {
        return { verdict: "kill", reason: t("Vybraný element už na stránce není.") };
      }
    }
    return null;
  }

  // ----------------------------------------------------- kotvy (SPEC §4.3)

  /** Kolik textu nese kotva. Delší se zkrátí, ne zahodí. */
  const ANCHOR_TEXT = 60;

  /**
   * Ke každému cíli se ukládá víc kotev najednou. Třídy generované
   * frameworkem se mění s každým buildem, takže CSS selektor je až poslední
   * možnost — použije se ta kotva, která ještě sedí.
   */
  function anchorFor(el) {
    // `tagName.toLowerCase()` by z `linearGradient` udělal `lineargradient`,
    // a ten v HTML dokumentu nenajde nic: jména v cizím jmenném prostoru se
    // porovnávají přesně. Uvnitř SVG se vybírá element (§2.8), tak ať sedí.
    const a = { tag: el.localName || el.tagName.toLowerCase() };

    const testid = el.getAttribute("data-testid") || el.getAttribute("data-test") || el.getAttribute("data-cy");
    if (testid) a.testid = testid;
    if (el.id) a.id = el.id;

    const role = el.getAttribute("role");
    if (role) a.role = role;

    const label = el.getAttribute("aria-label");
    if (label) a.label = label;

    /*
     * Dlouhý text se nezahazuje, zkrátí se — jinak odstavec prózy zůstane
     * bez kotvy a spadne až na cestu stromem, ze které se v promptu stane
     * `body:nth-of-type(1) > div:nth-of-type(1) > …` a dva odstavce vedle
     * sebe jsou v záměru k nerozeznání (SPEC §4.3). Zkrácená kotva se hledá
     * na začátek a jen když sedí na jediný prvek — nehádá (zásada 8).
     */
    const text = (el.textContent || "").trim().replace(/\s+/g, " ");
    if (text.length > ANCHOR_TEXT) {
      a.text = text.slice(0, ANCHOR_TEXT);
      a.textCut = true;
    } else if (text) {
      a.text = text;
    }

    a.path = domPath(el);
    return a;
  }

  function domPath(el) {
    const parts = [];
    let node = el;
    while (node && node.nodeType === 1 && node !== node.ownerDocument.documentElement) {
      const parent = node.parentElement;
      if (!parent) break;
      const siblings = Array.from(parent.children).filter((c) => c.tagName === node.tagName);
      const idx = siblings.indexOf(node) + 1;
      parts.unshift(`${node.localName || node.tagName.toLowerCase()}:nth-of-type(${idx})`);
      node = parent;
    }
    return parts.join(" > ");
  }

  /** Zkusí kotvy v pořadí od nejstabilnější. Vrátí element, nebo null. */
  function resolve(anchor, doc) {
    const d = doc || document;
    const tries = [];

    if (anchor.testid) tries.push(() => d.querySelector(`[data-testid="${cssEscape(anchor.testid)}"]`));
    if (anchor.id) tries.push(() => d.getElementById(anchor.id));
    if (anchor.label) tries.push(() => d.querySelector(`[aria-label="${cssEscape(anchor.label)}"]`));
    // Celá kotva sedí na shodu, zkrácená na začátek — a ta jen tehdy, když
    // z ní vyjde jediný prvek. Dva odstavce se stejným začátkem znamenají
    // nejistotu, a ta se nepřebíjí tipem: jde se o kotvu níž.
    const textOf = (e) => (e.textContent || "").trim().replace(/\s+/g, " ");
    const hits = (list) => {
      const found = Array.from(list).filter((e) =>
        anchor.textCut ? textOf(e).startsWith(anchor.text) : textOf(e) === anchor.text
      );
      return anchor.textCut ? (found.length === 1 ? found[0] : null) : found[0];
    };
    if (anchor.role && anchor.text) {
      tries.push(() => hits(d.querySelectorAll(`[role="${cssEscape(anchor.role)}"]`)));
    }
    if (anchor.text && anchor.tag) {
      tries.push(() => hits(d.getElementsByTagName(anchor.tag)));
    }
    if (anchor.path) tries.push(() => d.querySelector(anchor.path));

    for (const t of tries) {
      let el = null;
      try { el = t(); } catch (_) { el = null; }
      if (el && el.isConnected) return el;
    }
    return null;
  }

  function cssEscape(s) {
    return String(s).replace(/["\\]/g, "\\$&");
  }

  // ------------------------------------------------------ smysluplný prvek

  /*
   * Na co uživatel ukázal (SPEC §2.1). Prst i kurzor trefí nejhlubší uzel pod
   * bodem, a ten bývá obal bez významu — `<span>`, který drží jedno tučné slovo
   * uprostřed odstavce. Zadání nad ním pošle agenta hledat prvek, který ve
   * zdrojáku nemusí vůbec být: tučné písmo tam dělá třída na odstavci a obal
   * dorobil editor obsahu. Cíl proto vystoupá na nejbližší prvek s vlastním
   * boxem a významem — blok, odkaz, tlačítko, obrázek, položku, formulářový
   * prvek. Klik do textu odstavce vybere odstavec, ne slovo; o slovo se stará
   * úsek v cíli, ne cíl sám.
   *
   * Že je obal holý, se pozná ze stránky, ne z konvence (zásada 8): jméno,
   * které nenese nic než vysázení, žádné id, třída, role ani `data-`, nic, na
   * co se chytá chování, a display, který vlastní box nedělá. **Jediná třída
   * stačí, aby se nelezlo dál** — pojmenovaný `<span>` je ve zdrojáku k
   * nalezení a agent ho najde.
   *
   * `<body>` a `<html>` cílem nejsou: kdo ukáže na holý obal přímo v těle
   * stránky, dostane ten obal. Lepší cíl tam není a celá stránka je horší než
   * kus, na který se ukázalo.
   */

  /* Jména, která sama o sobě neříkají nic než „tady je text vysázený jinak".
     `code`, `abbr`, `time`, `q` a `cite` v seznamu schválně nejsou — ty význam
     nesou a ve zdrojáku se po nich dá jít. */
  const BARE_INLINE = new Set(["span", "b", "i", "em", "strong", "u", "s", "strike",
    "small", "big", "font", "mark", "sub", "sup", "tt", "nobr", "bdi", "bdo"]);

  /* Atributy, kterými obal přestává být obalem: někdo ho pojmenoval, nebo se na
     něj něco chytá. `data-`, `on` a `aria-` se berou celé — jmenovat je po jednom
     znamená zapomenout na to, co si web vymyslel sám. */
  const CARRIES = new Set(["id", "class", "role", "title", "tabindex", "contenteditable",
    "draggable", "itemprop", "itemscope", "itemtype"]);

  function bare(el, exceptClass) {
    if (!BARE_INLINE.has(el.localName)) return false;
    for (const attr of el.attributes) {
      const name = attr.name;
      if (exceptClass && name === "class") continue;
      if (CARRIES.has(name) || name.startsWith("data-") || name.startsWith("on") || name.startsWith("aria-")) return false;
    }
    // Obal, ze kterého si web udělal box — inline-block, flex, grid —, je prvek
    // jako každý jiný: má vlastní rozměry a zadání nad ním dává smysl.
    try { if (getComputedStyle(el).display !== "inline") return false; } catch (_) { /* bez stylu rozhodne jméno */ }
    return true;
  }

  /*
   * Zvýrazněná ukázka kódu je taky jedna kresba (SPEC §2.1). Uvnitř `<pre>` to
   * vypadá jako strom prvků, ale `<span>` s barvou tokenu i ten kolem celého
   * řádku vyrobil zvýrazňovač při sestavení stránky — ve zdrojáku není ani
   * jeden. Vystoupat po nich znamená dojít z tokenu na řádek, a oba jsou
   * stejně k ničemu. Ukázce odpovídá jedna věc, a to celý blok.
   *
   * Odkaz a tlačítko uvnitř jsou výjimka jako `<foreignObject>` u kresby:
   * tlačítko *Kopírovat* nad ukázkou je prvek stránky, ne vysázení.
   */
  const LIVE_IN_CODE = "a[href], button, input, select, textarea, label, summary";

  function codeBlock(el) {
    const pre = el.closest && el.closest("pre");
    if (!pre || pre === el) return null;
    const live = el.closest(LIVE_IN_CODE);
    return live && pre.contains(live) ? live : pre;
  }

  /* Prvky, jejichž význam je silnější než jméno obalu v nich: ťuknutí do textu
     odkazu je ťuknutí na odkaz. `div` a `p` tu schválně nejsou — u nich je
     pojmenovaný obal pořád tím užším a stejně dobrým cílem. */
  const STRONG = "a[href], button, h1, h2, h3, h4, h5, h6, li, label, summary, td, th, dt, dd, figcaption, legend, option";

  const ownText = (el) => (el.textContent || "").trim().replace(/\s+/g, " ");

  /*
   * Obal, který nese celý text prvku s významem. Třída jinak vystoupání
   * zastaví — pojmenovaný `<span>` ve zdrojáku je a agent ho najde —, jenže
   * `<a><span class="…__label">Plugins</span></a>` není prvek vedle odkazu,
   * je to text toho odkazu. Kdo ukázal na slovo, ukázal na odkaz, a zadání nad
   * obalem by agenta poslalo měnit vnitřek místo odkazu samotného.
   *
   * Obráceně to neplatí a je to celý rozdíl: odkaz jako jediný obsah položky
   * seznamu zůstává odkazem, protože `<a>` význam nese sám. Proto sem smí jen
   * jména z `BARE_INLINE`, ne cokoliv, co zrovna vyplňuje rodiče.
   */
  function wrapsAll(el) {
    if (!bare(el, true)) return false;
    const text = ownText(el);
    if (!text) return false;
    // Obalů bývá na sobě víc: MediaWiki dá do nadpisu `<span lang dir>` a do něj
    // teprve `<span class="mw-page-title-main">`. Hledá se proto nejbližší prvek
    // s významem a cestou k němu nesmí stát nic než další obal.
    let up = el.parentElement;
    while (up && !up.matches(STRONG)) {
      if (!bare(up, true)) return false;
      up = up.parentElement;
    }
    return !!up && text === ownText(up);
  }

  function meaningful(el) {
    if (!el || el.nodeType !== 1) return el;
    const code = codeBlock(el);
    if (code) return code;
    let node = el;
    while (node.parentElement && (bare(node) || wrapsAll(node))) {
      const up = node.parentElement;
      if (up.localName === "body" || up.localName === "html") break;
      node = up;
    }
    return node;
  }

  // ------------------------------------------------------- chytrý přesun

  /*
   * Kam to ťuknutí míří. Prst trefí nejhlubší prvek — odkaz v položce menu —
   * ale kdo přesouvá sekci, míří na sekci. Cíl proto vystoupá na prvek téže
   * úrovně jako přesouvaný a místo vůči němu určí poloha ťuknutí a rozložení:
   * pod sebou nad/pod, vedle sebe vlevo/vpravo; ťuknutí do kontejneru mimo
   * jeho děti je dovnitř. Dvě úrovně se stejnou vahou se nerozsuzují —
   * vrátí se obě a vybere člověk.
   */

  const CONTAINERS = new Set(["div", "section", "main", "article", "aside", "nav", "header", "footer",
    "ul", "ol", "form", "fieldset", "td", "th", "li", "figure", "details", "dialog", "body"]);

  /** Osa, ve které prvek stojí se sourozenci: podle skutečné polohy, jinak podle rozložení rodiče. */
  function axisOf(el) {
    const a = el.getBoundingClientRect();
    const seen = (s) => { const r = s.getBoundingClientRect(); return r.width > 0 && r.height > 0 ? r : null; };
    const near = (step) => { for (let s = step(el); s; s = step(s)) { const r = seen(s); if (r) return r; } return null; };
    // Nejbližší viditelný sourozenec před, jinak za — neviditelné <style> a nulové obaly polohu neřeknou.
    const b = near((s) => s.previousElementSibling) || near((s) => s.nextElementSibling);
    if (b && a.height) {
      const overlap = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
      const apart = a.right <= b.left + 1 || b.right <= a.left + 1;
      return apart && overlap > Math.min(a.height, b.height) / 2 ? "horizontal" : "vertical";
    }
    const parent = el.parentElement;
    if (!parent) return "vertical";
    const cs = getComputedStyle(parent);
    if (/flex/.test(cs.display)) return /^row/.test(cs.flexDirection) ? "horizontal" : "vertical";
    if (/grid/.test(cs.display)) return cs.gridTemplateColumns.trim().split(/\s+/).length > 1 ? "horizontal" : "vertical";
    return /^inline/.test(getComputedStyle(el).display) ? "horizontal" : "vertical";
  }

  /*
   * Úroveň, na které se přesouvaný a cíl potkají: předek cíle, jehož rodič
   * obsahuje i přesouvaný. Nadpis v mobilní Wikipedii stojí ve flexu vedle
   * šipky, ale sekce jsou pod sebou — osa přesunu je osa sekcí.
   */
  function meetingOf(target, moving) {
    let c = target;
    while (c.parentElement && !c.parentElement.contains(moving)) c = c.parentElement;
    return c;
  }

  const depthOf = (el) => { let d = 0; while ((el = el.parentElement)) d++; return d; };
  const sharesClass = (a, b) => [...a.classList].some((c) => b.classList.contains(c));

  /** Jak moc je `c` na téže úrovni jako `m` — sourozenec, stejná značka, stejná hloubka. */
  function levelScore(c, m) {
    let s = 0;
    if (c.parentElement === m.parentElement) s += 3;
    if (c.tagName === m.tagName) s += 2;
    if (depthOf(c) === depthOf(m)) s += 1;
    if (c.parentElement && m.parentElement && c.parentElement.tagName === m.parentElement.tagName) s += 1;
    if (sharesClass(c, m)) s += 1;
    // Sourozenec předka přesouvaného: prvek, vedle kterého to po vystoupání z rámečku stojí.
    if (c.parentElement && c.parentElement.contains(m)) s += 2;
    return s;
  }

  /** Do textu blok nepatří — odstavec, odkaz, nadpis ani položka s vlastním textem nejsou kontejner. */
  const textual = (el) => [...el.childNodes].some((n) => n.nodeType === 3 && n.data.trim())
    || /^inline/.test(getComputedStyle(el).display);

  /** Jak moc je `c` kontejner pro `m` — jeho rodič, nebo prvek jako jeho rodič. */
  function containerScore(c, m) {
    const p = m.parentElement;
    if (!p || !CONTAINERS.has(c.tagName.toLowerCase()) || textual(c)) return 0;
    if (c === p) return 5;
    let s = 0;
    if (c.tagName === p.tagName) s += 2;
    if (depthOf(c) === depthOf(p)) s += 1;
    if (sharesClass(c, p)) s += 1;
    return s;
  }

  const NOUNS = {
    button: ["tlačítko", "tlačítka"], a: ["odkaz", "odkazu"], img: ["obrázek", "obrázku"],
    p: ["odstavec", "odstavce"], li: ["položku", "položky"], ul: ["seznam", "seznamu"], ol: ["seznam", "seznamu"],
    input: ["pole", "pole"], textarea: ["pole", "pole"], nav: ["navigaci", "navigace"], section: ["sekci", "sekce"],
    header: ["hlavičku", "hlavičky"], footer: ["patičku", "patičky"], form: ["formulář", "formuláře"],
    div: ["blok", "bloku"], main: ["obsah", "obsahu"], article: ["článek", "článku"], aside: ["boční panel", "bočního panelu"],
    table: ["tabulku", "tabulky"], tr: ["řádek tabulky", "řádku tabulky"], td: ["buňku", "buňky"], figure: ["obrázek", "obrázku"],
    body: ["stránku", "stránky"],
  };

  const UNSEEN = new Set(["STYLE", "SCRIPT", "NOSCRIPT", "TEMPLATE"]);

  /**
   * Text, jak ho člověk vidí — bez stylů a skriptů uvnitř (Wikipedie vkládá
   * TemplateStyles `<style>` přímo do obsahu) a bez skrytých prvků.
   */
  function visibleText(el, max) {
    let out = "";
    const walk = (node) => {
      for (const n of node.childNodes) {
        if (out.length >= max) return;
        if (n.nodeType === 3) out += n.data;
        else if (n.nodeType === 1 && !UNSEEN.has(n.tagName) && !n.hidden && getComputedStyle(n).display !== "none") walk(n);
      }
    };
    walk(el);
    return out;
  }

  /** Česky pro člověka: [4. pád, 2. pád] — „položku menu „Ceník““. */
  function nounOf(el) {
    const tag = el.tagName.toLowerCase();
    let noun = (NOUNS[tag] || (/^h[1-6]$/.test(tag) ? ["nadpis", "nadpisu"] : ["prvek", "prvku"])).map(t);
    if (tag === "li" && el.closest("nav, menu, [role=menu], [role=menubar], [role=navigation]")) {
      noun = ["položku menu", "položky menu"].map(t);
    }
    if (tag === "body") return noun;
    const raw = (el.getAttribute("aria-label") || el.getAttribute("alt") || visibleText(el, 60)).replace(/\s+/g, " ").trim();
    const text = raw.length > 40 ? raw.slice(0, 39) + "…" : raw;
    return text ? noun.map((n) => `${n} „${text}“`) : noun;
  }

  const PHRASE = {
    vertical: { before: (n) => fill("nad %s", n[0]), after: (n) => fill("pod %s", n[0]) },
    horizontal: { before: (n) => fill("vlevo od %s", n[1]), after: (n) => fill("vpravo od %s", n[1]) },
  };

  /*
   * Přesouvá se jen vybraný prvek, nikdy jeho sourozenci. U nadpisu to agent
   * snadno vyloží jako přesun celé sekce — proto to zadání říká výslovně.
   * Věta nesmí obsahovat slova místa (za, pod, do…), aby se nepletla s tím,
   * kam se přesouvá.
   */
  const isHeading = (tag) => /^h[1-6]$/i.test(tag || "");
  const HEADING_ONLY = () => t("vyjmi jen nadpis, jeho obsah zůstane na místě");

  function option(moving, target, position, axis) {
    const noun = nounOf(target);
    const label = position === "inside" ? fill("dovnitř %s", noun[1]) : PHRASE[axis][position](noun);
    const heading = moving.some((el) => isHeading(el.tagName) || el.getAttribute("role") === "heading");
    return {
      label,
      text: fill("přesuň %s", label) + (heading ? ` — ${HEADING_ONLY()}` : ""),
      position,
      axis,
      intent: {
        op: "move",
        from: moving.map(anchorFor),
        to: anchorFor(target),
        position,
        axis,
        scope: "element",
      },
    };
  }

  /** Místo vůči cíli podle polohy ťuknutí na jeho ose. */
  function sideOf(target, moving, x, y) {
    const axis = axisOf(meetingOf(target, moving));
    const r = target.getBoundingClientRect();
    const f = axis === "horizontal" ? (x - r.left) / (r.width || 1) : (y - r.top) / (r.height || 1);
    return { axis, position: f < 0.5 ? "before" : "after" };
  }

  /**
   * Chytrý přesun: `moving` jsou vybrané prvky, x/y ťuknutí ve viewportu.
   * Vrací { verdict: "done" | "ask" | "kill", options: [{ label, text, position, axis, intent }], reason? }.
   * Stránky se nedotkne.
   */
  function placement(moving, x, y, doc) {
    const d = doc || document;
    const m = moving && moving[0];
    if (!m || !m.isConnected) return { verdict: "kill", options: [], reason: t("Nejdřív vyber, co se má přesunout.") };

    // Prvek pod prstem, ne naše UI (paleta, zaměřovač) — to žije pod #weed-root.
    const hit = d.elementsFromPoint(x, y).find((el) => !el.closest("#weed-root") && el !== d.documentElement);
    if (!hit) return { verdict: "kill", options: [], reason: t("Tam nic není.") };
    if (moving.some((el) => el === hit || el.contains(hit))) {
      return { verdict: "kill", options: [], reason: t("To je to, co přesouváš — ťukni jinam.") };
    }

    const found = [];
    for (let c = hit; c && c !== d.documentElement; c = c.parentElement) {
      // Předek přesouvaného může být jen kontejner — sourozencem sám sobě být nemůže.
      const ancestor = moving.some((el) => c.contains(el));
      const level = ancestor ? 0 : levelScore(c, m);
      // Dovnitř jen tam, kam se ťuklo mimo děti — ťuk do odstavce v článku míří na odstavec, ne do článku.
      const box = c === hit ? containerScore(c, m) : 0;
      if (level > 0 && level >= box) found.push({ el: c, score: level, kind: "level" });
      else if (box > 0) found.push({ el: c, score: box, kind: "container" });
    }

    const best = Math.max(0, ...found.map((f) => f.score));
    const top = best > 0 ? found.filter((f) => f.score === best) : [];
    const picks = top.length ? top.slice(0, 2) : [{ el: hit, kind: "level" }];
    const options = picks.map(({ el, kind }) => {
      if (kind === "container") return option(moving, el, "inside", null);
      const { axis, position } = sideOf(el, m, x, y);
      return option(moving, el, position, axis);
    });
    // Dvě možnosti se stejným popisem by člověk nerozlišil — řekne se, která úroveň je která.
    if (options.length === 2 && options[0].label === options[1].label) {
      options.forEach((o, i) => {
        const was = o.label;
        o.label += t(i === 0 ? " (vnitřní)" : " (vnější)");
        o.text = o.text.replace(was, o.label);
      });
    }
    return { verdict: top.length === 1 ? "done" : "ask", options };
  }

  // ------------------------------------------------------------- platforma

  /*
   * Na čem web běží (SPEC §4.4). Pravidlo: jen DOM a text inline skriptů, nikdy
   * `window` stránky (§13). Každý signál má váhu; platforma vyjde, jen když ji
   * signály ukazují samy a dost silně — jinak null a v promptu je vanilla.
   * Jméno je text pro agenta, ne číselník, na který se vážeme (zásada 8).
   */
  const PLATFORM_NAMES = { wordpress: "WordPress", shopify: "Shopify", shoptet: "Shoptet", webflow: "Webflow", wix: "Wix" };
  const SURE = 0.6;    // od kolika platforma vyjde
  const RIVAL = 0.4;   // od kolika ji jiná platforma zpochybní

  const inlineScripts = (doc) => [...doc.querySelectorAll("script:not([src])")].map((s) => s.textContent || "");
  const assetUrls = (doc) => [...doc.querySelectorAll("script[src], link[href], img[src]")].map((e) => e.getAttribute("src") || e.getAttribute("href") || "");
  const generator = (doc) => [...doc.querySelectorAll('meta[name="generator" i]')].map((m) => m.getAttribute("content") || "").join(" ");



  const PLATFORMS = {
    wordpress: {
      signals(doc) {
        const out = [];
        if (/^\s*WordPress/i.test(generator(doc))) out.push(["meta generator WordPress", 0.6]);
        if (doc.querySelector('link[rel="https://api.w.org/"]')) out.push(["odkaz na WP REST API", 0.6]);
        if (assetUrls(doc).some((u) => /\/wp-(content|includes)\//.test(u))) out.push(["assety z /wp-content/", 0.4]);
        return out;
      },
    },
    shopify: {
      signals(doc) {
        const out = [];
        const scripts = inlineScripts(doc);
        if (scripts.some((s) => /Shopify\.shop\s*=|ShopifyAnalytics/.test(s))) out.push(["inline skript Shopify", 0.6]);
        if (doc.querySelector('meta[name="shopify-checkout-api-token"]')) out.push(["meta shopify-checkout-api-token", 0.6]);
        if (assetUrls(doc).some((u) => /cdn\.shopify\.com|\/cdn\/shop\//.test(u))) out.push(["assety z cdn.shopify.com", 0.4]);
        return out;
      },
    },
    shoptet: {
      signals(doc) {
        const out = [];
        if (inlineScripts(doc).some((s) => /dataLayer[\s\S]*["']shoptet["']\s*:/.test(s))) out.push(["dataLayer Shoptetu", 0.6]);
        if (assetUrls(doc).some((u) => /cdn\.myshoptet\.com/.test(u))) out.push(["assety z cdn.myshoptet.com", 0.4]);
        return out;
      },
    },
    webflow: {
      signals(doc) {
        const out = [];
        const html = doc.documentElement;
        if (html.hasAttribute("data-wf-page")) out.push(["data-wf-page", 0.6]);
        if (html.hasAttribute("data-wf-site")) out.push(["data-wf-site", 0.3]);
        if (/Webflow/i.test(generator(doc))) out.push(["meta generator Webflow", 0.6]);
        return out;
      },
    },
    wix: {
      signals(doc) {
        const out = [];
        if (/Wix\.com/i.test(generator(doc))) out.push(["meta generator Wix", 0.6]);
        if (assetUrls(doc).some((u) => /static\.(parastorage|wixstatic)\.com/.test(u))) out.push(["assety z Wix CDN", 0.4]);
        return out;
      },
    },
  };

  /**
   * Na čem web běží. `{ id, name, confidence, signals }` — id je null, když
   * signály nejsou jednoznačné. Detekce je tichá: nikdo se neptá, výsledek jde
   * do hlavičky promptu jako text (§4.4).
   */
  function platform(doc) {
    const d = doc || document;
    const scored = Object.entries(PLATFORMS).map(([id, p]) => {
      const found = safeRun(() => p.signals(d), []);
      return { id, found, score: Math.min(1, found.reduce((s, [, w]) => s + w, 0)) };
    }).filter((p) => p.found.length);
    const signals = scored.flatMap((p) => p.found.map(([what]) => `${p.id}: ${what}`));
    const best = scored.slice().sort((a, b) => b.score - a.score)[0];
    const rivals = best ? scored.filter((p) => p !== best && p.score >= RIVAL) : [];
    if (!best || best.score < SURE || rivals.length) {
      return { id: null, name: null, confidence: best ? Math.round(best.score * 100) / 100 : 0, signals };
    }
    return { id: best.id, name: PLATFORM_NAMES[best.id], confidence: Math.round(best.score * 100) / 100, signals };
  }


  // --------------------------------------------- obsah, nebo kód (SPEC §4.4)

  /*
   * První otázka agenta a nejdražší chyba, kterou umíme udělat. Když je
   * „Sleva 20 % jen dnes!“ řádek v databázi, grep ve zdrojáku nenajde nic a
   * agent ztratí kola, než mu to dojde; když je to text v šabloně, stejnou
   * ztrátou je hledání v administraci.
   *
   * Signály se čtou ze stránky a obecně — ne z konvence frameworku. MVC je
   * pohled jednoho frameworku na svět a my chceme jeden postup pro všechny
   * weby, tak se čte, co je v prohlížeči vidět: opakovaná struktura, tvar
   * hodnoty, mutace po načtení, výskyt textu a stopy platformy.
   *
   * Web Editor z toho netvrdí závěr. Skládá větu, podle které se agent rozhodne
   * sám — a když si signály protiřečí, věta ven nejde a řekne se to nahlas
   * (zásada 8). Odhad prodaný jako fakt je horší než mlčení.
   */

  const ORIGIN_SURE = 0.6;      // pod tím se netvrdí nic
  const ORIGIN_RIVAL = 0.3;     // protistrana, kterou nejde přejít mlčky
  const ORIGIN_CLIMB = 6;       // o kolik předků se opře hledání opakované struktury
  const ORIGIN_SCAN = 4000;     // strop textových uzlů: cizí dokument (zásada 2)
  const ORIGIN_REPEAT = 3;      // tři stejní sourozenci jsou seznam, dva náhoda
  const ORIGIN_LONG = 25;       // znaků — kratší text je unikát i náhodou

  /* Tvary, které píše stroj, ne člověk do šablony. */
  const VALUE_SHAPES = [
    [/^\d{1,2}\.\s?\d{1,2}\.\s?\d{2,4}$/, "datum"],
    [/^\d{4}-\d{2}-\d{2}([T ]|$)/, "datum"],
    [/^\d{1,2}:\d{2}(:\d{2})?$/, "čas"],
    [/^[-−]?\s?\d[\d\s  ]*([.,]\d+)?\s*(Kč|CZK|€|EUR|\$|USD|%)$/i, "cena nebo procento"],
    [/^(Kč|€|\$|CZK|EUR|USD)\s?\d/i, "cena"],
    [/^\d+\s*(ks|kusů|kusy|×|x)$/i, "počet"],
    [/^[A-Z0-9]{3,}([-/][A-Z0-9]+)+$/, "kód"],
  ];

  /* Atributy, které nesou identitu záznamu — ne jak se jmenuje framework. */
  const RECORD_ATTR = /^(data-.*-?id|data-id|data-key|itemprop|itemid)$/i;

  const ORIGIN_TEMPLATE_TAGS = new Set(["nav", "header", "footer"]);

  /** Tvar uzlu pro porovnání sourozenců: značka a třídy, ne obsah. */
  function shapeOf(node) {
    const cls = node.classList ? [...node.classList].sort().join(".") : "";
    return `${(node.localName || "").toLowerCase()}${cls ? "." + cls : ""}`;
  }

  const originText = (el) => String((el && el.textContent) || "").replace(/\s+/g, " ").trim();

  /*
   * Uzly, které se po načtení změnily samy. Pozorovatel musí běžet od začátku,
   * takže ho startuje povrch při inicializaci; bez něj signál jen chybí, nic
   * se nerozbije (zásada 5).
   */
  const mutated = new WeakMap();

  function watchOrigin(doc, ignore) {
    const d = doc || document;
    if (mutated.has(d)) return mutated.get(d);
    const seen = new WeakSet();
    const skip = (n) => !!ignore && !!n && (n === ignore || (ignore.contains && ignore.contains(n)));
    const mark = (n) => { if (n && n.nodeType && !skip(n)) seen.add(n.nodeType === 3 ? n.parentNode || n : n); };
    const observer = new MutationObserver((records) => {
      for (const r of records) {
        if (skip(r.target)) continue;
        if (r.type === "characterData") mark(r.target);
        for (const n of r.addedNodes) mark(n);
        if (r.type === "attributes") mark(r.target);
      }
    });
    safeRun(() => observer.observe(d.documentElement || d, {
      subtree: true, childList: true, characterData: true,
    }), null);
    const state = { seen, observer, since: Date.now() };
    mutated.set(d, state);
    return state;
  }

  /** Změnil se prvek sám po načtení? Bez pozorovatele je odpověď „nevíme“. */
  function didMutate(el, doc) {
    const state = mutated.get(doc || (el && el.ownerDocument) || document);
    if (!state) return null;
    for (let n = el, i = 0; n && i < ORIGIN_CLIMB; n = n.parentElement, i++) {
      if (state.seen.has(n)) return true;
    }
    return false;
  }

  /** Kolikrát je tentýž text na stránce. Strop je tu proto, že běžíme u cizího. */
  function textHits(text, doc, ignore) {
    if (!text) return 0;
    const d = doc || document;
    const walker = d.createTreeWalker(d.body || d.documentElement, NodeFilter.SHOW_TEXT);
    let hits = 0, seen = 0, node;
    while ((node = walker.nextNode()) && seen < ORIGIN_SCAN) {
      seen++;
      if (ignore && ignore.contains && ignore.contains(node)) continue;
      if (String(node.nodeValue || "").replace(/\s+/g, " ").trim() === text) hits++;
    }
    return hits;
  }

  /**
   * Obsah, nebo kód. Vrací signály a verdikt — nebo přiznání, že se to ze
   * stránky nepozná. `{ verdict: "data" | "code" | null, confidence, signals, conflict }`
   */
  function origin(el, doc) {
    if (!el || !el.nodeType) return { verdict: null, confidence: 0, signals: [], conflict: false };
    const d = doc || el.ownerDocument || document;
    const ignore = d.getElementById && d.getElementById("weed-root");
    const data = [], code = [];
    const say = (side, weight, what) => (side === "data" ? data : code).push({ weight, what });

    // Opakovaná struktura: pátý stejný blok je řádek z dat, ne kopie v šabloně.
    for (let n = el, i = 0; n && n.parentElement && i < ORIGIN_CLIMB; n = n.parentElement, i++) {
      const shape = shapeOf(n);
      if (!shape || shape === "body") continue;
      let same = 0;
      for (const sib of n.parentElement.children) if (shapeOf(sib) === shape) same++;
      if (same >= ORIGIN_REPEAT) {
        say("data", 0.35, `${same} sourozenců stejného tvaru (${shape}) — je to jedna kopie z několika, změna patří šabloně nebo záznamu`);
        break;
      }
    }

    // Tvar hodnoty: co je formátováno strojem, nikdo do šablony nepsal ručně.
    const text = originText(el);
    for (const [re, what] of VALUE_SHAPES) {
      if (re.test(text)) { say("data", 0.35, `tvar hodnoty: ${what}`); break; }
    }

    // Mutace bez dotyku: co se ve stránce změnilo samo, přišlo z API, ne z HTML.
    const moved = didMutate(el, d);
    if (moved) say("data", 0.4, "po načtení se to změnilo samo — obsah z API, ne z HTML");

    // Stopy platformy jsou bonus, ne podmínka: když nejsou, stačí řádky výš.
    for (let n = el, i = 0; n && i < ORIGIN_CLIMB; n = n.parentElement, i++) {
      const hit = [...(n.attributes || [])].find((a) => RECORD_ATTR.test(a.name) && a.value);
      if (hit) { say("data", 0.5, `identita záznamu v markupu: ${hit.name}`); break; }
    }
    if (el.closest && el.closest("time[datetime]")) say("data", 0.3, "hodnota v <time datetime> — strojový zápis");

    // Výskyt textu: co je na stránce pokaždé, je šablona; unikát spíš obsah.
    if (text && text.length <= 200) {
      const hits = textHits(text, d, ignore);
      if (hits >= ORIGIN_REPEAT) say("code", 0.35, `tentýž text je na stránce ${hits}×— spíš šablona než záznam`);
      else if (hits === 1 && text.length >= ORIGIN_LONG) say("data", 0.15, "text je na stránce jen jednou");
    }

    // Trvalé části stránky píše člověk do šablony, ne redaktor do administrace.
    for (let n = el, i = 0; n && i < ORIGIN_CLIMB; n = n.parentElement, i++) {
      if (ORIGIN_TEMPLATE_TAGS.has((n.localName || "").toLowerCase())) {
        say("code", 0.3, `je to v <${n.localName.toLowerCase()}> — část, která je na každé stránce`);
        break;
      }
    }

    const weigh = (list) => Math.min(1, list.reduce((s, x) => s + x.weight, 0));
    const dw = weigh(data), cw = weigh(code);
    const signals = [
      ...data.map((x) => `obsah: ${x.what}`),
      ...code.map((x) => `kód: ${x.what}`),
    ];
    const top = Math.max(dw, cw), other = Math.min(dw, cw);
    const conflict = other >= ORIGIN_RIVAL && top >= ORIGIN_RIVAL;
    const round2 = (n) => Math.round(n * 100) / 100;
    if (conflict || top < ORIGIN_SURE) {
      return { verdict: null, confidence: round2(top), signals, conflict };
    }
    return { verdict: dw > cw ? "data" : "code", confidence: round2(top), signals, conflict: false };
  }

  // -------------------------------------------------------------- škála webu

  const SCALE_SCAN = 1200;      // strop prvků: běžíme v cizím dokumentu (zásada 2)
  const SCALE_SAME = 0.75;      // px — blíž u sebe je tentýž stupeň, ne dva
  const SCALE_MIN_STEPS = 3;    // dva stupně nejsou škála, to je náhoda
  const SCALE_MIN_USES = 2;     // velikost použitá jednou je výjimka, ne stupeň
  const SCALE_MIN = 8, SCALE_MAX = 96;
  const TYPE_VAR = /(^|-)(text|font|fs|type)s?(-|$)/;

  /** Délka na pixely. Jen px, rem a em — procenta a calc() stupeň neurčují. */
  function lengthToPx(value, el) {
    const m = /^\s*([\d.]+)(px|rem|em)\s*$/.exec(String(value || ""));
    if (!m) return 0;
    const n = parseFloat(m[1]);
    if (!isFinite(n) || n <= 0) return 0;
    if (m[2] === "px") return n;
    const base = m[2] === "rem"
      ? parseFloat(getComputedStyle(el.ownerDocument.documentElement).fontSize) || 16
      : parseFloat(getComputedStyle(el).fontSize) || 16;
    return n * base;
  }

  /** Má prvek vlastní text? Velikost zděděná prázdným obalem není stupeň. */
  function hasOwnText(el) {
    for (const node of el.childNodes) if (node.nodeType === 3 && node.nodeValue.trim()) return true;
    return false;
  }

  /**
   * Škála velikostí písma, jak ji web sám používá (SPEC §4.5). „Zvětši“ má
   * skočit na její další stupeň, ne násobit 1,25: násobek vyrobí velikost,
   * kterou web nikde jinde nemá, a agent ji pak napíše natvrdo do stylu.
   *
   * Čte se ze dvou stran. Četnost spočtených velikostí funguje vždycky, i na
   * cizím webu bez přístupu ke stylesheetu. Proměnné `:root` přidají jména, ale
   * jen ty, které podle jména patří písmu — `--space-4` je délka, ne stupeň.
   * Když web škálu nemá, vrátí se prázdno a vrstva vypadne: nejistý stupeň
   * je dražší než žádný (zásada 8).
   */
  function scale(doc) {
    const d = doc || document;
    const signals = [];
    const found = new Map();

    const counts = safeRun(() => {
      const out = new Map();
      const all = d.body ? d.body.getElementsByTagName("*") : [];
      const limit = Math.min(all.length, SCALE_SCAN);
      for (let i = 0; i < limit; i++) {
        const el = all[i];
        if (!hasOwnText(el)) continue;
        const cs = getComputedStyle(el);
        if (cs.display === "none" || cs.visibility === "hidden") continue;
        const px = parseFloat(cs.fontSize);
        if (!px || px < SCALE_MIN || px > SCALE_MAX) continue;
        const key = Math.round(px * 2) / 2;
        out.set(key, (out.get(key) || 0) + 1);
      }
      return out;
    }, new Map());
    for (const [px, uses] of counts) if (uses >= SCALE_MIN_USES) found.set(px, uses);
    if (found.size) signals.push(`četnost: ${found.size} velikostí na stránce`);

    // Proměnné vrátí jen prohlížeč, který umí iterovat spočtené `--*`. Kde to
    // nejde, vrstva vypadne a zbyde četnost — prompt je chudší, ne rozbitý (zásada 5).
    const vars = safeRun(() => {
      const el = d.documentElement, cs = getComputedStyle(el), out = [];
      for (const name of cs) {
        if (!name.startsWith("--") || !TYPE_VAR.test(name)) continue;
        const px = lengthToPx(cs.getPropertyValue(name), el);
        if (px >= SCALE_MIN && px <= SCALE_MAX) out.push([Math.round(px * 2) / 2, name]);
      }
      return out;
    }, []);
    const named = new Map();
    for (const [px, name] of vars) {
      if (!found.has(px)) found.set(px, SCALE_MIN_USES);
      if (!named.has(px)) named.set(px, name);
    }
    if (vars.length) signals.push(`proměnné: ${vars.map(([, n]) => n).join(", ")}`);

    // Dva stupně blíž než SCALE_SAME jsou tentýž stupeň.
    const steps = [];
    for (const px of [...found.keys()].sort((a, b) => a - b)) {
      const last = steps[steps.length - 1];
      if (last != null && px - last < SCALE_SAME) continue;
      steps.push(px);
    }
    const sure = steps.length >= SCALE_MIN_STEPS;
    // Stupeň, který má na webu jméno, se píše jménem — `var(--fs-sm)`, ne opsaných
    // 13,5 px. Je to totéž co u barev (§4.5): hodnota opsaná natvrdo
    // vypadne ze škály hned, jak ji web přenastaví.
    const names = {};
    for (const px of steps) if (named.has(px)) names[px] = named.get(px);
    return {
      steps: sure ? steps : [],
      names: sure ? names : {},
      source: !sure ? null : vars.length ? (found.size > vars.length ? "proměnné i četnost" : "proměnné") : "četnost",
      signals,
    };
  }


  // -------------------------------------------------------- barvy webu (§4.5)

  const COLOR_SCAN = 1200;       // strop prvků: běžíme v cizím dokumentu (zásada 2)
  const COLOR_MIN_USES = 2;      // barva použitá jednou je výjimka, ne barva webu
  const HUE_SPAN = 25;           // ± stupňů kolem odstínu; dál to není táž barva
  const CHROMA_MIN = 18;         // pod tím je to šeď, ne barva
  const DARK_MAX = 22;           // černá končí tady
  const LIGHT_MIN = 90;          // bílá začíná tady
  const BROWN_MAX_L = 45;        // hnědá je tmavá oranžová, ne druhý odstín
  const NEAR_HUE = 12;           // dva odstíny blíž u sebe jsou táž barva, ne volba
  const NEAR_SL = 12;
  const OPAQUE = 0.5;            // průhlednější barva není barva webu, je to závoj
  /** Tailwind nese odstín i sytost ve jméně třídy — `text-red-600` (§4.5). */
  const TW_CLASS = /(?:^|\s)(?:text|bg|border)-([a-z]+-\d{2,3})(?=\s|$)/;

  /** Barva na složky. Jen tvary, které prohlížeč a stylesheety opravdu vracejí. */
  function rgbOf(value) {
    const s = String(value || "").trim().toLowerCase();
    if (!s || s === "transparent" || s === "none" || s === "currentcolor") return null;
    const hex = /^#([0-9a-f]{3,8})$/.exec(s);
    if (hex) {
      const h = hex[1].length <= 4 ? [...hex[1]].map((c) => c + c).join("") : hex[1];
      if (h.length < 6) return null;
      const n = parseInt(h.slice(0, 6), 16);
      return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255, a: h.length >= 8 ? parseInt(h.slice(6, 8), 16) / 255 : 1 };
    }
    const rgb = /^rgba?\(([^)]+)\)$/.exec(s);
    if (rgb) {
      const parts = rgb[1].split(/[\s,/]+/).filter(Boolean).map(parseFloat);
      if (parts.length < 3 || parts.slice(0, 3).some((n) => !isFinite(n))) return null;
      return { r: parts[0], g: parts[1], b: parts[2], a: parts.length > 3 && isFinite(parts[3]) ? parts[3] : 1 };
    }
    const hsl = /^hsla?\(([^)]+)\)$/.exec(s);
    if (hsl) {
      const parts = hsl[1].split(/[\s,/%]+/).filter(Boolean).map(parseFloat);
      if (parts.length < 3 || parts.slice(0, 3).some((n) => !isFinite(n))) return null;
      return { ...rgbFromHsl({ h: parts[0], s: parts[1], l: parts[2] }), a: parts.length > 3 ? parts[3] : 1 };
    }
    return null;
  }

  function hslOf({ r, g, b }) {
    const R = r / 255, G = g / 255, B = b / 255;
    const max = Math.max(R, G, B), min = Math.min(R, G, B), d = max - min;
    const l = (max + min) / 2;
    if (!d) return { h: 0, s: 0, l: Math.round(l * 100) };
    const s = d / (1 - Math.abs(2 * l - 1));
    const h = max === R ? ((G - B) / d + (G < B ? 6 : 0)) : max === G ? (B - R) / d + 2 : (R - G) / d + 4;
    return { h: Math.round(h * 60), s: Math.round(s * 100), l: Math.round(l * 100) };
  }

  function rgbFromHsl({ h, s, l }) {
    const S = s / 100, L = l / 100;
    const c = (1 - Math.abs(2 * L - 1)) * S, x = c * (1 - Math.abs(((h / 60) % 2) - 1)), m = L - c / 2;
    const [r, g, b] = h < 60 ? [c, x, 0] : h < 120 ? [x, c, 0] : h < 180 ? [0, c, x]
      : h < 240 ? [0, x, c] : h < 300 ? [x, 0, c] : [c, 0, x];
    return { r: Math.round((r + m) * 255), g: Math.round((g + m) * 255), b: Math.round((b + m) * 255) };
  }

  const hexOf = ({ r, g, b }) => `#${[r, g, b].map((n) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, "0")).join("")}`;

  const hueGap = (a, b) => { const d = Math.abs(a - b) % 360; return d > 180 ? 360 - d : d; };

  /** Dvě barvy tak blízko, že mezi nimi nemá smysl dávat uživateli na výběr. */
  const nearColor = (a, b) =>
    Math.abs(a.l - b.l) <= NEAR_SL && Math.abs(a.s - b.s) <= NEAR_SL
    && (a.s < CHROMA_MIN || b.s < CHROMA_MIN || hueGap(a.h, b.h) <= NEAR_HUE);


  /**
   * Barvy, které web sám používá (SPEC §4.5). Čte se ze tří stran a každá
   * vydrží něco jiného: proměnné `:root` dají jména (`--brand` je signál
   * navíc), četnost spočtených barev funguje i tam, kde se k cizímu
   * stylesheetu bez CORS nedostaneme, a jméno Tailwindové třídy nese odstín
   * i sytost samo. Barva použitá jednou je výjimka, ne barva webu — proto
   * strop na četnost. Když web nedá nic, vrátí se prázdno a vrstva vypadne —
   * mlčet je levnější než hádat (zásada 8).
   */
  function colors(doc) {
    const d = doc || document;
    const signals = [];
    const found = new Map();

    const add = (value, name, tw) => {
      const rgb = rgbOf(value);
      if (!rgb || rgb.a < OPAQUE) return;
      const hex = hexOf(rgb);
      const at = found.get(hex) || { hex, ...hslOf(rgb), uses: 0, name: null, tw: null };
      at.uses += 1;
      if (name && !at.name) at.name = name;
      if (tw && !at.tw) at.tw = tw;
      found.set(hex, at);
    };

    const counted = safeRun(() => {
      const all = d.body ? d.body.getElementsByTagName("*") : [];
      const limit = Math.min(all.length, COLOR_SCAN);
      for (let i = 0; i < limit; i++) {
        const el = all[i];
        const cs = getComputedStyle(el);
        if (cs.display === "none" || cs.visibility === "hidden") continue;
        const cls = typeof el.className === "string" ? el.className : "";
        const tw = (TW_CLASS.exec(cls) || [])[1] || null;
        // Barvu textu počítáme jen tam, kde text opravdu je: zděděná barva
        // prázdného obalu by nafoukla četnost čímkoliv, co se dědí.
        if (hasOwnText(el)) add(cs.color, null, tw);
        add(cs.backgroundColor, null, tw);
        if (parseFloat(cs.borderTopWidth) > 0) add(cs.borderTopColor, null, tw);
      }
      return found.size;
    }, 0);
    if (counted) signals.push(`četnost: ${counted} barev na stránce`);

    // Proměnné vrátí jen prohlížeč, který umí iterovat spočtené `--*`. Kde to
    // nejde, vrstva vypadne a zbyde četnost (zásada 5).
    const vars = safeRun(() => {
      const cs = getComputedStyle(d.documentElement), out = [];
      for (const name of cs) {
        if (!name.startsWith("--")) continue;
        const value = cs.getPropertyValue(name);
        const rgb = rgbOf(value);
        if (!rgb) continue;
        out.push(name);
        add(value, name, null);
        // Pojmenovaná barva je barva webu i bez druhého výskytu: jméno je
        // silnější signál než četnost — někdo ji do stylu napsal schválně.
        const at = found.get(hexOf(rgb));
        if (at && at.uses < COLOR_MIN_USES) at.uses = COLOR_MIN_USES;
      }
      return out;
    }, []);
    if (vars.length) signals.push(`proměnné: ${vars.join(", ")}`);

    const list = [...found.values()].filter((c) => c.uses >= COLOR_MIN_USES).sort((a, b) => b.uses - a.uses);
    const tw = list.filter((c) => c.tw).map((c) => c.tw);
    if (tw.length) signals.push(`třídy: ${[...new Set(tw)].slice(0, 6).join(", ")}`);
    return {
      colors: list,
      source: !list.length ? null : vars.length ? (counted ? "proměnné i četnost" : "proměnné") : "četnost",
      signals,
    };
  }


  function safeRun(fn, fallback) {
    try { return fn(); } catch (_) { return fallback; }
  }

  // -------------------------------------------------------------- průchod

  /**
   * Celý průchod. Web Editor zadání nepřekládá — je to nástroj, který předá, co
   * vidí na stránce a co ukázal uživatel. Věta jde ven, jak ji člověk řekl,
   * i s kontextem kolem cíle; co s ní, rozhoduje agent uživatele.
   *
   * Zbyla tu jediná práce: kontrola, jestli je z čeho zadání složit. Ta se
   * dělá v prohlížeči schválně — chybějící cíl nebo prázdná věta se pozná
   * zadarmo a otázka na místě stojí míň než kolo u agenta.
   */
  function run(prompt, elements) {
    const killed = check(prompt, elements);
    if (killed) return killed;
    if (!elements.length) {
      return { verdict: "kill", reason: t("Nic není vybráno — vyber elementy zaměřovačem.") };
    }
    return { verdict: "prompt" };
  }

  /*
   * Projekt je web, jak ho vidí uživatel: registrovatelná doména se všemi
   * subdoménami (SPEC §0). Rozepsaný seznam patří jemu — ne stránce a ne
   * originu, jinak by se `admin.x.cz` ladila zvlášť od `www.x.cz`. Appka
   * počítá totéž ve Swiftu (`Project.key`); obě strany musí dát stejný klíč,
   * jinak si jádro na téže stránce sáhne pokaždé jinam.
   */
  const SECOND_LEVEL = ["co", "com", "org", "net", "ac", "gov", "edu"];

  function project(host, port) {
    const name = String(host || "").toLowerCase().replace(/^\[|\]$/g, "");
    if (!name) return "";
    // Localhost, .local a IP adresy jsou host s portem — na jednom stroji běží víc projektů.
    const local = name === "localhost" || name.endsWith(".local") || name.includes(":")
      || /^\d{1,3}(\.\d{1,3}){3}$/.test(name);
    const p = Number(port) || 0;
    if (local) return p ? `${name}:${p}` : name;
    const labels = name.split(".");
    if (labels.length <= 2) return name;
    const n = labels.length;
    // co.uk, com.au a podobné — druhý řád pod národní doménou není projekt.
    const second = labels[n - 1].length === 2 && SECOND_LEVEL.includes(labels[n - 2]);
    return labels.slice(second ? n - 3 : n - 2).join(".");
  }

  root.WeedCore = {
    t, fill,
    check, run, placement, platform, origin, watchOrigin, scale, colors,
    anchorFor, resolve, domPath, project, meaningful,
  };
})(typeof globalThis !== "undefined" ? globalThis : this);
