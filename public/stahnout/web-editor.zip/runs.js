/* Měření (SPEC §7.3). Úložiště rozšíření komunikuje s jádrem jen uvnitř
 * izolovaného světa.
 *
 * Drží se dvě věci a každá jinak dlouho:
 *
 * - **agregáty** — běžící součty bez obsahu a bez časové osy. Je to pár čísel,
 *   takže zůstávají trvale; z nich se pozná, jestli prompt neroste a kolik
 *   zadání kdo zadává.
 * - **záznam běhů** — posledních pár desítek, pak se zahazuje sám. Je na
 *   hledání toho, co se právě pokazilo, ne na historii.
 *
 * Obsah stránky tu není nikdy (§11) a nikam odsud nic neodchází.
 */

(() => {
  "use strict";

  const events = window.WeedCore.events ||= new EventTarget();

  const KEY = "runs";
  const SUM = "stats";
  /* Pár desítek, ne dva tisíce: záznam je na ladění posledních běhů. Co má
     přežít, jsou agregáty — a ty se nepočítají z něj. */
  const CAP = 50;
  const store = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
  if (!store) return;

  const load = async () => {
    const v = await store.get(KEY);
    return Array.isArray(v[KEY]) ? v[KEY] : [];
  };
  const stats = async () => {
    const v = await store.get(SUM);
    const s = v[SUM];
    return s && typeof s === "object"
      ? s
      : { runs: 0, chars: 0, snap: 0, targets: 0, verdicts: {}, since: null };
  };

  // Zápisy jdou za sebou — dva rychlé běhy by si jinak přepsaly seznam.
  let chain = Promise.resolve();

  events.addEventListener("weed:run", (e) => {
    let rec;
    try { rec = JSON.parse(e.detail); } catch (_) { return; }
    if (!rec || typeof rec !== "object") return;
    chain = chain.then(async () => {
      const runs = await load();
      runs.push(rec);
      if (runs.length > CAP) runs.splice(0, runs.length - CAP);

      /*
       * Agregát se počítá při zápisu, ne ze seznamu: seznam se ořezává, takže
       * součet z něj by po padesátém běhu začal klesat a měření by lhalo.
       */
      const s = await stats();
      s.runs += 1;
      s.chars += Number(rec.chars) || 0;
      s.snap += Number(rec.snap) || 0;
      s.targets += Number(rec.targets) || 0;
      if (rec.verdict) s.verdicts[rec.verdict] = (s.verdicts[rec.verdict] || 0) + 1;
      // Jediný čas, který se drží: od kdy se počítá. Osa běhů tu není (§7.3).
      s.since ||= Number(rec.at) || Date.now();

      await store.set({ [KEY]: runs, [SUM]: s });
    }).catch(() => {});
  });

  events.addEventListener("weed:runs:get", () => {
    chain = chain.then(async () => {
      const runs = await load();
      events.dispatchEvent(new CustomEvent("weed:runs", { detail: JSON.stringify(runs) }));
    }).catch(() => {});
  });

  events.addEventListener("weed:stats:get", () => {
    chain = chain.then(async () => {
      events.dispatchEvent(new CustomEvent("weed:stats", { detail: JSON.stringify(await stats()) }));
    }).catch(() => {
      events.dispatchEvent(new CustomEvent("weed:stats", { detail: "null" }));
    });
  });

  /* Smazat jde obojí naráz (§7.3) — měření patří uživateli, ne nám. */
  events.addEventListener("weed:runs:clear", () => {
    chain = chain.then(() => store.remove([KEY, SUM])).catch(() => {});
  });
})();
