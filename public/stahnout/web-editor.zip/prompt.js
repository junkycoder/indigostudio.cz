/*
 * prompt.js — kontext prvku, požadavek a sestavení promptu
 * (SPEC §2.3, §2.5, §4.1, §7.9).
 *
 * Ven jde prompt, ne model a ne přeložené zadání. Tři tvary, tři role
 * (§2.5): požadavek je vstup — co uživatel ukázal a řekl, nic odvozeného;
 * běh je, co se s ním stalo — verdikt a délka; balíček je výstup z obou —
 * prompt ve vrstvách. Vrstvy jsou nezávislé: když jedna spadne (cizí
 * stylesheet bez CORS), vypadne jen ona a prompt je chudší, ne žádný.
 * Z běhu se zapíše záznam (§7.4) — nikdy obsah stránky.
 *
 * Nic se neposílá. Výstup je text — uživatel si ho vloží, kam chce.
 * Žije pod WeedCore.Prompt, ne jako další globál (SPEC §13).
 */

(function (root) {
  "use strict";

  const Core = root.WeedCore;

  /** Vrstva, která spadne, vrátí náhradu — ne výjimku. */
  function safe(fn, fallback) {
    try { return fn(); } catch (_) { return fallback; }
  }

  // Každý znak se jednou zaplatí jako token. Limity jsou schválně těsné.
  const MAX_TEXT = 60;
  const MAX_ATTR = 80;
  // Karta pro sdílení je pár řádků a v konverzaci se stejně ořízne — delší text
  // by byl jen dražší prompt.
  const MAX_SHARE_TEXT = 200;
  const MAX_RULES = 6;
  const MAX_RULE_TEXT = 240;
  const MAX_PARENTS = 5;
  const MAX_INLINE = 200;
  const MAX_CLASSES = 4;
  const MAX_HINTS = 12;
  const MAX_QUOTE = 200;
  const MAX_GREP = 40;
  const MAX_SITE_COLORS = 6;      // barevník webu je popis, ne paleta k vybírání
  const MAX_ORIGIN_SIGNALS = 2;   // dva důvody stačí; třetí už agent neplatí rád

  // Desetiny pixelu nikdy (§7.6): `253.6` je přesnost, kterou nikdo nevyužije.
  const round = (n) => Math.round(n);
  const short = (s, n) => {
    s = String(s || "").replace(/\s+/g, " ").trim();
    return s.length > n ? s.slice(0, n - 1) + "…" : s;
  };
  const cssEscape = (s) => (root.CSS && root.CSS.escape ? root.CSS.escape(s) : String(s));

  /*
   * Úryvek, na který jde grepnout: useknutý na slovo a bez výpustky.
   * `„As described in RFC 2606 a…“` je klíčové slovo, které nic nenajde —
   * a klíčová slova jsou to, na čem agent nejvíc šetří (§7.6).
   */
  const grep = (s, n) => {
    const t = String(s || "").replace(/[…]+$/, "").replace(/\s+/g, " ").trim();
    if (t.length <= n) return t;
    const cut = t.slice(0, n);
    const space = cut.lastIndexOf(" ");
    return space > n / 2 ? cut.slice(0, space) : cut;
  };
  const norm = (s) => String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");

  // ------------------------------------------------------------- identita

  /*
   * `className` je řetězec jen u HTML — uvnitř SVG je to SVGAnimatedString
   * a `.trim()` na něm spadne. `classList` umí obojí, a tvar uvnitř SVG je
   * cíl jako každý jiný (SPEC §2.8).
   */
  function classes(el) {
    return el.classList ? Array.from(el.classList) : [];
  }

  /*
   * Jméno značky pro selektor. `tagName.toLowerCase()` by z `linearGradient`
   * udělal `lineargradient` a ten v HTML dokumentu nenajde nic: jména v cizím
   * jmenném prostoru se porovnávají přesně. `localName` je drží, jak jsou.
   */
  const localName = (el) => el.localName || el.tagName.toLowerCase();

  /** Jméno pro člověka: tag, id, pár tříd. */
  function name(el) {
    const cls = classes(el).slice(0, MAX_CLASSES).map((c) => "." + c).join("");
    return localName(el) + (el.id ? "#" + el.id : cls);
  }

  /** `p:nth-of-type(2)`, a bez indexu, když je sourozenec svého druhu sám. */
  function nth(node) {
    const tag = localName(node);
    const same = Array.from(node.parentElement.children).filter((c) => c.tagName === node.tagName);
    return same.length > 1 ? `${tag}:nth-of-type(${same.indexOf(node) + 1})` : tag;
  }

  /**
   * Nejkratší jednoznačný selektor: id, pak tag s třídami, pak totéž pod
   * některým z předků — a až nakonec index pod nejbližším předkem, který
   * je sám jednoznačný. Cesta od `<body>` je poslední záchrana: je
   * čtyřikrát delší a agentovi neřekne nic, co by v ní nebylo i takhle.
   */
  function selector(el, doc) {
    const d = doc || el.ownerDocument;
    const unique = (s) => safe(() => d.querySelectorAll(s).length === 1, false);
    const own = (node) =>
      node.id ? "#" + cssEscape(node.id) : localName(node) + classes(node).map((c) => "." + cssEscape(c)).join("");

    const self = own(el);
    if (unique(self)) return self;
    let node = el.parentElement;
    for (let i = 0; node && node !== d.documentElement && i < MAX_PARENTS; i++, node = node.parentElement) {
      const candidate = `${own(node)} ${self}`;
      if (unique(candidate)) return candidate;
      if (node.id) break; // id je jednoznačné — cokoliv nad ním už nepomůže
    }

    // Přímá cesta nahoru: každý krok je rodič, takže `>` sedí.
    const parts = [];
    node = el;
    for (let i = 0; node.parentElement && node.parentElement !== d.documentElement && i <= MAX_PARENTS; i++, node = node.parentElement) {
      parts.unshift(nth(node));
      const candidate = `${own(node.parentElement)} > ${parts.join(" > ")}`;
      if (unique(candidate)) return candidate;
    }
    return Core.domPath(el);
  }

  function identity(el) {
    const attrs = [];
    for (const a of Array.from(el.attributes)) {
      if (a.name === "class" || a.name === "style" || a.name === "id") continue;
      attrs.push(a.value === "" ? a.name : `${a.name}="${short(a.value, MAX_ATTR)}"`);
    }
    return { tag: localName(el), id: el.id || null, classes: classes(el), attrs, text: short(el.textContent, MAX_TEXT) };
  }

  // ------------------------------------------------------------ geometrie

  function geometry(el, win) {
    const r = el.getBoundingClientRect();
    const p = el.parentElement && el.parentElement.getBoundingClientRect();
    const out = {
      width: round(r.width), height: round(r.height), x: round(r.left), y: round(r.top),
      parent: p ? { width: round(p.width), height: round(p.height) } : null,
    };
    const off = [];
    if (r.right > win.innerWidth) off.push(`vpravo o ${round(r.right - win.innerWidth)}`);
    if (r.bottom > win.innerHeight) off.push(`dole o ${round(r.bottom - win.innerHeight)}`);
    if (r.left < 0) off.push(`vlevo o ${round(-r.left)}`);
    if (r.top < 0) off.push(`nahoře o ${round(-r.top)}`);
    if (off.length) out.offscreen = off;
    return out;
  }

  // ---------------------------------------------------------------- styly

  /*
   * Jen to, co má k rozložení a vzhledu co říct, a jen když to není výchozí
   * hodnota. Celý getComputedStyle má tři sta řádků, z toho dvě stě devadesát
   * nikoho nezajímá — a každý by se platil.
   */
  const PROPS = [
    "display", "position", "z-index", "top", "right", "bottom", "left",
    "flex-direction", "flex-wrap", "justify-content", "align-items", "grid-template-columns", "gap",
    "flex", "align-self", "order",
    "min-width", "max-width", "min-height", "max-height",
    "margin", "padding", "border", "border-radius", "box-shadow", "background-color",
    "font-size", "font-weight", "line-height", "color", "text-align", "white-space",
    "opacity", "visibility", "overflow", "transform", "pointer-events", "cursor", "transition",
  ];

  const DEFAULTS = {
    position: ["static"], "z-index": ["auto"], top: ["auto"], right: ["auto"], bottom: ["auto"], left: ["auto"],
    "flex-direction": ["row"], "flex-wrap": ["nowrap"], "justify-content": ["normal", "flex-start"],
    "align-items": ["normal", "stretch"], "grid-template-columns": ["none"], gap: ["normal", "0px"],
    flex: ["0 1 auto"], "align-self": ["auto"], order: ["0"],
    "min-width": ["auto", "0px"], "max-width": ["none"], "min-height": ["auto", "0px"], "max-height": ["none"],
    margin: ["0px"], padding: ["0px"], "border-radius": ["0px"], "box-shadow": ["none"],
    "background-color": ["rgba(0, 0, 0, 0)"], "font-weight": ["400"], "line-height": ["normal"],
    "text-align": ["start"], "white-space": ["normal"], opacity: ["1"], visibility: ["visible"],
    overflow: ["visible"], transform: ["none"], "pointer-events": ["auto"], cursor: ["auto", "default"],
    transition: ["none", "all"],
  };

  /*
   * Styly relevantní k větě (SPEC §4.1). Bez modelu se relevance pozná jen
   * podle slov: věta o překryvu nepotřebuje font, věta o písmu nepotřebuje
   * z-index. Když věta žádné slovo neobsahuje, jde ven všechno mimo výchozí
   * hodnoty. Je to úspora, ne hádání — pravidla ze stylesheetu nesou celý
   * zápis tak jako tak.
   */
  const ALWAYS = ["display", "position"];
  const TOPICS = [
    [/prekryv|pres sebe|\b(nad|pod)\b|z-?index|vrstv|schov|fixed|sticky|pozic|roh|okraj|vycuhuj|orez|overflow|posun|hni|dolev|doprav|nahoru|dolu/,
      ["z-index", "top", "right", "bottom", "left", "overflow", "transform", "opacity", "visibility", "pointer-events", "margin"]],
    [/barv|pozadi|background|color|stin|shadow|ramec|border|zaobl|radius|pruhled/,
      ["color", "background-color", "border", "border-radius", "box-shadow", "opacity"]],
    [/pism|font|\btext|velik|tucn|kurziv|radk|line-height|napis|nadpis/,
      ["font-size", "font-weight", "line-height", "color", "text-align", "white-space"]],
    [/mezer|odsaz|margin|padding|\bgap|tesn|daleko|blizko|sirk|vysk|width|height|velik|roztah|zuz/,
      ["margin", "padding", "gap", "min-width", "max-width", "min-height", "max-height", "flex", "align-self", "order"]],
    [/zarovn|stred|vlevo|vpravo|flex|grid|sloup|layout|rozloz|vedle|pod sebou|poradi/,
      ["flex-direction", "flex-wrap", "justify-content", "align-items", "grid-template-columns", "gap", "text-align", "flex", "align-self", "order"]],
  ];

  /** Co způsobuje překryv nebo mezeru mezi cíli — u nich jde ven vždy celé (§4.1). */
  const RELATION_PROPS = ["position", "top", "right", "bottom", "left", "z-index", "transform", "overflow"];

  /** Co věta určila, nebo null, když neurčila nic — to není totéž jako nic. */
  function topics(text, extra) {
    const t = norm(text);
    const wanted = new Set([...ALWAYS, ...(extra || [])]);
    let hit = false;
    for (const [re, props] of TOPICS) {
      if (!re.test(t)) continue;
      hit = true;
      props.forEach((p) => wanted.add(p));
    }
    return hit ? wanted : null;
  }

  function relevant(text, extra) {
    return topics(text, extra) || new Set([...PROPS, ...ALWAYS, ...(extra || [])]);
  }

  const INSET = ["top", "right", "bottom", "left"];
  const COLORED = new Set(["color", "background-color", "border", "box-shadow"]);

  /**
   * `declared` jsou vlastnosti, které někdo opravdu napsal (inline, pravidla).
   * U fixed prvku s `right: 20px` je spočtené `left: 1220px` jen dopočet —
   * ukáže se jen zapsaná strana. Bez znalosti pravidel (cizí sheet) všechny.
   */
  function styles(el, win, declared, wanted) {
    const cs = win.getComputedStyle(el);
    const knownInset = INSET.some((p) => declared.has(p)) || declared.has("inset");
    const out = [];
    for (const p of PROPS) {
      if (!wanted.has(p)) continue;
      let v = cs.getPropertyValue(p).trim();
      if (!v || (DEFAULTS[p] || []).includes(v)) continue;
      if (knownInset && INSET.includes(p) && !declared.has(p) && !declared.has("inset")) continue;
      if (p === "border" && /^0px/.test(v)) continue;
      if (p === "transition" && /^all 0s/.test(v)) continue;
      // Barva tak, jak ji někdo napsal (§4.1): agent grepuje zdroják, ne
      // prohlížeč, a `oklch(0.45 0.01 107)` nenajde ani ve svém stylesheetu.
      if (COLORED.has(p) && declared.get(p)) v = declared.get(p);
      out.push(`${p}: ${v}`);
    }
    return out;
  }

  /**
   * Odkud hodnota je (SPEC §4.1): pravidla ze stylesheetů, která na prvek
   * sedí, i se souborem. Cizí origin bez CORS se přeskočí — vrstva vypadne,
   * prompt je jen chudší.
   */
  /*
   * Reset a normalize (`html, body, div, span, … { margin: 0 }`) sedí na
   * každý prvek a o žádném neřeknou nic — a přitom jsou to stovky znaků,
   * které se platí u každého cíle znovu (§7.6, *totéž dvakrát*). Pozná se
   * podle délky výčtu selektorů: ručně psané pravidlo jich tolik nemá.
   */
  const RESET_SELECTORS = 8;
  const isReset = (selectorText) => String(selectorText).split(",").length > RESET_SELECTORS;

  function rules(el, doc) {
    const win = doc.defaultView;
    const out = [];
    const walk = (list, source) => {
      for (const rule of Array.from(list || [])) {
        if (rule.type === 1) {
          if (isReset(rule.selectorText)) continue;
          if (!safe(() => el.matches(rule.selectorText), false)) continue;
          const css = rule.style.cssText;
          if (css) out.push({ selector: rule.selectorText, css: short(css, MAX_RULE_TEXT), ...source });
        } else if (rule.type === 3 && rule.styleSheet) {
          safe(() => walk(rule.styleSheet.cssRules, basename(rule.styleSheet.href)));
        } else if (rule.type === 4) {
          if (win.matchMedia(rule.conditionText || rule.media.mediaText).matches) walk(rule.cssRules, source);
        } else if (rule.cssRules) {
          walk(rule.cssRules, source);
        }
      }
    };
    for (const sheet of Array.from(doc.styleSheets)) {
      let list = null;
      try { list = sheet.cssRules; } catch (_) { continue; }
      walk(list, basename(sheet.href));
    }
    // Kaskáda: pozdější vyhrává. Když se ořezává, zůstane konec.
    return out.slice(-MAX_RULES);
  }

  /**
   * Jméno souboru bez otisku z buildu — `application-9f2a….css` nikdo
   * negrepne. Otisk je zároveň důkaz, že soubor vyrobil build: jméno po
   * očesání je náš odhad, ne fakt, takže se s ním dál nakládá opatrně (§7.6).
   */
  const FINGERPRINT = /[-.][0-9a-f]{8,64}(?=\.[a-z]+$)/;

  function basename(href) {
    if (!href) return { source: "<style>", built: false };
    const file = href.split("?")[0].split("#")[0].split("/").pop() || href;
    return { source: file.replace(FINGERPRINT, ""), built: FINGERPRINT.test(file) };
  }

  // ---------------------------------------------------------------- okolí

  function surroundings(el, win) {
    const chain = [];
    const controllers = new Set();
    const pick = (node) => {
      const c = node.getAttribute("data-controller");
      if (c) c.split(/\s+/).forEach((x) => controllers.add(x));
    };
    pick(el);
    let node = el.parentElement;
    for (let i = 0; node && node !== node.ownerDocument.documentElement && i < MAX_PARENTS; i++, node = node.parentElement) {
      const entry = { name: name(node) };
      const inline = node.getAttribute("style");
      if (inline) entry.inline = short(inline, MAX_INLINE);
      pick(node);
      chain.push(entry);
    }

    const parent = el.parentElement;
    let layout = null;
    if (parent) {
      const cs = win.getComputedStyle(parent);
      if (cs.display.includes("flex")) layout = `flex ${cs.flexDirection}${cs.flexWrap !== "nowrap" ? " wrap" : ""}`;
      else if (cs.display.includes("grid")) layout = `grid ${short(cs.gridTemplateColumns, 60)}`;
      else layout = cs.display;
    }
    const frame = el.closest("turbo-frame");
    const siblings = parent ? Array.from(parent.children) : [];
    return {
      chain, layout, controllers: [...controllers],
      frame: frame && frame.id ? frame.id : null,
      siblings: siblings.length, index: siblings.indexOf(el) + 1,
      prev: el.previousElementSibling ? name(el.previousElementSibling) : null,
      next: el.nextElementSibling ? name(el.nextElementSibling) : null,
    };
  }

  // -------------------------------------------------------------- kontext

  // ---------------------------------------------------------- médium (§2.8)

  // Odkaz je klíč ke stažení — useknutý v půlce je k ničemu, tak má víc místa.
  const MAX_SRC = 300;

  /** Přípona z odkazu, nebo typ z `data:` — formát, ne obsah. */
  function format(src) {
    const data = /^data:([\w.+-]+)\/([\w.+-]+)/.exec(src || "");
    if (data) return data[2].toLowerCase();
    const path = String(src || "").split(/[?#]/)[0];
    const ext = /\.([a-z0-9]{2,5})$/i.exec(path);
    return ext ? ext[1].toLowerCase() : null;
  }

  const KB = (n) => (n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} kB`);

  /*
   * Velikost z Resource Timing — tedy z toho, co o odpovědi ví prohlížeč.
   * Cizí server bez `Timing-Allow-Origin` vydá nulu; pak vrstva vypadne
   * (zásada 5). Odhadnout velikost z rozměrů by bylo hádání (zásada 8).
   */
  function bytesOf(src, win) {
    const perf = win && win.performance;
    if (!perf || !perf.getEntriesByName || !src || /^data:/.test(src)) return null;
    const hits = perf.getEntriesByName(src);
    const last = hits[hits.length - 1];
    const n = last && (last.encodedBodySize || last.transferSize);
    return n > 0 ? n : null;
  }

  /*
   * Síťový přenos stránky (§7.6) — volitelná vrstva, kterou si povrch vyžádá.
   * Bere se z Resource Timing, tedy z toho, co o odpovědích ví prohlížeč: žádné
   * odchytávání requestů, žádný proxy. Cizí server bez `Timing-Allow-Origin`
   * velikost nevydá — takový požadavek se spočítá zvlášť a nehádá se (zásada 8).
   *
   * Je to snímek okamžiku, kdy se zadávalo, a platí pro stránku, na které
   * uživatel stojí — jiné stránce ho přilepit nejde, její entries už prohlížeč
   * nemá. Když se nedá zjistit nic, vrstva vypadne a prompt je jen chudší.
   */
  const KIND = {
    script: "script", css: "css", link: "css", img: "obrázky", image: "obrázky",
    font: "fonty", xmlhttprequest: "xhr", fetch: "fetch", beacon: "beacon",
    iframe: "iframe", video: "video", audio: "audio",
  };

  function network(win, opts) {
    const perf = win && win.performance;
    if (!perf || !perf.getEntriesByType) return null;
    const res = perf.getEntriesByType("resource") || [];
    if (!res.length) return null;

    const host = safe(() => win.location.host, "");
    const kinds = new Map();
    const origins = new Map();
    let bytes = 0, unknown = 0;
    const big = [];

    for (const r of res) {
      const kind = KIND[r.initiatorType] || r.initiatorType || "jiné";
      const size = r.encodedBodySize || r.transferSize || 0;
      const at = kinds.get(kind) || { n: 0, bytes: 0 };
      at.n += 1; at.bytes += size;
      kinds.set(kind, at);
      if (size > 0) { bytes += size; big.push({ size, kind, url: r.name }); } else unknown += 1;
      const origin = safe(() => new win.URL(r.name).host, "");
      if (origin && origin !== host) origins.set(origin, (origins.get(origin) || 0) + 1);
    }

    const nav = (safe(() => perf.getEntriesByType("navigation"), []) || [])[0] || null;
    return {
      requests: res.length, bytes, unknown,
      kinds: [...kinds].sort((a, b) => b[1].bytes - a[1].bytes),
      origins: [...origins].sort((a, b) => b[1] - a[1]).slice(0, 6),
      big: big.sort((a, b) => b.size - a.size).slice(0, 3),
      timing: nav ? {
        ttfb: round(nav.responseStart),
        dom: round(nav.domContentLoadedEventEnd),
        load: round(nav.loadEventEnd) || null,
      } : null,
      vitals: safe(() => vitals(win), null),
      // Čí je to číslo: čisté měření od načtení, nebo součet toho, co se nasbíralo
      // za procházení. Rozdíl je informace, ne detail — viz `renderNetwork` (§4.6).
      measured: !!(opts && opts.measured),
    };
  }

  const MS = (n) => (n >= 1000 ? `${(n / 1000).toFixed(1)} s` : `${n} ms`);

  /** Naše vlastní vrstva se do metrik stránky nepočítá — měřili bychom sebe. */
  const OURS = "#weed-root, #weed-overlay, #weed-marks";
  const ours = (node) => {
    const el = node && node.nodeType === 1 ? node : node && node.parentElement;
    return !el || !el.isConnected || !!safe(() => el.closest(OURS), false);
  };

  /*
   * Sběrač musí startovat s paletou, ne až u zadání: LCP ani posuny nejsou
   * v timeline prohlížeče k vyzvednutí, vydá je jen `PerformanceObserver`.
   * `buffered: true` dodá i to, co se stalo před ním — proto načtení nezmeškáme,
   * i když se jádro vloží až po něm.
   *
   * Drží se součty a nejhorší případy, ne osa — kdo nechá kartu otevřenou půl
   * dne, by jinak platil pamětí za data, která nikdo nepřečte.
   */
  const BLAME = 50;
  let box = null;

  function watchVitals(win) {
    if (box) return box;
    const PO = win && win.PerformanceObserver;
    if (!PO) return null;
    const at = { lcp: null, cls: 0, blame: new Map(), event: null };
    const on = (type, fn) => {
      // Typ, který prohlížeč neumí, vezme s sebou jeden řádek, ne vrstvu (zásada 5).
      try {
        new PO((list) => { for (const e of list.getEntries()) safe(() => fn(e), null); })
          .observe({ type, buffered: true });
      } catch (_) { /* řádek chybí */ }
    };
    on("largest-contentful-paint", (e) => { at.lcp = e; });
    on("layout-shift", (e) => {
      // `hadRecentInput` odděluje skok po načtení fontu od menu, které si uživatel rozbalil sám.
      if (e.hadRecentInput) return;
      at.cls += e.value || 0;
      for (const src of e.sources || []) {
        const el = src.node && (src.node.nodeType === 1 ? src.node : src.node.parentElement);
        if (!el || (!at.blame.has(el) && at.blame.size >= BLAME)) continue;
        at.blame.set(el, (at.blame.get(el) || 0) + (e.value || 0));
      }
    });
    on("event", (e) => { if (e.duration > 0 && (!at.event || e.duration > at.event.duration)) at.event = e; });
    box = at;
    return box;
  }

  /*
   * Jak to dopadlo na obrazovce (§4.6). Přenos říká, co se stáhlo; tohle říká,
   * co z toho uživatel pocítil — a hlavně **na kterém prvku**.
   *
   * Číslo samo je diagnóza bez adresy: z „LCP 3,2 s“ agent nepozná, kam sáhnout.
   * Největší vykreslený prvek je ale prvek na stránce a dostane tutéž kotvu jako
   * každý jiný cíl (§4.1) — to je vrstva, kterou nikdo jiný nesloží: agent má
   * zdroják a ne běžící stránku, měřicí služba stránku a ne kotvy do zadání.
   */
  function vitals(win) {
    const at = box || safe(() => watchVitals(win), null);
    if (!at) return null;
    const doc = win && win.document;
    const out = {};

    const mark = (el) => {
      if (!el || ours(el)) return null;
      return {
        tag: el.localName || null,
        anchor: safe(() => Core.anchorFor(el), null),
        selector: safe(() => selector(el, doc), null),
      };
    };

    if (at.lcp) {
      out.lcp = {
        ms: round(at.lcp.startTime),
        bytes: at.lcp.size || 0,
        url: at.lcp.url || null,
        at: safe(() => mark(at.lcp.element), null),
      };
    }
    if (at.cls > 0) {
      out.cls = {
        value: at.cls,
        worst: [...at.blame].sort((a, b) => b[1] - a[1]).slice(0, 3)
          .map(([el]) => safe(() => mark(el), null)).filter(Boolean),
      };
    }
    /*
     * Nejdelší reakce, ne INP: INP je percentil z celé návštěvy a z pěti kliknutí
     * ho spočítat nejde. Říct číslu jméno, které nemá, je horší než mlčet (zásada 8).
     */
    if (at.event) {
      out.event = { ms: round(at.event.duration), name: at.event.name, at: safe(() => mark(at.event.target), null) };
    }

    return Object.keys(out).length ? out : null;
  }

  /** 1 požadavek, 2 požadavky, 5 požadavků — číslo v promptu je taky čeština. */
  const REQS = (n) => `${n} ${n === 1 ? "požadavek" : n < 5 ? "požadavky" : "požadavků"}`;

  /*
   * Ven jde `<details>` — je to podklad, ne zadání, a nemá zabírat půlku
   * dokumentu ani v promptu, ani v panelu. Markdown uvnitř zůstává markdownem:
   * prázdný řádek za `<summary>` je to, co ho nechá vykreslit.
   */
  function renderNetwork(req) {
    const n = req.network;
    if (!n || !n.requests) return null;
    const out = [
      "<details>",
      `<summary>Síťový přenos — ${REQS(n.requests)}, ${KB(n.bytes)}</summary>`,
      "",
    ];
    if (n.timing) {
      const t = [`TTFB ${MS(n.timing.ttfb)}`, `DOMContentLoaded ${MS(n.timing.dom)}`];
      if (n.timing.load) t.push(`load ${MS(n.timing.load)}`);
      out.push(`- načtení: ${t.join(" · ")}`);
    }
    out.push(`- podle typu: ${n.kinds.map(([k, v]) => `${k} ${v.n}× ${KB(v.bytes)}`).join(" · ")}`);
    if (n.big.length) out.push(`- největší: ${n.big.map((b) => `${KB(b.size)} \`${short(b.url, 90)}\``).join(" · ")}`);
    if (n.origins.length) out.push(`- cizí původy: ${n.origins.map(([o, c]) => `${o} ${c}×`).join(" · ")}`);
    if (n.unknown) out.push(`- bez velikosti: ${REQS(n.unknown)} — cizí server nepustil \`Timing-Allow-Origin\``);
    out.push(...renderVitals(n.vitals));
    // Čí je to číslo. Agent, který dostane součet relace jako cenu načtení,
    // opravuje něco jiného, než měl (zásada 8) — takže se to řekne u čísel samých.
    out.push(n.measured
      ? "- měřeno načtením stránky, čísla jsou od čistého začátku"
      : "- posbíráno za chodu, ne měřeno od načtení — co si uživatel proklikal, je v součtu také");
    out.push("", "</details>");
    return out;
  }

  /** Kotva prvku tak, jak ji zná zbytek promptu — jméno a k němu selektor. */
  function where(at) {
    if (!at) return null;
    const bits = [anchorName(at.anchor)];
    if (at.selector) bits.push(`\`${at.selector}\``);
    return bits.join(" · ");
  }

  /*
   * Číslo s prstem ukázaným na prvek (§4.6). Kde prvek není — LCP z cizího
   * originů, uzel, který mezitím zmizel — jde ven číslo samo; připsat mu prvek,
   * který není doložený, by bylo hádání (zásada 8).
   */
  function renderVitals(v) {
    if (!v) return [];
    const out = [];
    if (v.lcp) {
      const bits = [MS(v.lcp.ms)];
      const at = where(v.lcp.at);
      if (at) bits.push(at);
      if (v.lcp.bytes) bits.push(KB(v.lcp.bytes));
      if (v.lcp.url) bits.push(`\`${short(v.lcp.url, 90)}\``);
      out.push(`- největší vykreslený prvek: ${bits.join(" · ")}`);
    }
    if (v.cls) {
      const who = v.cls.worst.map(where).filter(Boolean);
      out.push(`- posuny obsahu: CLS ${v.cls.value.toFixed(2)}${who.length ? ` — nejvíc ${who.join(" · ")}` : ""}`);
    }
    if (v.event) {
      const at = where(v.event.at);
      out.push(`- nejdelší reakce: ${MS(v.event.ms)} na \`${v.event.name}\`${at ? ` · ${at}` : ""}`);
    }
    return out;
  }

  /*
   * Popis média, ne médium samo. Do promptu jde odkaz, rozměry a to, jak je
   * obrázek vsazený; soubor ne — fotka z telefonu má megabajty a mění se kód
   * kolem ní, ne ona (zásada 6). Kdo ho potřebuje, stáhne si ho z odkazu.
   *
   * Tři případy, a každý se ukazuje jinak (§2.8): u rastru místem v obraze,
   * u inline SVG elementem uvnitř — proto `svg-part` není chyba, ale ten
   * nejlepší případ: cíl má kotvu a souřadnice nejsou potřeba.
   */
  function media(el, win) {
    const tag = localName(el);
    const box = el.getBoundingClientRect();
    const rendered = { width: round(box.width), height: round(box.height) };

    if (tag === "svg") {
      return {
        kind: "svg", src: null, rendered,
        viewBox: el.getAttribute("viewBox") || null,
        parts: el.querySelectorAll("path, rect, circle, ellipse, line, polyline, polygon, text, g, use").length,
      };
    }
    if (el.ownerSVGElement) {
      const owner = el.ownerSVGElement;
      return { kind: "svg-part", src: null, rendered, of: name(owner), viewBox: owner.getAttribute("viewBox") || null };
    }

    const img = tag === "img" ? el : tag === "picture" ? el.querySelector("img") : null;
    if (!img) return null;

    const src = img.currentSrc || img.getAttribute("src") || "";
    const cs = win ? win.getComputedStyle(img) : null;
    const attr = (n) => img.getAttribute(n);
    const out = {
      kind: "image",
      src: short(src, MAX_SRC),
      format: format(src),
      bytes: bytesOf(src, win),
      // Přirozené rozměry zná prohlížeč až po načtení; nula znamená „ještě ne“.
      natural: img.naturalWidth ? { width: img.naturalWidth, height: img.naturalHeight } : null,
      rendered: tag === "picture" ? { width: round(img.getBoundingClientRect().width), height: round(img.getBoundingClientRect().height) } : rendered,
      fit: cs && cs.objectFit !== "fill" ? cs.objectFit : null,
      position: cs && cs.objectPosition !== "50% 50%" ? cs.objectPosition : null,
      // Kolik variant si prohlížeč měl z čeho vybrat — celý srcset je dlouhý a v atributech cíle už je.
      variants: (attr("srcset") || (tag === "picture" ? Array.from(el.querySelectorAll("source")).map((s) => s.getAttribute("srcset")).join(",") : "")).split(",").filter((x) => x.trim()).length || null,
      loading: attr("loading"),
      // Chybějící alt je taky informace — a často to, co se má zadáním spravit.
      alt: attr("alt") ? short(attr("alt"), MAX_ATTR) : null,
      noAlt: attr("alt") === null,
    };
    return out;
  }

  /*
   * Kam se obraz v boxu vykreslí: `object-fit` říká měřítko, `object-position`
   * posun. Procenta i pixely; cokoliv jiného se nepřekládá a místo v obraze
   * se pak nespočítá — raději méně než vedle (zásada 8).
   */
  function placement(img, win) {
    const cs = win.getComputedStyle(img);
    const box = img.getBoundingClientRect();
    const px = (v) => parseFloat(v) || 0;
    const left = px(cs.borderLeftWidth) + px(cs.paddingLeft);
    const top = px(cs.borderTopWidth) + px(cs.paddingTop);
    const cw = box.width - left - px(cs.borderRightWidth) - px(cs.paddingRight);
    const ch = box.height - top - px(cs.borderBottomWidth) - px(cs.paddingBottom);
    const nw = img.naturalWidth, nh = img.naturalHeight;
    if (!nw || !nh || cw <= 0 || ch <= 0) return null;

    const fit = cs.objectFit || "fill";
    let sx = cw / nw, sy = ch / nh;
    if (fit === "contain" || fit === "scale-down") {
      const s = fit === "scale-down" ? Math.min(1, Math.min(sx, sy)) : Math.min(sx, sy);
      sx = sy = s;
    } else if (fit === "cover") {
      sx = sy = Math.max(sx, sy);
    } else if (fit === "none") {
      sx = sy = 1;
    }

    const parts = String(cs.objectPosition || "50% 50%").trim().split(/\s+/);
    if (parts.length !== 2) return null;
    const free = [cw - nw * sx, ch - nh * sy];
    const offset = parts.map((v, i) => {
      if (/%$/.test(v)) return (parseFloat(v) / 100) * free[i];
      if (/px$/.test(v)) return parseFloat(v);
      return null;
    });
    if (offset.some((v) => v === null || !isFinite(v))) return null;

    return { x: box.left + left + offset[0], y: box.top + top + offset[1], sx, sy, nw, nh, box, left, top, cw, ch };
  }

  const ratio = (v) => Math.round(v * 1000) / 1000;

  /*
   * Místo, které uživatel ukázal v obraze (§2.8). Povrch pošle klientské
   * souřadnice — kde se prst dotkl —, přepočet dělá jádro: poměr k boxu
   * vždycky, poměr a pixely v obraze jen tehdy, když jde spočítat, kam se
   * obraz v boxu vykreslil. **Pixel z obrazovky ven nejde**: obrázek
   * vykreslený na 320 px má přirozených 2400 a agent by mířil o řád vedle.
   */
  function spotFor(el, win, spot) {
    if (!spot || !win) return null;
    const img = localName(el) === "picture" ? el.querySelector("img") : el;
    if (!img) return null;
    const box = img.getBoundingClientRect();
    if (!box.width || !box.height) return null;

    const w = Number(spot.w) > 0 ? Number(spot.w) : 0;
    const h = Number(spot.h) > 0 ? Number(spot.h) : 0;
    const clamp = (v) => Math.min(1, Math.max(0, v));
    const inBox = {
      x: ratio(clamp((Number(spot.x) - box.left) / box.width)),
      y: ratio(clamp((Number(spot.y) - box.top) / box.height)),
    };
    if (w && h) {
      inBox.w = ratio(clamp(w / box.width));
      inBox.h = ratio(clamp(h / box.height));
    }
    const out = { box: inBox, image: null, px: null };

    const p = safe(() => placement(img, win), null);
    if (!p) return out;
    const ix = (Number(spot.x) - p.x) / p.sx;
    const iy = (Number(spot.y) - p.y) / p.sy;
    // Na prázdném pásu vedle obrazu (contain) není co ukázat — a nehádá se,
    // který okraj uživatel myslel.
    if (ix < 0 || iy < 0 || ix > p.nw || iy > p.nh) return out;
    out.image = { x: ratio(ix / p.nw), y: ratio(iy / p.nh) };
    out.px = { x: round(ix), y: round(iy) };
    if (w && h) {
      out.image.w = ratio(Math.min(1, w / p.sx / p.nw));
      out.image.h = ratio(Math.min(1, h / p.sy / p.nh));
      out.px.w = round(Math.min(p.nw - ix, w / p.sx));
      out.px.h = round(Math.min(p.nh - iy, h / p.sy));
    }
    return out;
  }

  function context(el, doc, text, extra) {
    const d = doc || el.ownerDocument;
    const win = d.defaultView;
    const inline = safe(() => short(el.getAttribute("style"), MAX_INLINE), "") || null;
    /*
     * Značka v hlavičce se nevykresluje (§2.10). Box má nulový, spočtené styly
     * zdědila z `head { display: none }` a jediné CSS pravidlo, které na ni
     * sedí, bývá `*`. Ven by z toho vyšlo *kde hledat: `<style>`* — kontext,
     * který agenta pošle do stylů kvůli `og:image` a stojí víc, než kdyby
     * hledal sám (zásada 8). Vrstvy vykreslení proto vypadnou celé; `og:image`
     * se mění v šabloně, ne v CSS.
     */
    const unrendered = safe(() => !!el.closest("head"), false);
    const matched = unrendered ? [] : safe(() => rules(el, d), []);
    /*
     * Co někdo opravdu napsal, a s jakou hodnotou. Když ji píšou dvě pravidla
     * různě, nevíme, které vyhrálo — hodnota je null a ven jde spočtená.
     * Buď jistota, nebo dál doslova (zásada 8). Inline je výjimka: ten vyhrává.
     */
    const declared = new Map();
    const note = (css, wins) => {
      for (const part of String(css || "").split(";")) {
        const i = part.indexOf(":");
        const prop = (i < 0 ? part : part.slice(0, i)).trim();
        if (!prop) continue;
        const value = i < 0 ? null : part.slice(i + 1).trim();
        if (wins || !declared.has(prop)) declared.set(prop, value);
        else if (declared.get(prop) !== value) declared.set(prop, null);
      }
    };
    matched.forEach((r) => note(r.css, false));
    note(inline, true);
    return {
      selector: safe(() => selector(el, d), name(el)),
      identity: safe(() => identity(el), { tag: el.tagName.toLowerCase(), id: null, classes: [], attrs: [], text: "" }),
      geometry: unrendered ? null : safe(() => geometry(el, win), null),
      styles: unrendered ? [] : safe(() => styles(el, win, declared, relevant(text, extra)), []),
      inline,
      rules: matched,
      around: unrendered ? null : safe(() => surroundings(el, win), null),
      media: unrendered ? null : safe(() => media(el, win), null),
      // Obsah, nebo kód (§4.4) — první otázka agenta a nejdražší chyba, kterou umíme udělat.
      origin: safe(() => Core.origin(el, d), null),
    };
  }

  /**
   * Co mezi cíli platí: kdo je v kom, kdo je čí sourozenec, kdo se s kým
   * překrývá a o kolik, nebo jak daleko a kterým směrem od sebe jsou. Je to
   * aritmetika nad boxy, bez modelu. Kdo je nahoře se neodvozuje ze z-indexu,
   * ten je jen půlka pravdy; ptáme se prohlížeče, co v místě průniku vidí.
   */
  function relations(elements, doc) {
    const d = doc || document;
    const out = [];
    for (let i = 0; i < elements.length; i++) {
      for (let j = i + 1; j < elements.length; j++) {
        const a = elements[i], b = elements[j];
        const rel = { a: i + 1, b: j + 1 };
        if (a.contains(b)) rel.inside = "b";
        else if (b.contains(a)) rel.inside = "a";
        else if (a.parentElement && a.parentElement === b.parentElement) rel.siblings = true;

        const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
        const w = Math.min(ra.right, rb.right) - Math.max(ra.left, rb.left);
        const h = Math.min(ra.bottom, rb.bottom) - Math.max(ra.top, rb.top);
        if (rel.inside) {
          // nic dalšího — poloha uvnitř rodiče je vidět z boxů
        } else if (w > 0 && h > 0) {
          rel.overlap = { width: round(w), height: round(h) };
          const cx = Math.max(ra.left, rb.left) + w / 2, cy = Math.max(ra.top, rb.top) + h / 2;
          for (const node of safe(() => d.elementsFromPoint(cx, cy), [])) {
            if (a.contains(node)) { rel.top = "a"; break; }
            if (b.contains(node)) { rel.top = "b"; break; }
          }
        } else {
          // mezera po osách: kladná = b je vpravo / pod a, záporná = vlevo / nad; 0 = na té ose se kryjí
          const dx = rb.left >= ra.right ? rb.left - ra.right : ra.left >= rb.right ? -(ra.left - rb.right) : 0;
          const dy = rb.top >= ra.bottom ? rb.top - ra.bottom : ra.top >= rb.bottom ? -(ra.top - rb.bottom) : 0;
          rel.apart = { dx: round(dx), dy: round(dy) };
        }
        out.push(rel);
      }
    }
    return out;
  }

  // -------------------------------------------------------------- stránka

  function stack(doc) {
    const d = doc || document, win = d.defaultView;
    const has = (s) => !!d.querySelector(s);
    const out = [];
    if (has('meta[name="csrf-param"]')) out.push("Rails");
    if (win.Turbo || has('meta[name^="turbo-"], turbo-frame')) out.push("Turbo");
    if (has("[data-controller]")) out.push("Stimulus");
    if (has("[hx-get], [hx-post], [hx-target]")) out.push("htmx");
    if (win.__NEXT_DATA__) out.push("Next");
    else if (has("[data-reactroot], [data-react-helmet]") || Object.keys(win).some((k) => k.startsWith("__REACT_DEVTOOLS"))) out.push("React");
    if (win.__NUXT__) out.push("Nuxt");
    else if (has("[data-v-app], [data-server-rendered]")) out.push("Vue");
    if (has("[ng-version]")) out.push("Angular");
    if (has("[data-svelte-h], [class*='svelte-']")) out.push("Svelte");
    return out;
  }

  // ------------------------------------------- náhled pro sdílení (§2.10)

  /*
   * Co ze stránky uvidí ten, komu se pošle odkaz. Není to obsah stránky, je to
   * hlavička: `og:*`, `twitter:*` a to, co scrapery berou, když chybí. Pořadí
   * zdrojů je pořadí, ve kterém hledají oni — kdo čte jinak, uvidí jinou kartu,
   * a tohle je ta nejčastější.
   *
   * Každé pole nese, **odkud se vzalo**: banner bez toho je hezký obrázek, ze
   * kterého se nepozná, který tag se má změnit. Co chybí, se nedopočítává ani
   * nehádá (zásada 8) — chybějící pole je samo o sobě nález, protože právě tak
   * bude vypadat odkaz v cizí konverzaci.
   */
  const SHARE_SLOTS = [
    { slot: "title", name: "og:title", key: true, from: ['meta[property="og:title"]', 'meta[name="twitter:title"]', "title"] },
    { slot: "description", name: "og:description", key: true, from: ['meta[property="og:description"]', 'meta[name="twitter:description"]', 'meta[name="description"]'] },
    { slot: "image", name: "og:image", key: true, from: ['meta[property="og:image:secure_url"]', 'meta[property="og:image"]', 'meta[name="twitter:image"]'], url: true },
    { slot: "imageAlt", name: "og:image:alt", from: ['meta[property="og:image:alt"]', 'meta[name="twitter:image:alt"]'] },
    { slot: "site", name: "og:site_name", from: ['meta[property="og:site_name"]', 'meta[name="application-name"]'] },
    { slot: "url", name: "og:url", from: ['meta[property="og:url"]', 'link[rel="canonical"]'], url: true },
    { slot: "card", name: "twitter:card", from: ['meta[name="twitter:card"]'] },
    { slot: "type", name: "og:type", from: ['meta[property="og:type"]'] },
    { slot: "icon", name: "favicon", from: ['link[rel="apple-touch-icon"]', 'link[rel="icon"]', 'link[rel="shortcut icon"]'], url: true },
  ];

  /** Hodnota tagu podle jeho druhu — `content`, `href`, nebo text `<title>`. */
  function metaValue(el) {
    const raw = el.tagName === "TITLE" ? el.textContent : (el.getAttribute("content") || el.getAttribute("href") || "");
    return String(raw || "").trim().replace(/\s+/g, " ");
  }

  /** Jméno tagu tak, jak ho člověk hledá ve zdrojáku: `og:image`, `<title>`. */
  function metaName(el) {
    const key = el.getAttribute("property") || el.getAttribute("name");
    if (key) return key;
    if (el.tagName === "LINK") return `rel=${el.getAttribute("rel")}`;
    return `<${el.tagName.toLowerCase()}>`;
  }

  function share(doc) {
    const d = doc || document;
    const here = d.location.href;
    const absolute = (value) => safe(() => new URL(value, here).href, value);
    const fields = {};
    const missing = [];
    for (const spec of SHARE_SLOTS) {
      let found = null;
      for (const query of spec.from) {
        const el = safe(() => d.querySelector(query), null);
        if (!el) continue;
        const value = metaValue(el);
        if (!value) continue;
        found = {
          value: spec.url ? absolute(value) : short(value, MAX_SHARE_TEXT),
          source: metaName(el),
          // Selektor, kterým se tag našel, je i ten, kterým se dá vybrat jako
          // cíl — a je čitelný: `meta[property="og:image"]` řekne člověku i
          // agentovi totéž. Obecný selektor až tehdy, když by query sedla na
          // víc tagů; dva `og:image` v hlavičce jsou samy o sobě nález.
          selector: safe(() => (d.querySelectorAll(query).length === 1 ? query : selector(el, d)), null),
        };
        break;
      }
      if (found) fields[spec.slot] = found;
      // Hlásí se jen to, z čeho je karta — `og:type` nebo `twitter:card` nechybí
      // nikomu a řádek pod kartou má být přečtený, ne dlouhý.
      else if (spec.key) missing.push(spec.name);
    }
    return {
      url: here,
      host: safe(() => d.location.host, ""),
      // Titulek dokumentu vedle pole: karta ho použije, když `og:title` chybí,
      // a rozdíl mezi nimi je sám o sobě vidět.
      documentTitle: short(d.title || "", MAX_SHARE_TEXT),
      fields,
      missing,
    };
  }

  function page(doc) {
    const d = doc || document, win = d.defaultView;
    return {
      url: d.location.href,
      title: d.title,
      // Na čem web běží (§4.4): tichá detekce, nikdo se neptá. Text do hlavičky promptu.
      platform: safe(() => (Core.platform(d) || {}).name, null),
      stack: safe(() => stack(d), []),
      viewport: { width: win.innerWidth, height: win.innerHeight, dpr: win.devicePixelRatio || 1 },
      scroll: { x: Math.round(win.scrollX), y: Math.round(win.scrollY) },
      document: { width: d.documentElement.scrollWidth, height: d.documentElement.scrollHeight },
      scheme: win.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light",
      /*
       * Co Web Editor na stránce vidí a agent ne (§4.5). Počítá se tady, při vzniku
       * požadavku — ne při renderu: seznam se skládá dnes a kopíruje zítra,
       * a to už může být stránka jinde.
       */
      typeScale: safe(() => Core.scale(d), null),
      palette: safe(() => Core.colors(d), null),
    };
  }

  // ------------------------------------------------------ požadavek (§2.5)

  /*
   * Jeden tvar pro to, co uživatel ukázal a řekl. Rodí se tady, v prohlížeči;
   * worker/ ho přebírá. Cíl je kotva; kontext vedle ní je to, z čeho
   * se dnes skládá prompt — a kdo balíček nestaví, si ho nemusí platit
   * (context: false). Snímek (§4.3) má hlavičku a strom: ve fázi 1 jen
   * hlavičku, strom je null — tvar požadavku se s ním pak nemění. PM překlad
   * (§5) je null — fáze 2. Nic odvozeného tu není.
   */
  const uid = (prefix) => `${prefix}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

  /*
   * Strom stránky, jak ho uvidí agent (§4.3). Reálný DOM je tady vedle nás,
   * agent má jen tohle — a každý kilobajt je token, takže se ořezává:
   *
   * - pryč, co není vidět, a skripty a styly, které nejsou obsah
   * - prázdný obal zmizí; řádek bez informace je řádek za peníze
   * - vzorek místo výčtu: z padesáti položek dvě a počet
   * - zkrácené texty — dlouhý odstavec se pozná podle začátku
   * - okolí cíle podrobně, zbytek stránky jen jako kostra
   *
   * Styly tu nejsou schválně: relevantní styl předpokládá rozumět zadání
   * a ten předpoklad se platí dvakrát (zásada 8). Kontext u cíle je nese
   * a druhé kolo si o víc řekne levným dotazem do prohlížeče.
   */
  const SNAP_NODES = 120;      // strop uzlů: snímek je největší kus balíčku (§7.3)
  const SNAP_TEXT = 40;
  const SNAP_SAMPLE = 2;       // kolik stejných sourozenců se vypíše
  const SNAP_MANY = 4;         // od kolika je to výčet, ne pár prvků vedle sebe
  const SNAP_SKELETON = 3;     // kostra končí v téhle hloubce
  const SNAP_AROUND = 2;       // pod cílem se jde ještě o tolik pater
  const SNAP_SKIP = new Set(["script", "style", "noscript", "template", "link", "meta", "title", "br"]);

  function ownText(el) {
    let out = "";
    for (const node of el.childNodes) if (node.nodeType === 3) out += node.nodeValue;
    return out.replace(/\s+/g, " ").trim();
  }

  /** Podpis tvaru — sourozenci, kteří se liší jen obsahem, mají stejný (§4.4). */
  const shapeOf = (el) => `${el.localName}.${classes(el).slice(0, MAX_CLASSES).join(".")}`;

  const named = (el) =>
    !!(el.id || el.getAttribute("data-testid") || el.getAttribute("data-test") || el.getAttribute("aria-label"));

  function tree(doc, targets) {
    const d = doc || document;
    const win = d.defaultView || root;
    const from = d.body || d.documentElement;
    if (!from) return null;

    const marks = new Set();
    const path = new Set();
    for (const el of targets || []) {
      if (!el || !el.isConnected || !el.parentElement) continue;
      marks.add(el);
      for (let p = el.parentElement; p; p = p.parentElement) path.add(p);
    }

    let budget = SNAP_NODES;
    let cut = 0;

    const walk = (el, depth, under) => {
      if (budget <= 0) { cut++; return null; }
      if (SNAP_SKIP.has(el.localName)) return null;
      if (!safe(() => {
        const cs = win.getComputedStyle(el);
        return cs.display !== "none" && cs.visibility !== "hidden";
      }, true)) return null;

      const target = marks.has(el);
      const onPath = path.has(el);
      // Kolik pater pod cílem jsme; `null` znamená, že cíl nad sebou nemáme.
      const below = target ? 0 : under == null ? null : under + 1;
      if (!target && !onPath && !(below != null && below <= SNAP_AROUND) && depth > SNAP_SKELETON) {
        cut++;
        return null;
      }

      const kids = Array.from(el.children).filter((k) => !SNAP_SKIP.has(k.localName));
      const text = ownText(el);
      // Prázdný obal se přeskočí, ne zapíše: `div > div > p` je jedna
      // informace, ne tři. Platí to i nad cílem — obal kolem něj nenese nic,
      // co by agent potřeboval. Hloubka se tím nezvyšuje, uzel neexistuje.
      if (!target && !text && kids.length === 1 && !named(el) && !classes(el).length) {
        return walk(kids[0], depth, below);
      }

      budget--;
      const node = { tag: el.localName, anchor: safe(() => Core.anchorFor(el), null) };
      const cls = classes(el)[0];
      if (cls) node.cls = cls;
      if (text) node.text = short(text, SNAP_TEXT);
      if (target) node.target = true;

      const shapes = new Map();
      for (const kid of kids) {
        const key = shapeOf(kid);
        if (!shapes.has(key)) shapes.set(key, []);
        shapes.get(key).push(kid);
      }
      const children = [];
      for (const same of shapes.values()) {
        const many = same.length >= SNAP_MANY;
        // Z výčtu jdou dovnitř první dva — a cíl, i kdyby byl padesátý:
        // vzorek, ve kterém chybí to, na co uživatel ukázal, je k ničemu.
        const take = many ? same.filter((k, i) => i < SNAP_SAMPLE || marks.has(k) || path.has(k)) : same;
        for (const kid of take) {
          const child = walk(kid, depth + 1, below);
          if (child) children.push(child);
        }
        if (many && take.length < same.length) {
          children.push({ tag: same[0].localName, more: same.length - take.length });
        }
      }
      if (children.length) node.children = children;
      return node;
    };

    const built = walk(from, 0, null);
    return built ? { root: built, nodes: SNAP_NODES - budget, cut } : null;
  }

  /*
   * Jméno uzlu ve výpisu. Schválně ne `anchorName` — ta sahá po textu prvku,
   * a text obalu je text jeho potomků: `div „Tohle je odstavec…"` nad tímtéž
   * odstavcem je řádek, který platíme dvakrát a nic nového neříká.
   */
  function nodeName(node) {
    const a = node.anchor || {};
    if (a.testid) return `${node.tag}[data-testid="${a.testid}"]`;
    if (a.id) return `${node.tag}#${a.id}`;
    if (a.label) return `${node.tag}[aria-label="${short(a.label, 40)}"]`;
    return node.cls ? `${node.tag}.${node.cls}` : node.tag;
  }

  /** Strom na řádky. Tohle je tvar, který se platí — na něm se měří (§7.3). */
  function renderTree(node, depth, out) {
    const lines = out || [];
    if (!node) return lines.join("\n");
    const pad = "  ".repeat(depth || 0);
    if (node.more) lines.push(`${pad}- … a dalších ${node.more}× ${node.tag}`);
    else {
      lines.push(`${pad}- ${nodeName(node)}${node.text ? ` „${node.text}“` : ""}${node.target ? "  ← cíl" : ""}`);
      for (const kid of node.children || []) renderTree(kid, (depth || 0) + 1, lines);
    }
    return lines.join("\n");
  }

  /*
   * Hlavička vzniká vždycky, strom jen když si ho někdo staví: `targets`
   * je `null` u požadavku, který balíček nestaví (`context: false`), a ten
   * si pak procházku stránkou nemá proč platit.
   */
  function snapshot(doc, targets) {
    const built = targets ? safe(() => tree(doc, targets), null) : null;
    const text = built ? safe(() => renderTree(built.root, 0), "") : "";
    return {
      id: uid("s"),
      page: safe(() => page(doc), null),
      tree: built ? built.root : null,
      // Velikost snímku je přímo cena zadání (§4.3), a měří se ve znacích,
      // které odejdou — ne v uzlech. Uzel s odstavcem stojí desetkrát víc
      // než uzel s prázdným divem.
      chars: text.length,
      nodes: built ? built.nodes : 0,
      // Co se do stropu nevešlo. Nula znamená celou stránku, ne úspěch —
      // useknutý snímek se musí poznat, ne tvářit se jako celý (zásada 8).
      cut: built ? built.cut : 0,
    };
  }

  function request(opts) {
    const d = opts.doc || document;
    const elements = (opts.elements || []).filter((el) => el && el.isConnected);
    const text = String(opts.text || "").trim();
    const rels = safe(() => relations(elements, d), []);
    // u cílů, které se překrývají nebo mají mezeru, jde ven celá sada vlastností, které to způsobují
    const related = new Set();
    for (const r of rels) if (r.overlap || r.apart) { related.add(r.a - 1); related.add(r.b - 1); }
    return {
      id: opts.id || uid("r"),
      web: { url: d.location.href, title: d.title },
      targets: elements.map((el, i) => ({
        anchor: Core.anchorFor(el),
        // Úsek textu, který uživatel označil uvnitř cíle (§2.1) — prázdné pole
        // znamená celý prvek. Pořadí výskytu je součást úseku: „cena“ bývá
        // v odstavci třikrát a bez něj by agent přepsal první.
        quotes: ((opts.quotes && opts.quotes[i]) || [])
          .filter((q) => q && q.text)
          .map((q) => ({ text: short(String(q.text), MAX_QUOTE), nth: q.nth > 1 ? q.nth : 1 })),
        // Místo, které uživatel ukázal v obraze (§2.8) — prázdné znamená celé
        // médium. Povrch posílá klientské souřadnice, přepočet je na jádře.
        spot: safe(() => spotFor(el, d.defaultView, opts.spots && opts.spots[i]), null),
        context: opts.context === false ? null : safe(() => context(el, d, text, related.has(i) ? RELATION_PROPS : null), null),
      })),
      relations: rels,
      text,
      translation: null,
      // Anotace: řádky kódu a stylů, které uživatel označil v inspektoru appky.
      attachments: (opts.attachments || [])
        .filter((a) => a && a.type === "code" && a.text)
        .map((a) => ({ type: "code", from: a.from === "styles" ? "styles" : "dom", text: short(String(a.text), 400) })),
      origin: opts.origin || "palette",
      /*
       * Adresa vzdáleného MCP, když ji povrch má — tedy když uživatel relay sám
       * zapnul (§11). Jde do promptu proto, aby agent, kterému člověk balíček
       * vloží ručně, našel cestu zpátky: přečte si seznam a odškrtne, co udělal,
       * aniž by se ho na to kdokoliv musel doptávat.
       */
      mcp: typeof opts.mcp === "string" && /^https?:\/\//.test(opts.mcp) ? opts.mcp : null,
      // Obrázky, které k zadání přiložil povrch (ořez cíle, fotka od člověka).
      // Jdou ven jako soubory; tady je jen jejich jméno, aby agent věděl, co dostal.
      shots: [],
      dependsOn: null,
      snapshot: snapshot(d, opts.context === false ? null : elements),
      at: Date.now(),
    };
  }

  // ---------------------------------------------------------- běh (§2.5)

  /*
   * Co se s požadavkem stalo: verdikt kontroly a délka promptu. Sdílí id
   * s požadavkem; cena je ve fázi 1 nula, tak se nezapisuje.
   */
  function run(r) {
    return {
      id: r.id || uid("r"),
      at: r.at || Date.now(),
      verdict: r.verdict || null,
      chars: r.chars || 0,
    };
  }

  /*
   * Zapsaná část běhu (§7.4, milník E2): verdikt, délka promptu ve
   * znacích, počet cílů, hostname. Nikdy obsah stránky (§13).
   * Tentýž tvar poteče později do D1 — proto je tu jako schéma.
   */
  function record(req, r) {
    return {
      id: r.id,
      at: r.at,
      host: safe(() => new URL(req.web.url).hostname, null),
      origin: req.origin || null,
      verdict: r.verdict,
      chars: r.chars || 0,
      // Snímek je největší kus balíčku, tak se měří zvlášť od promptu (§7.3).
      snap: (req.snapshot && req.snapshot.chars) || 0,
      targets: (req.targets || []).length,
    };
  }

  // -------------------------------------------------------- vrstvy (§2.3)

  function renderTask(req) {
    return ["## Zadání", req.text || "(bez textu — jen ukázáno)"];
  }

  /*
   * Stránka jako nadpis, ne jako vypsaná adresa (§6.1). V nadpisu stojí titulek —
   * to je jméno, pod kterým uživatel stránku zná; cesta mu neřekne nic. Adresa
   * zůstává v cíli odkazu: agent ji čte ze zdroje markdownu a člověk na nadpis
   * ťukne a je na té stránce. Bez titulku nese nadpis adresu — odkaz bez popisky
   * by neměl co ukázat.
   */
  function pageLink(web) {
    const url = String((web && web.url) || "");
    const label = short((web && web.title) || "", MAX_TEXT);
    // Hranatá závorka v titulku a kulatá v adrese by odkaz ukončily dřív, než končí.
    const text = (label || url || "bez adresy").replace(/[[\]]/g, "");
    if (!url) return text;
    return `[${text}](${/[()\s]/.test(url) ? `<${url}>` : url})`;
  }

  function renderPage(req) {
    const out = [`## ${pageLink(req.web)}`];
    const p = req.snapshot && req.snapshot.page;
    if (!p) return out;
    const bits = [];
    // Systém webu (§4.4) jako text, ne číselník: platforma, stack, nebo vanilla.
    const system = [p.platform, p.stack.join(" + ")].filter(Boolean).join(" · ");
    bits.push(`systém: ${system || "vanilla (žádná platforma ani framework se ze stránky nepozná)"}`);
    bits.push(`viewport ${p.viewport.width}×${p.viewport.height}${p.viewport.dpr !== 1 ? ` @${p.viewport.dpr}x` : ""}`);
    if (p.scroll.x || p.scroll.y) bits.push(`scroll ${p.scroll.x},${p.scroll.y}`);
    if (p.document.width > p.viewport.width) bits.push(`stránka je širší než viewport (${p.document.width} px)`);
    bits.push(p.scheme);
    out.push(bits.join(" · "));

    /*
     * Škála a barvy webu (§4.5) jako popis, ne jako rozhodnutí. Web Editor neurčuje,
     * kterou hodnotu má agent napsat — jen mu říká, co na téhle stránce platí
     * a co by ze zdrojáku nevyčetl stejně rychle. „Zvětši“ se pak trefí do
     * stupně místo do násobku, a červená vyjde jako `var(--brand)` místo hexu,
     * který z palety vypadne hned, jak ji web přenastaví.
     */
    const sc = p.typeScale;
    if (sc && sc.steps.length) {
      const steps = sc.steps.map((px) => (sc.names[px] ? `${px} px (var(${sc.names[px]}))` : `${px} px`));
      out.push(`škála písma na webu: ${steps.join(" · ")} — ${sc.source}. Stupeň škály sedí líp než vlastní číslo.`);
    }
    const col = p.palette;
    if (col && col.colors.length) {
      const named = col.colors.filter((c) => c.name).slice(0, MAX_SITE_COLORS);
      const rest = col.colors.filter((c) => !c.name).slice(0, MAX_SITE_COLORS - named.length);
      const show = [...named, ...rest].map((c) => (c.name ? `${c.hex} (var(${c.name}))` : c.hex));
      if (show.length) out.push(`barvy webu: ${show.join(" · ")} — ${col.source}. Pojmenovanou piš jménem, ne hexem.`);
    }
    return out;
  }

  /** Píše pravidlo o něčem, co se zadání týká? `margin-top` sedí na `margin`. */
  function declares(css, props) {
    for (const part of String(css || "").split(";")) {
      const i = part.indexOf(":");
      if (i < 0) continue;
      const prop = part.slice(0, i).trim();
      for (const w of props) if (prop === w || prop.startsWith(`${w}-`)) return true;
    }
    return false;
  }

  /*
   * Co se z kontextu pošle. Sbírá se široce — v prohlížeči je to zadarmo —
   * ale platí se až tady, takže se tu zužuje: podle slov ve větě, a když ani
   * ta nic neurčila, jde ven všechno mimo výchozí hodnoty (§4.1).
   *
   * Zadání se přitom nepřekládá: slova vybírají, co z kontextu má cenu poslat,
   * ne co se má udělat. Když si věta říká o barvu, mají cenu barvy; jestli je
   * ta změna správná a jak se zapíše, rozhoduje agent.
   */
  function focus(req) {
    const related = req.relations.some((rel) => rel.overlap || rel.apart) ? RELATION_PROPS : [];
    return { props: topics(req.text, related), visual: true };
  }

  const pct = (v) => `${Math.round(v * 100)} %`;

  /*
   * Médium v cíli (§2.8): co to je, kam vede odkaz, jak je vsazené — a kde
   * uživatel v obraze ukázal. Soubor se nepřikládá; kdo ho potřebuje, stáhne
   * si ho z odkazu (zásada 6).
   */
  function renderMedia(m, spot) {
    const out = [];
    if (m.kind === "svg-part") {
      out.push(`médium: tvar uvnitř inline ${m.of}${m.viewBox ? ` (viewBox ${m.viewBox})` : ""} — je to element v markupu, ne soubor`);
      return out;
    }
    if (m.kind === "svg") {
      out.push(`médium: inline SVG${m.viewBox ? `, viewBox ${m.viewBox}` : ""}, ${m.parts} tvarů uvnitř; vykresleno ${m.rendered.width}×${m.rendered.height} px`);
      out.push("tvar uvnitř jde vybrat jako každý jiný prvek — ukazovat do něj souřadnicemi není potřeba");
      return out;
    }

    const head = ["obrázek"];
    if (m.natural) head.push(`${m.natural.width}×${m.natural.height} px`);
    head.push(`vykresleno ${m.rendered.width}×${m.rendered.height}`);
    if (m.format) head.push(m.format);
    if (m.bytes) head.push(KB(m.bytes));
    out.push(`médium: ${head.join(" · ")}`);
    if (m.src) out.push(`odkaz: ${m.src}`);

    const how = [];
    if (m.fit) how.push(`object-fit: ${m.fit}`);
    if (m.position) how.push(`object-position: ${m.position}`);
    if (m.variants > 1) how.push(`srcset: ${m.variants} varianty, tahle je vybraná`);
    if (m.loading) how.push(`loading=${m.loading}`);
    if (how.length) out.push(`vsazeno: ${how.join("; ")}`);
    if (m.alt) out.push(`popis (alt): „${m.alt}“`);
    else if (m.noAlt) out.push("popis (alt): chybí");

    if (spot) {
      const where = [`${pct(spot.box.x)} zleva, ${pct(spot.box.y)} shora`];
      if (spot.box.w) where.push(`oblast ${pct(spot.box.w)} × ${pct(spot.box.h)}`);
      let line = `ukázané místo: ${where.join(", ")} vykresleného obrázku`;
      if (spot.px) {
        line += `; v obraze ${spot.px.x},${spot.px.y} px`;
        if (spot.px.w) line += ` a ${spot.px.w}×${spot.px.h} px`;
      }
      out.push(line);
      out.push("Sem uživatel ukázal — zadání se týká tohohle místa, ne celého obrázku. Web Editor do souboru nesahá: obraz se mění mimo něj.");
    }
    // Soubor v promptu není, tak ať je aspoň vidět proč.
    if (m.src) out.push("Soubor přiložený není — stáhni si ho z odkazu, když je potřeba.");
    return out;
  }

  const SNAP_EXCERPT = 8;   // řádků okolí; víc už je druhý snímek, ne kontext

  function findNode(node, same, parent) {
    if (!node) return null;
    if (node.anchor && same(node.anchor)) return { node, parent };
    for (const kid of node.children || []) {
      const hit = findNode(kid, same, node);
      if (hit) return hit;
    }
    return null;
  }

  /*
   * Úryvek snímku kolem cíle (§7.6). Agent nemůže rozhodnout, co znamená
   * „to tlačítko vedle nadpisu", když vidí jen selektor — a celá stránka
   * je druhý extrém (§4.3). Cesta stromem je ve `v:` nad tím, takže rodič
   * se nepíše znovu: tady jsou sousedi, ne rodokmen.
   */
  function excerpt(snapshot, anchor) {
    if (!snapshot || !snapshot.tree || !anchor) return [];
    const same = (a) =>
      (anchor.path && a.path === anchor.path)
      || (anchor.testid && a.testid === anchor.testid)
      || (anchor.id && a.id === anchor.id);
    const hit = findNode(snapshot.tree, same, null);
    if (!hit || !hit.parent) return [];
    const label = (node) => `${nodeName(node)}${node.text ? ` „${node.text}“` : ""}`;
    const out = [];
    for (const kid of hit.parent.children || []) {
      if (out.length >= SNAP_EXCERPT) { out.push("- …"); break; }
      if (kid.more) { out.push(`- … a dalších ${kid.more}× ${kid.tag}`); continue; }
      const me = kid === hit.node;
      out.push(`- ${label(kid)}${me ? "  ← cíl" : ""}`);
      // Do cíle se jde ještě o patro: co je uvnitř něj, je součást zadání.
      if (me) for (const sub of (kid.children || []).slice(0, 3)) out.push(`  - ${label(sub)}`);
    }
    return out.length > 1 ? out : [];
  }

  function renderTarget(t, n, total, focus, seen, snap) {
    const c = t.context;
    if (!c) {
      const marked = (t.quotes || []).map((q) => `označený úsek: „${q.text}“`);
      if (t.spot) marked.push(`ukázané místo v obraze: ${pct(t.spot.box.x)} zleva, ${pct(t.spot.box.y)} shora`);
      return [`### ${total > 1 ? `${n} · ` : ""}${t.anchor.tag}`, ...marked];
    }
    const id = c.identity, g = c.geometry, a = c.around;
    const out = [`### ${total > 1 ? `${n} · ` : ""}${c.selector}`];

    const who = [];
    if (id.text) who.push(`text „${id.text}“`);
    if (id.attrs.length) who.push(id.attrs.join(" "));
    if (who.length) out.push(who.join(" · "));
    for (const q of t.quotes || []) {
      out.push(`označený úsek: „${q.text}“${q.nth > 1 ? ` (${q.nth}. výskyt v prvku)` : ""} — mění se jen on, zbytek prvku zůstává`);
    }

    if (g && focus.visual) {
      // Jen rozměry, ne pozice. Souřadnice ve viewportu a „mimo viewport“ jsou
      // snímek toho, kde se zrovna scrollovalo, když se zadávalo — do zdrojáku
      // nevedou a agent je vědomě přeskakuje (§7.6). Velikost naopak ze zdrojáku
      // nevyčte: že se dva cíle liší 20×20 vs 16×16, je vidět jen z vykreslení.
      let line = `box ${g.width}×${g.height} px`;
      if (g.parent) line += `; rodič ${g.parent.width}×${g.parent.height}`;
      out.push(line);
    }
    const shown = focus.props ? c.styles.filter((s) => focus.props.has(s.slice(0, s.indexOf(":")))) : c.styles;
    if (shown.length) out.push(`styly: ${shown.join("; ")}`);
    if (c.inline) out.push(`inline: ${c.inline}`);

    // Pravidlo, které už stálo u předchozího cíle, se nepíše dvakrát — a že
    // na oba sedí totéž, je samo o sobě signál: stejný tvar, nejspíš šablona.
    let same = 0;
    for (const r of c.rules) {
      if (focus.props && !declares(r.css, focus.props)) continue;
      const key = `${r.selector}|${r.css}|${r.source}`;
      if (seen.has(key)) { same = Math.max(same, seen.get(key)); continue; }
      seen.set(key, n);
      out.push(`css: ${r.selector} { ${r.css} }  ← ${r.source}`);
    }
    if (same) out.push(`css: dál stejná pravidla jako cíl ${same}`);

    if (c.media) out.push(...safe(() => renderMedia(c.media, t.spot), []));

    if (a) {
      const path = [...a.chain].reverse().map((x) => x.name);
      out.push(`v: ${path.join(" > ")}${a.layout ? `  (rodič je ${a.layout})` : ""}`);
      // Sousedi jménem, když je snímek po ruce — „sourozenci: 2, tohle je 2."
      // je totéž číslem a agent z něj nepozná, vedle čeho ten prvek stojí.
      const near = safe(() => excerpt(snap, t.anchor), []);
      if (near.length) out.push("okolí:", ...near);
      else {
        let sib = `sourozenci: ${a.siblings}, tohle je ${a.index}.`;
        if (a.prev) sib += ` · před: ${a.prev}`;
        if (a.next) sib += ` · za: ${a.next}`;
        out.push(sib);
      }
      for (const x of a.chain) if (x.inline) out.push(`inline na ${x.name}: ${x.inline}`);
    }
    return out;
  }

  function renderRelation(r) {
    const parts = [];
    if (r.inside === "b") parts.push(`${r.b} je uvnitř ${r.a}`);
    if (r.inside === "a") parts.push(`${r.a} je uvnitř ${r.b}`);
    if (r.siblings) parts.push("sourozenci");
    if (r.overlap) {
      parts.push(`překrývají se, průnik ${r.overlap.width}×${r.overlap.height} px`);
      if (r.top) parts.push(`nahoře je ${r.top === "a" ? r.a : r.b}`);
    }
    if (r.apart) {
      const where = [];
      if (r.apart.dx) where.push(`${Math.abs(r.apart.dx)} px ${r.apart.dx > 0 ? "vpravo od" : "vlevo od"}`);
      if (r.apart.dy) where.push(`${Math.abs(r.apart.dy)} px ${r.apart.dy > 0 ? "pod" : "nad"}`);
      parts.push(where.length ? `${r.b} je ${where.join(" a ")} ${r.a}` : "dotýkají se");
    }
    return `${r.a} × ${r.b}: ${parts.join("; ")}`;
  }

  function renderContext(req, r) {
    const out = [];
    if (req.targets.length) {
      const what = safe(() => focus(req), { props: null, visual: true });
      const seen = new Map();
      out.push(req.targets.length === 1 ? "## Cíl" : "## Cíle");
      req.targets.forEach((t, i) => out.push(...safe(() => renderTarget(t, i + 1, req.targets.length, what, seen, req.snapshot), []), ""));
    }
    if (req.relations.length) out.push("## Vztahy", ...req.relations.map(renderRelation), "");
    const code = (req.attachments || []).filter((a) => a.type === "code");
    if (code.length) {
      out.push("## Označeno v inspektoru", "Na tohle uživatel ukázal — zadání se týká právě těchhle řádků.");
      for (const [from, lang] of [["dom", "html"], ["styles", "css"]]) {
        const lines = code.filter((a) => a.from === from).map((a) => a.text);
        if (lines.length) out.push("```" + lang, ...lines, "```");
      }
      out.push("");
    }
    return out;
  }

  const PLACE = { before: "před", after: "za", prepend: "na začátek", append: "na konec" };
  // Vizuální osa říká agentovi, co „před" a „za" znamená na obrazovce.
  const ON_AXIS = {
    vertical: { before: "nad", after: "pod" },
    horizontal: { before: "vlevo od", after: "vpravo od" },
  };

  function anchorName(a) {
    if (!a) return "?";
    if (a.testid) return `${a.tag}[data-testid="${a.testid}"]`;
    if (a.id) return `${a.tag}#${a.id}`;
    if (a.label) return `${a.tag}[aria-label="${short(a.label, 40)}"]`;
    if (a.text) return `${a.tag} „${short(a.text, 30)}“`;
    return a.path ? short(a.path, 80) : a.tag;
  }

  /*
   * Kde hledat a kde ne (SPEC §7.9) — to, na čem agent nejvíc šetří.
   * Klíčová slova jsou ze stránky; cesty jsou konvence frameworku, ne odhad:
   * Stimulus controller `entity-index` je v Rails vždy
   * app/javascript/controllers/entity_index_controller.js.
   */
  const PATHS = { Rails: "app/views, app/javascript/controllers, app/assets/stylesheets" };
  // jen vygenerované a cizí — db/ je aplikační kód a u obsahu z databáze ho agent potřebuje (§4.4)
  const SKIP = { Rails: "vendor/, node_modules/, public/assets/, tmp/, log/" };

  /*
   * Klíčová slova ze stránky — to, na co se dá grepnout. Počítají se jednou
   * a jako data: schránka z nich udělá vrstvu „Kde hledat", CLI je pošle do
   * skutečného grepu a vrátí soubory a řádky (§7.6). Dvě místa, kde by se
   * počítala, by se rozešla.
   */
  function keywords(req) {
    const cls = new Set(), attrs = new Set(), texts = new Set(), files = new Set(), ctrls = new Set(), vars = new Set(), frames = new Set(), media = new Set();
    for (const t of req.targets) {
      const c = t.context;
      if (!c) continue;
      if (c.identity.id) attrs.add(`#${c.identity.id}`);
      c.identity.classes.forEach((x) => cls.add(x));
      c.identity.attrs.filter((x) => /^(data-|aria-label|role)/.test(x)).forEach((x) => attrs.add(x));
      // Označený úsek je pro grep přesnější než text celého prvku — ukázal ho uživatel.
      for (const q of t.quotes || []) if (q.text) texts.add(grep(q.text, MAX_GREP));
      const text = grep((t.anchor && t.anchor.text) || c.identity.text, MAX_GREP);
      if (text) texts.add(text);
      // Soubor s otiskem z buildu vyrobil build — jeho jméno ve zdrojáku není.
      c.rules.forEach((r) => { if (!r.built) files.add(r.source); });
      // Jméno obrázku je ve zdrojáku k nalezení líp než cokoliv jiného z média (§2.8).
      // Jméno bez otisku z buildu — ve zdrojáku je obrázek pod ním, ne pod `foto-9f3a1c.svg`.
      if (c.media && c.media.src) { const b = safe(() => basename(c.media.src).source, null); if (b) media.add(b); }
      if (c.around) {
        c.around.controllers.forEach((x) => ctrls.add(x));
        if (c.around.frame) frames.add(c.around.frame);
        for (const x of [c.inline, ...c.around.chain.map((y) => y.inline)]) {
          for (const v of String(x || "").match(/--[\w-]+/g) || []) vars.add(v);
        }
      }
    }
    const take = (set) => [...set].slice(0, MAX_HINTS);
    return {
      classes: take(cls), attrs: take(attrs), texts: take(texts), files: take(files),
      media: take(media), controllers: take(ctrls), frames: take(frames), vars: take(vars),
      stack: (req.snapshot && req.snapshot.page && req.snapshot.page.stack) || [],
    };
  }

  /*
   * Obsah, nebo kód (§4.4). Web Editor netvrdí závěr — dává větu, podle které se
   * agent rozhodne na jeden krok. Když si signály protiřečí, jde ven přiznání
   * místo věty: odhad prodaný jako fakt je horší než mlčení (zásada 8). A když
   * se nepozná nic, nejde ven nic — prázdná vrstva se taky platí (zásada 6).
   */
  function renderOrigin(req) {
    const list = req.targets.map((t) => t.context && t.context.origin).filter(Boolean);
    if (!list.length) return [];
    const conflict = list.find((o) => o.conflict);
    const verdicts = new Set(list.map((o) => o.verdict).filter(Boolean));
    const why = (o) => (o.signals.length ? ` (${o.signals.slice(0, MAX_ORIGIN_SIGNALS).join("; ")})` : "");

    if (conflict) {
      return [`obsah, nebo kód: ze stránky se to nepozná — signály si protiřečí${why(conflict)}. Ověř si to dřív, než začneš hledat.`];
    }
    if (verdicts.size !== 1) return [];
    if (verdicts.has("data")) {
      return [`obsah, ne kód: tenhle text v repozitáři nenajdeš${why(list[0])}. Hledej ho v datech nebo v administraci; v kódu hledej šablonu, která ho vypisuje.`];
    }
    return [`text je v kódu, ne v datech${why(list[0])} — grep ve zdrojáku ho najde.`];
  }

  /*
   * Cesta zpátky (§2.9). Balíček, který někdo vloží agentovi ručně, končí
   * slepě: agent udělá práci a nemá jak říct, že ji udělal. Když relay běží,
   * jde s balíčkem i adresa, na které je seznam živý — agent se připojí, přečte
   * si zbytek zadání a odškrtne, co dokončil.
   *
   * Do tenkého kanálu (`mcp`) to nepatří: tam už agent připojený je a adresa,
   * kterou zrovna používá, by byla řádek, za který platí zbytečně (zásada 6).
   */
  function renderConnect(req) {
    if (!req.mcp) return [];
    return [
      "## Napojení",
      `Tenhle seznam je živý na \`${req.mcp}\` — MCP přes Streamable HTTP. Když se připojíš, odškrtneš, co uděláš, a uživatel to uvidí u sebe.`,
      `- Codex: \`codex mcp add weed --url ${req.mcp}\``,
      `- Claude Code: \`claude mcp add --transport http weed ${req.mcp}\``,
      "Nástroje: `weed_list` přečte rozepsaná zadání, `weed_done` označí jedno za hotové a připojí poznámku, co se změnilo.",
    ];
  }

  function renderHints(req) {
    const k = safe(() => keywords(req), null);
    if (!k) return [];
    const rails = k.stack.includes("Rails");
    const controller = (id) => rails
      ? `${id} (app/javascript/controllers/${id.replace(/--/g, "/").replace(/-/g, "_")}_controller.js)`
      : id;

    const line = (label, list, map) => (list.length ? `${label}: ${list.map(map || ((x) => x)).join(", ")}` : null);
    const out = [
      line("třídy", k.classes), line("atributy", k.attrs), line("texty", k.texts, (x) => `„${x}“`),
      line("soubory", k.files), line("obrázky", k.media), line("stimulus", k.controllers, controller),
      line("turbo-frame", k.frames), line("proměnné", k.vars),
    ].filter(Boolean);
    if (!out.length) return [];

    // Cesty jen když je stack jistý z DOMu — špatná cesta je horší než žádná.
    for (const s of k.stack) if (PATHS[s]) out.push(`cesty: ${PATHS[s]}`);
    for (const s of k.stack) if (SKIP[s]) out.push(`neprocházej: ${SKIP[s]}`);
    out.push("Začni tímhle; celou aplikaci neprocházej.");
    for (const line of safe(() => renderOrigin(req), []) || []) out.push(line);
    return ["## Kde hledat", ...out];
  }

  /*
   * Tři věty, které nesmí chybět (§7.6). Žádná není o obsahu zadání a každá
   * mění, co agent udělá: odkud změna je, co Web Editor neví, a čím se smyčka
   * zavírá. Bez první z nich agent neví, jestli drží specifikaci, nebo odhad.
   */
  function renderFacts(req, r) {
    const p = (req.snapshot && req.snapshot.page) || null;
    const system = p ? [p.platform, (p.stack || []).join(" + ")].filter(Boolean).join(" · ") : "";
    return [
      "## Odkud to je",
      "- Web Editor do stránky nezapsal nic a zadání nepřeložil. Věta výš je, jak ji řekl uživatel; co se má v kódu stát, rozhoduješ ty.",
      system
        ? `- Web Editor nevidí zdroják ani databázi. Systém webu je odhad z DOMu, ne ze zdrojáku: ${system}.`
        : "- Web Editor nevidí zdroják ani databázi. Systém webu se z DOMu nepoznal — ber to jako vanilla.",
      "- Až to nasadíš, uživatel si stránku ve Web Editoru načte a uvidí to. Nikdo nic nepřepisuje za tebou.",
    ];
  }

  /*
   * Obecná hranice — „nejmenší diff, nic navíc" — tu nestojí schválně (§7.6):
   * agent ji má ve svém systémovém promptu, a kdo ji tam nemá, ten ji
   * neposlechne ani v markdownu. Totéž o vzhledu říká hlavička rámce
   * (`prompts/frame/header.md`), takže by šla ven dvakrát. Cenné je jen
   * měřené kritérium — to je v „Hotovo, když“, spočtené z toho, co víme.
   */

  function renderDone(req) {
    const overlaps = req.relations.filter((r) => r.overlap);
    let done;
    if (overlaps.length) {
      done = `Cíle ${overlaps.map((r) => `${r.a} a ${r.b}`).join(", ")} se nepřekrývají (pokud zadání nechce jinak) a oba zůstávají viditelné a klikatelné. Nic jiného na stránce se nezměnilo.`;
    } else if (req.targets.some((t) => t.spot)) {
      done = "Kotva cíle sedí, změna se týká ukázaného místa v obraze a zbytek obrázku i stránky zůstal, jak byl. Web Editor do souboru nesahá — co je v něm, je na tobě.";
    } else if (req.targets.some((t) => (t.quotes || []).length)) {
      done = "Kotva cíle sedí (prvek jde najít stejně jako teď), změnil se jen označený úsek textu a zbytek prvku i stránky zůstal, jak byl.";
    } else if (req.targets.length) {
      done = "Kotva cíle sedí (prvek jde najít stejně jako teď), hodnota je nová a nic jiného na stránce se nezměnilo.";
    } else {
      done = "Zadání je splněné a nic jiného na stránce se nezměnilo.";
    }
    return ["## Hotovo, když", done];
  }

  /*
   * Balíček (§7.9): vrstvy podle SPEC §2.3, v pořadí od nejstálejší, nad
   * požadavkem a během. Prázdné sloty jsou fáze 2 — prompt webu a role
   * s profilem webu (§6.6), sety (§6.1), design skill a zákazy (§6.2, §6.3),
   * PM překlad (§5). Každá vrstva je
   * samostatný krok: když spadne, vypadne jen ona.
   */
  /*
   * Obrázek u zadání (§7.6). Soubory jdou ven vedle promptu a bez jména by je
   * agent neměl jak přiřadit — u tří zadání a tří ořezů by hádal, co k čemu je.
   * Jméno je proto v textu u toho zadání, ke kterému ořez patří.
   */
  function renderShots(req) {
    const shots = (req.shots || []).map((s) => String(s || "").trim()).filter(Boolean);
    if (!shots.length) return null;
    const out = ["## Přiložený obrázek", ""];
    for (const name of shots) out.push(`- \`${name}\` — cíl tohoto zadání, jak vypadal na obrazovce, když se zadávalo`);
    return out;
  }

  /*
   * Podklady (§7.6): obrázky, které uživatel přiložil sám. Na rozdíl od ořezu cíle
   * nepatří jednomu zadání — proto stojí nad seznamem, ne v něm. Co na nich je,
   * neříkáme: vidí je agent, my do nich nekoukáme (zásada 9).
   */
  function renderPapers(req) {
    const papers = (req.papers || []).map((s) => String(s || "").trim()).filter(Boolean);
    if (!papers.length) return null;
    const out = ["## Podklady", "Obrázky přiložené uživatelem. Platí pro celé zadání, ne pro jeden cíl.", ""];
    for (const name of papers) out.push(`- \`${name}\``);
    return out;
  }

  const LAYERS = [
    ["role", () => ["# Zadání z prohlížeče (Web Editor)"]],
    ["web", null],
    ["prefixes", null],
    ["design", null],
    ["papers", renderPapers],
    ["task", renderTask],
    ["page", renderPage],
    ["network", renderNetwork],
    ["context", renderContext],
    ["shots", renderShots],
    ["connect", renderConnect],
    ["hints", renderHints],
    ["facts", renderFacts],
    ["done", renderDone],
    ["postfixes", null],
  ];

  function layers(list, req, r) {
    const out = [];
    for (const [, layer] of list) {
      if (!layer) continue;
      const lines = safe(() => layer(req, r), null);
      if (lines && lines.length) out.push(...lines, "");
    }
    return out;
  }

  const tidy = (lines) => lines.join("\n").replace(/\n{3,}/g, "\n\n").trimEnd();

  /*
   * Tři kanály, tři tloušťky (§7.6). Neliší se tím, kolik kontextu umíme
   * složit, ale tím, **co příjemce už ví a jestli se může doptat**:
   *
   * - `clipboard` — nejdelší a sebenosný. Agentovi, kterému text někdo vloží,
   *   se nemá kdo doptat a my nevíme, co má v systémovém promptu; proto je
   *   na konci i věta pro člověka, kam to patří.
   * - `cli` — krátký požadavek jako data. CLI má repozitář u sebe, takže
   *   *kde hledat* si udělá samo skutečným grepem. My posíláme slova, ono
   *   vrací soubory a řádky — tím zásada 8 přestane být kompromis.
   * - `mcp` — nejtenčí: věta, kotva a adresa. Zbytek si agent dobere
   *   nástroji (§1), a kdo si vrstvu nevyzvedne, nezaplatí ji. Smí se navíc
   *   zeptat i na prvek, na který uživatel neukázal — to předem složený
   *   prompt neumí.
   */
  const CHANNELS = ["clipboard", "cli", "mcp"];

  const HANDOFF = "Vlož to celé svému agentovi jako jedno zadání — je to sebenosné, nic dalšího doplňovat nemusíš.";

  const MCP_TOOLS = "page_target (kontext a styly cíle), page_snapshot (HTML a styly prvku), page_capture (ořez cíle), page_list (celý seznam zadání), page_metadata (stránka a systém)";

  /* Nejtenčí render (§7.6): co agent nedostane, si vyzvedne sám. */
  function renderThin(req, r) {
    const out = ["# Zadání z prohlížeče (Web Editor)", req.text || "(bez věty — uživatel jen ukázal)"];
    const web = req.web || {};
    if (web.url) out.push(`stránka: ${web.url}${web.title ? ` (${web.title})` : ""}`);
    for (const t of req.targets || []) {
      const bits = [anchorName(t.anchor)];
      if (t.context && t.context.selector) bits.push(t.context.selector);
      for (const q of t.quotes || []) bits.push(`úsek „${short(q.text, MAX_TEXT)}“`);
      out.push(`cíl: ${bits.join(" · ")}`);
    }
    // Tahle věta platí ve všech kanálech: bez ní agent neví, jestli drží
    // specifikaci, nebo hotovou změnu (§7.6).
    out.push("Web Editor do stránky nezapsal nic — je to zadání, ne hotová změna.");
    out.push(`Dobrat si zbytek: ${MCP_TOOLS}.`);
    return out;
  }

  /*
   * Požadavek jako data pro CLI. Cesty ani výjimky tu schválně nejsou: CLI
   * stojí nad repozitářem a najde je grepem, kdežto náš odhad by ho poslal
   * jinam (zásada 8). `applied: false` je věta „na stránce se nic nezměnilo"
   * ve tvaru, který se dá přečíst strojem.
   */
  function renderData(req, r) {
    const k = safe(() => keywords(req), null) || { stack: [] };
    const page = (req.snapshot && req.snapshot.page) || {};
    const grep = [...new Set([
      ...(k.classes || []), ...(k.attrs || []), ...(k.texts || []), ...(k.files || []),
      ...(k.media || []), ...(k.controllers || []), ...(k.frames || []), ...(k.vars || []),
    ])];
    return JSON.stringify({
      weed: 1,
      channel: "cli",
      url: (req.web && req.web.url) || null,
      title: (req.web && req.web.title) || null,
      system: { platform: page.platform || null, stack: k.stack },
      text: req.text || "",
      targets: (req.targets || []).map((t) => ({
        anchor: t.anchor,
        selector: (t.context && t.context.selector) || null,
        quotes: (t.quotes || []).map((q) => q.text),
      })),
      grep,
      applied: false,
      done: safe(() => renderDone(req)[1], null),
    }, null, 2);
  }

  function render(req, r, opts) {
    const channel = (opts && opts.channel) || "clipboard";
    if (channel === "cli") return renderData(req, r);
    if (channel === "mcp") return tidy(renderThin(req, r));
    return tidy([...layers(LAYERS, req, r), HANDOFF]);
  }

  /*
   * Rámec pro schránku (§7.6, *Tři kanály, tři tloušťky*). Agent, kterému
   * někdo prompt vloží, se nemůže doptat a nevíme, co má v systémovém
   * promptu — tenhle jediný kanál proto musí být sebenosný. MCP a CLI ho
   * nedostanou: kdo si vrstvu nevyzvedne, nezaplatí ji.
   *
   * Text je data (`prompts/frame/`), ne kód — povrch si ho dodá do
   * `WeedCore.frame`. Když ho nedodá, vypadne jen tahle vrstva a prompt je
   * chudší, ne žádný (zásada 5).
   */
  function frame(text) {
    const f = Core.frame || {};
    // Jen úvod: patička padla i s pokyny v ní. Fakta, která agent nemá jak zjistit,
    // skládá balíček sám (`renderFacts`) a needitují se.
    return [f.header, text].map((x) => String(x == null ? "" : x).trim()).filter(Boolean).join("\n\n");
  }

  /*
   * Rozepsaný seznam (§2.6) jako jeden balíček: co je společné — role, web,
   * sety, hranice — jde jednou, stabilní začátek se tak cacheuje přes všechna
   * zadání (§2.3). Každé zadání nese vlastní cíl, kontext a hotovo.
   */
  const PER_REQUEST = new Set(["task", "context", "shots", "hints", "done"]);
  // Stránka je společná pro zadání, která na ní vznikla — v seznamu stojí nad skupinou,
  // ne u každého zadání zvlášť.
  const PER_PAGE = new Set(["page", "network"]);

  /*
   * Průchod webem se čte po stránkách. Zadání se drží v pořadí, v jakém vznikla,
   * a seskupí se, dokud se nezmění adresa: kdo prošel `/` → `/cenik` → `/` má
   * v promptu tři skupiny, protože i to je pořadí kroků (§2.6). Skupina vypíše
   * adresu a fakta o stránce jednou — u každého zadání by se opakovala a agent
   * by z toho nepoznal, že je to táž stránka.
   */
  function byPage(items) {
    const groups = [];
    for (const it of items) {
      const url = (it.req.web && it.req.web.url) || "";
      const last = groups[groups.length - 1];
      if (last && last.url === url) last.items.push(it);
      else groups.push({ url, items: [it] });
    }
    return groups;
  }

  function renderList(items, opts) {
    const channel = (opts && opts.channel) || "clipboard";
    // Data a nejtenčí render se seznamem neslévají: CLI dostane pole požadavků
    // a agent přes MCP jde po jednom. Společné vrstvy šetří tokeny jen tam,
    // kde se prompt čte celý — tedy ve schránce.
    if (channel === "cli") return `[\n${items.map((it) => renderData(it.req, it.run)).join(",\n")}\n]`;
    if (channel === "mcp") return tidy(items.flatMap((it, i) => [...(items.length > 1 ? [`# ${i + 1}/${items.length}`] : []), ...renderThin(it.req, it.run), ""]));
    if (items.length <= 1) return items.length ? render(items[0].req, items[0].run) : "";
    const first = LAYERS.findIndex(([n]) => PER_REQUEST.has(n) || PER_PAGE.has(n));
    const head = LAYERS.slice(0, first);
    const page = LAYERS.filter(([n]) => PER_PAGE.has(n));
    const own = LAYERS.filter(([n]) => PER_REQUEST.has(n));
    const tail = LAYERS.slice(first).filter(([n]) => !PER_REQUEST.has(n) && !PER_PAGE.has(n));
    const lead = items[0];
    const groups = byPage(items);
    const where = groups.length > 1
      ? ` Jsou rozdělená po stránkách — ${groups.length} oddílů v pořadí, jak jimi uživatel prošel.`
      : "";
    const out = [
      ...layers(head, lead.req, lead.run),
      `${items.length} zadání z jednoho průchodu webem. Každé má vlastní cíl a kontext; udělej je v tomhle pořadí.${where}`, "",
    ];
    let n = 0;
    for (const group of groups) {
      out.push("---", "", ...layers(page, group.items[0].req, group.items[0].run));
      for (const it of group.items) out.push(`# ${++n}/${items.length}`, "", ...layers(own, it.req, it.run));
    }
    out.push("---", "", ...layers(tail, lead.req, lead.run), HANDOFF);
    return tidy(out);
  }

  // ------------------------------------------------------------ zip (§7.6)

  /*
   * Balíček jako jeden soubor. Zip proto, že je to jediný archiv, který
   * rozbalí každý systém sám — a hlavně jediná cesta k **druhému** agentovi:
   * živá relace je jedna (§9), takže srovnat dva agenty nad týmž zadáním jde
   * jedině souborem. Je to zároveň archiv a záloha, když napojení selže.
   *
   * Píše se ručně a bez komprese (zásada 2: jádro běží v cizí stránce a nemá
   * závislosti). `store` není lenost — prompt jsou jednotky kilobajtů a
   * přílohy jsou PNG a PDF, které už stlačené jsou; deflate by byl kód navíc
   * za nic. Soubory dodává povrch: jádro do galerie ani na disk nevidí.
   */
  const CRC_TABLE = (() => {
    const table = new Int32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      table[i] = c;
    }
    return table;
  })();

  function crc32(bytes) {
    let c = -1;
    for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
    return (c ^ -1) >>> 0;
  }

  const utf8 = (s) => new TextEncoder().encode(String(s));

  /*
   * Zip s jednou položkou na soubor. `files` je `[{ name, bytes | text }]`
   * a jména si volí volající — vazba ořezu na zadání drží právě jménem (§7.6),
   * takže je jádro nepřepisuje. Vrací `Uint8Array`; co s ním povrch udělá —
   * stažení, Sdílet — je jeho věc.
   */
  function zip(files) {
    const items = (files || [])
      .filter((f) => f && f.name)
      .map((f) => {
        const bytes = f.bytes instanceof Uint8Array ? f.bytes : utf8(f.text || "");
        return { name: utf8(f.name), bytes, crc: crc32(bytes) };
      });
    const LOCAL = 30, CENTRAL = 46, END = 22;
    const size = items.reduce((n, it) => n + LOCAL + it.name.length + it.bytes.length + CENTRAL + it.name.length, 0) + END;
    const out = new Uint8Array(size);
    const view = new DataView(out.buffer);
    let at = 0;
    const u16 = (n) => { view.setUint16(at, n, true); at += 2; };
    const u32 = (n) => { view.setUint32(at, n >>> 0, true); at += 4; };
    const raw = (b) => { out.set(b, at); at += b.length; };

    // Čas v zipu je DOS formát z roku 1980. Bereme teď — archiv má datum,
    // kdy vznikl, a nic jiného z něj nečteme.
    const now = new Date();
    const time = (now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1);
    const date = ((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate();
    // Bit 11 říká, že jména jsou v UTF-8 — bez něj je „zadání.md" v cizím
    // rozbalovači krysí ocas.
    const FLAGS = 0x800;

    for (const it of items) {
      it.at = at;
      u32(0x04034b50); u16(20); u16(FLAGS); u16(0); u16(time); u16(date);
      u32(it.crc); u32(it.bytes.length); u32(it.bytes.length);
      u16(it.name.length); u16(0);
      raw(it.name); raw(it.bytes);
    }
    const dirAt = at;
    for (const it of items) {
      u32(0x02014b50); u16(20); u16(20); u16(FLAGS); u16(0); u16(time); u16(date);
      u32(it.crc); u32(it.bytes.length); u32(it.bytes.length);
      u16(it.name.length); u16(0); u16(0); u16(0); u16(0); u32(0); u32(it.at);
      raw(it.name);
    }
    // Velikost adresáře se spočítá dřív, než se začne psát patička: `at` se
    // jejími vlastními poli posune a rozbalovači by pak chybělo dvanáct bajtů.
    const dirSize = at - dirAt;
    u32(0x06054b50); u16(0); u16(0); u16(items.length); u16(items.length);
    u32(dirSize); u32(dirAt); u16(0);
    return out;
  }

  /*
   * Balíček k předání: prompt jako soubor a přílohy vedle něj, v jedné složce.
   * Povrch dodá
   * bajty příloh — ten, kdo je má. Když nedodá nic, je v zipu prompt sám
   * a je to pořád archiv, ne chyba; odkazy na soubory, které nepřijdou, se
   * do promptu nepíšou (zásada 8), o to se stará ten, kdo skládá seznam.
   */
  function pack(prompt, files, folder) {
    // Jedna složka uvnitř, pojmenovaná po balíčku: rozbalený zip jinak
    // vysype `zadani.md` a přílohy doprostřed Stažených. Appka to tak dělá
    // od začátku (ios/Web Editor/Sharing.swift) a tvar balíčku musí být jeden —
    // agent na druhé straně nepozná, ze kterého povrchu přišel.
    const at = folder ? `${String(folder).replace(/[/\\]+$/, "")}/` : "";
    return zip([
      { name: `${at}zadani.md`, text: String(prompt || "") },
      ...(files || []).map((f) => ({ ...f, name: `${at}${f.name}` })),
    ]);
  }

  /** Zkratka bez běhu — pro agenta, který chce jen kontext. */
  function build(opts) {
    return render(request(opts), null);
  }

  Core.Prompt = { context, selector, page, share, stack, relations, snapshot, renderTree, zip, pack, keywords, CHANNELS, network, vitals, watchVitals, request, run, record, render, renderList, frame, build, id: () => uid("r"), LAYERS, PROPS };
})(typeof globalThis !== "undefined" ? globalThis : this);
