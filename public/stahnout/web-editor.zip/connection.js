/* Napojení na vzdálený Weed MCP — co o něm ví rozšíření (SPEC §9, §11).
 *
 * Tři hodnoty a jedna z nich je souhlas. Drží je `chrome.storage.local`,
 * protože patří tomuhle prohlížeči, ne účtu — a účet nevznikne (§8.2).
 *
 * Klíč je tajemství, ne autentizace: kdo ho uvidí, na zadání dosáhne. Není to
 * stav před OAuth, ale trvalý tvar — autentizace by znamenala účet a ten
 * nevznikne (§8.2). UI to proto říká natvrdo; hezčí věta by slibovala
 * bezpečí, které tu není (zásada 8).
 */

const KEY = "connection";

/* Náš Worker tu schválně není jako výchozí adresa. Relay je to jediné, co
   provozujeme my (zásada 6), a patří proto za nárok z aplikace — rozšíření se
   k němu spáruje kódem z appky (§8.2, milník 15a). Dokud párování není,
   vyplněná adresa našeho relaye by ho otevřela komukoliv, kdo si rozšíření
   stáhne: klíč si klient generuje sám a Worker ho neváže na nic.

   Prázdné pole proto znamená „nikam" — rozšíření bez adresy zadání skládá dál
   a ven jde schránkou, ta nás nestojí nic. Kdo si pustí vlastní Worker, zadá
   si ho na stránce Napojení. */

/* 32 znaků z `crypto`, ne z `Math.random`. Tvar sedí na to, co Worker
   pouští dál (`/^[A-Za-z0-9_-]{22,64}$/`). */
function freshKey() {
  const bytes = crypto.getRandomValues(new Uint8Array(24));
  return btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

/** Výchozí stav je vypnuto — bez souhlasu odsud neodejde nic (§11). */
async function read() {
  const stored = (await chrome.storage.local.get(KEY))[KEY] || {};
  return {
    endpoint: stored.endpoint || "",
    key: stored.key || "",
    on: !!stored.on,
  };
}

async function write(patch) {
  const next = { ...(await read()), ...patch };
  await chrome.storage.local.set({ [KEY]: next });
  return next;
}

/* Adresa, kterou uživatel vloží do svého klienta. Projekt v ní není: klíč je
   jeden pro celý prohlížeč a Worker si podle něj najde instanci sám. */
function mcpUrl({ endpoint, key }) {
  if (!endpoint || !key) return "";
  return `${endpoint.replace(/\/+$/, "")}/s/${key}/mcp`;
}

if (typeof self !== "undefined") self.Connection = { read, write, freshKey, mcpUrl };
