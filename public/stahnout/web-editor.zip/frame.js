// Generováno z prompts/frame/ — needitovat, mění se tam.
window.WeedCore.frame = {
  "header": "Zadání vzniklo ve [Web Editoru](https://weed.indigostudio.cz): uživatel ukázal prvky na webu a popsal požadované změny. Selektory, styly a kontext pocházejí z vykreslené stránky, ne ze zdrojového kódu."
};
