/* Zrcadlení rozepsaného seznamu do vzdáleného Weed MCP (SPEC §9).
 *
 * Běží v izolovaném světě vedle jádra, takže si prompt vezme rovnou z něj —
 * skládat ho podruhé tady by znamenalo druhou implementaci §7.9, která se
 * s tou první rozejde.
 *
 * **Výchozí stav je vypnuto a je to zásada 9, ne opatrnost.** Zapnutím
 * uživatel řekne, že obsah stránky smí opustit zařízení; do té doby odsud
 * neodejde nic a seznam jde do schránky jako vždycky.
 */

(() => {
  "use strict";

  const events = window.WeedCore.events ||= new EventTarget();
  if (typeof chrome === "undefined" || !chrome.runtime) return;

  const project = window.WeedCore.project(location.hostname, location.port);

  // Seznam se mění po zadáních, ne po písmenech, ale zahodit a přidat jdou
  // rychle za sebou. Odesílá se poslední stav, ne každý mezikrok.
  let timer = null;
  let last = "";

  events.addEventListener("weed:draft:set", () => {
    clearTimeout(timer);
    timer = setTimeout(send, 400);
  });

  async function send() {
    let payload;
    try {
      const snapshot = await window.weed.list();
      payload = { items: snapshot.items || [], prompt: snapshot.prompt || "" };
    } catch (_) { return; }

    // Tentýž stav se neposílá dvakrát: přepnutí karty a obnovení stránky vyvolá
    // uložení, ale na seznamu se nic nezměnilo.
    const stamp = JSON.stringify(payload);
    if (stamp === last) return;

    try {
      const answer = await chrome.runtime.sendMessage({ type: "weed:sync", project, payload });
      // Až když Worker potvrdí. Kdyby se zapamatoval neodeslaný stav, další
      // změna by ho přeskočila a seznam by zůstal pozadu bez hlášky (zásada 8).
      if (answer && answer.ok) {
        last = stamp;
        // Až teď je jisté, že seznam na té adrese opravdu je (§2.9).
        if (answer.mcp) window.weed.mcp(answer.mcp);
      }
    } catch (_) { /* rozšíření se právě znovu načetlo — pošle se příště */ }
  }
})();
