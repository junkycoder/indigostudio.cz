/*
 * palette.js — všechno, co je vidět: paleta, zaměřovač, historie.
 *
 * Paleta žije v Shadow DOM, aby ji styly stránky nerozbily a ona nerozbila
 * stránku. Zaměřovač je druhá vrstva nad stránkou, která nikdy nepustí
 * událost dál — proto se dá vybírat i na webech s vlastními klikacími handlery.
 *
 * Rozšíření běží v izolovaném světě; appka vkládá stejné jádro vlastním mostem.
 */

(function () {
  "use strict";

  if (window.__weedLoaded) return;
  window.__weedLoaded = true;

  const Core = window.WeedCore;
  const Prompt = Core.Prompt;
  // Rozšíření předá soukromý kanál; appka dál používá svůj DOM most.
  const events = Core.events || window;

  const state = {
    open: false,
    picking: false,
    selection: [],       // vybrané elementy
    list: [],            // rozepsaný seznam (SPEC §2.6): [{req, run}]
    lastPrompt: null,    // poslední prompt, který šel do schránky
    papers: [],          // podklady (§7.6) — přílohy povrchu bez vazby na zadání
    network: false,      // přilepit síťový přenos stránky (§7.6) — volba povrchu
    mcp: null,           // adresa vzdáleného MCP, když ji povrch potvrdil (§2.9)
    shots: false,        // umí tenhle povrch ořez cíle? pak se na něj čeká (§7.6)
    placing: [],         // možnosti posledního ťuknutí při přesunu
    quotes: new Map(),   // úseky textu označené uvnitř vybraných prvků: Element → Range[]
    undoStack: [],       // co jde vrátit, odzadu (SPEC §2.6)
    redoStack: [],       // co jde vrátit zpátky, když se vrátilo omylem
  };

  // ------------------------------------------------------------------ UI

  const host = document.createElement("div");
  host.id = "weed-root";
  host.style.cssText = "all:initial;position:fixed;z-index:2147483647;inset:auto;";
  const shadow = host.attachShadow({ mode: "open" });

  /*
   * Co se ve stránce po načtení změnilo samo, se dá poznat jen odtud — pozdější
   * pohled do DOMu už rozdíl nevidí (§4.4). Pozorovatel proto startuje hned a
   * naše vlastní vrstva se z něj vynechává; bez něj signál jen chybí (zásada 5).
   */
  if (Core.watchOrigin) { try { Core.watchOrigin(document, host); } catch { /* signál jen chybí */ } }

  shadow.innerHTML = `
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; }

      .panel {
        position: fixed;
        left: 50%; bottom: 40px; transform: translateX(-50%);
        width: min(640px, calc(100vw - 32px));
        background: #2c2c2e;
        color: #f2f2f7;
        border: 1px solid #48484a;
        border-radius: 10px;
        box-shadow: 0 18px 50px rgba(0,0,0,.45), 0 2px 6px rgba(0,0,0,.3);
        font: 14px/1.5 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
        overflow: hidden;
        display: none;
      }
      .panel[data-open="true"] { display: block; }
      /* Panel se dá odtáhnout za kterékoliv místo, kde nic není — proto ruka
         nad ním a systémový kurzor nad tím, co se ovládá nebo píše. Tažení po
         panelu nesmí scrollovat stránkou, proto se dotyk zastaví tady; do
         vstupu a do textu se vrací, jinak by v nich nešlo označit slovo. */
      .panel { cursor: grab; touch-action: none; }
      .panel[data-dragging="true"] { cursor: grabbing; user-select: none; }
      .panel input, .panel textarea, .panel button, .panel a { touch-action: auto; cursor: auto; }
      .panel button, .panel a { cursor: pointer; }

      .row { display: flex; align-items: center; gap: 8px; padding: 10px 12px; }

      .chips { display: flex; flex-wrap: wrap; gap: 6px; padding: 0 12px 8px; }
      .chips:empty { display: none; }
      .chip {
        display: inline-flex; align-items: center; gap: 6px;
        background: #3a3a3c; border: 1px solid #48484a; color: #ffb340;
        border-radius: 999px; padding: 3px 6px 3px 9px; font-size: 12px;
        max-width: 260px;
      }
      .chip b { font-weight: 600; }
      .chip i { font-style: normal; opacity: .6; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .chip button {
        all: unset; cursor: pointer; width: 16px; height: 16px;
        display: grid; place-items: center; border-radius: 50%;
        color: #98989f; font-size: 13px; line-height: 1;
      }
      .chip button:hover { background: #48484a; color: #f2f2f7; }

      input.cmd {
        all: unset;
        flex: 1; min-width: 0;
        color: #f2f2f7; font: inherit;
        caret-color: #59b7f0;
      }
      input.cmd::placeholder { color: #8e8e93; }
      /* pod 16 px si iOS při ťuknutí do řádku přiblíží celou stránku */
      @media (pointer: coarse) { input.cmd { font-size: 16px; } }

      .aim, .copy {
        all: unset; cursor: pointer;
        width: 28px; height: 28px; flex: none;
        display: grid; place-items: center;
        border: 1px solid #48484a; border-radius: 6px;
        color: #59b7f0;
      }
      .copy:hover { background: #3a3a3c; }
      /*
       * Ukázat prvek je první krok — bez něj je zadání jen věta a agent hledá
       * sám. Proto plná plocha u zaměřovače a obrys u schránky vedle: ze dvou
       * stejně vypadajících tlačítek není poznat, čím se začíná.
       */
      .aim { background: #0a84ff; border-color: #0a84ff; color: #fff; }
      .aim:hover { background: #3d9bff; border-color: #3d9bff; }
      /* Zapnutý zaměřovač už není výzva, ale stav — světlejší plocha a prstenec
         kolem, aby šel odlišit od tlačítka, které na kliknutí teprve čeká. */
      .aim[data-active="true"] {
        background: #59b7f0; border-color: #59b7f0; color: #1c1c1e;
        box-shadow: 0 0 0 3px rgba(89,183,240,.28);
      }

      .status {
        border-top: 1px solid #3a3a3c;
        padding: 8px 12px; font-size: 12px; color: #98989f;
        display: flex; gap: 10px; align-items: baseline;
      }
      .status[data-kind="done"] { color: #30d158; }
      .status[data-kind="kill"] { color: #ff453a; }
      .status[data-kind="ask"] { color: #ff9f0a; }
      .status[data-kind="escalate"] { color: #ff9f0a; }
      .status[data-kind="prompt"] { color: #30d158; }
      .spacer { flex: 1; }
      .runs, .clear, .pack { all: unset; cursor: pointer; color: #98989f; text-decoration: underline; }
      .runs:hover, .clear:hover, .pack:hover { color: #f2f2f7; }
      .clear[hidden] { display: none; }
      .manual-copy {
        display: block; width: calc(100% - 24px); height: min(160px, 30vh);
        margin: 0 12px 12px; padding: 8px;
        background: #1c1c1e; color: #f2f2f7; border: 1px solid #48484a;
        border-radius: 0; font: inherit; resize: vertical;
      }
      .manual-copy[hidden] { display: none; }
      .manual-copy:focus-visible { outline: 2px solid #59b7f0; outline-offset: 2px; }
    </style>

    <div class="panel" part="panel">
      <div class="row">
        <input class="cmd" type="text" placeholder="co chceš na stránce změnit?" spellcheck="false" />
        <button class="aim" title="vybrat prvek — přidá se k vybraným" aria-label="zaměřovač">⊹</button>
        <button class="copy" title="přidat k ostatním a zkopírovat všechna zadání (⏎)" aria-label="do schránky">⧉</button>
      </div>
      <div class="chips"></div>
      <div class="status"><span class="msg">zadání pro tvého agenta, stránku neměníme</span><span class="spacer"></span><button class="pack" title="balíček ke stažení — prompt a přílohy v jednom souboru" hidden>zip</button><button class="runs" title="měření — čísla do schránky">měření</button><button class="clear" title="zahodit rozepsaná zadání" hidden>zahodit</button></div>
      <textarea class="manual-copy" readonly hidden aria-label="Zadání k ručnímu zkopírování" spellcheck="false"></textarea>
    </div>
  `;

  const $ = (sel) => shadow.querySelector(sel);
  const panel = $(".panel");
  const input = $("input.cmd");
  const aim = $(".aim");
  const copyBtn = $(".copy");
  const chips = $(".chips");
  const status = $(".status");
  const msg = $(".msg");
  const runsBtn = $(".runs");
  const packBtn = $(".pack");
  const clearBtn = $(".clear");
  const manualCopy = $(".manual-copy");

  // Appka má vlastní nativní rozhraní — paleta ve stránce by jí jen překážela a vytahovala klávesnici.
  const app = Core.surface === "app";
  if (!app) document.documentElement.appendChild(host);

  // --------------------------------------------------------- overlay picker

  // Vrstva jen chytá ťuknutí a kliky. Přesahuje displej, protože WebKit v appce kreslí
  // fixed prvky posunuté, když stránka dojede do odsazení pod lištou.
  const overlay = document.createElement("div");
  overlay.id = "weed-overlay";
  overlay.style.cssText =
    "position:fixed;left:0;right:0;top:-100vh;bottom:-100vh;z-index:2147483646;display:none;cursor:crosshair;" +
    "touch-action:manipulation;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none;";
  const oShadow = overlay.attachShadow({ mode: "open" });
  oShadow.innerHTML = `
    <style>
      .hint { position: fixed; left: 50%; top: 16px; transform: translateX(-50%);
              background: #2c2c2e; color: #f2f2f7; border: 1px solid #48484a; border-radius: 6px;
              padding: 6px 12px; font: 12px/1.4 ui-monospace, monospace; pointer-events: none; }
    </style>
    <style>
      /* Nad vybraným prvkem prst maluje po slovech a stránka se pod ním nehýbe —
         proto touch-action jen tady, a ne na celé vrstvě: vedle vybraného prvku
         se stránkou dál jezdí. */
      .brush { position: absolute; touch-action: none; }
    </style>
    <div class="hint">klik přidá prvek · tažením po vybraném textu úsek · jinde rámeček · Esc zpět</div>
  `;
  if (app) oShadow.querySelector(".hint").remove();
  document.documentElement.appendChild(overlay);

  // Rámečky jsou v souřadnicích dokumentu, ne displeje — fixed rámečky WebKit posune
  // o visualViewport.offsetTop a ukazovaly by jinam, než kam se ťuklo.
  const marks = document.createElement("div");
  marks.id = "weed-marks";
  marks.style.cssText = "position:absolute;left:0;top:0;width:0;height:0;z-index:2147483646;pointer-events:none;display:none;";
  const mShadow = marks.attachShadow({ mode: "open" });
  mShadow.innerHTML = `
    <style>
      /* Clona přes stránku: co není vybrané, jde do pozadí. Vidí ji i ořez, který
         jde jako příloha (§7.6) — na výstřižku je pak poznat, co je cíl.
         V souřadnicích dokumentu jako rámečky, ne fixed: fixed vrstvu WebKit
         posune o visualViewport (otevřená klávesnice) a díra odjede od prvku,
         na kterém rámeček drží. */
      .scrim { position: absolute; pointer-events: none; }
      .box { position: absolute; border: 2px solid #ff9f0a; background: rgba(255,159,10,.12);
             pointer-events: none; border-radius: 2px; box-sizing: border-box; }
      .tag { position: absolute; background: #ff9f0a; color: #1c1c1e; font: 500 11px/1.4 ui-monospace, monospace;
             padding: 1px 5px; border-radius: 3px; pointer-events: none; white-space: nowrap; }
      .marquee { position: absolute; border: 1px dashed #ff9f0a; background: rgba(255,159,10,.08); pointer-events: none; }
      /* „Ukaž mi ten prvek“ je jiná věc než výběr a musí jít rozeznat i vedle něj:
         vybraný prvek je vybraný pořád (bez něj by v promptu nebyl), tohle je
         odpověď na ťuknutí. Proto studená modrá proti teplé oranžové výběru — dvojice,
         kterou rozezná i oko, co nerozliší zelenou od červené — a navrch přes ni. */
      .pulse { position: absolute; border: 3px solid #59b7f0; background: rgba(89,183,240,.16);
               border-radius: 2px; pointer-events: none; z-index: 1;
               box-sizing: border-box; animation: weed-pulse .9s ease-out forwards; }
      @keyframes weed-pulse { from { opacity: 1; } to { opacity: 0; } }
      /* Označený úsek textu uvnitř vybraného prvku. Zvýrazňovač pod písmem, ne
         rámeček kolem: označené slovo musí jít pořád přečíst. */
      .mark { position: absolute; background: rgba(255,214,10,.35); pointer-events: none; border-radius: 2px; }
      :host([data-dark]) .mark { background: rgba(255,214,10,.30); }
      :host([data-dark]) .pulse { box-shadow: 0 0 0 1px rgba(255,255,255,.8); }
    </style>
  `;
  document.documentElement.appendChild(marks);

  /** Obdélník z pohledu displeje (clientX/Y, getBoundingClientRect) na místo ve vrstvě rámečků. */
  function at(left, top, width, height) {
    const o = marks.getBoundingClientRect();
    let css = `left:${left - o.left}px;top:${top - o.top}px;`;
    if (width != null) css += `width:${width}px;height:${height}px;`;
    return css;
  }

  /** Totéž pro vrstvu zaměřovače — ta přesahuje displej nahoru i dolů. */
  function onOverlay(r) {
    const o = overlay.getBoundingClientRect();
    return `left:${r.left - o.left}px;top:${r.top - o.top}px;width:${r.width}px;height:${r.height}px;`;
  }

  let hoverBox = null, hoverTag = null, marquee = null, dragStart = null, brush = null;

  function clearHover() {
    if (hoverBox) { hoverBox.remove(); hoverBox = null; }
    if (hoverTag) { hoverTag.remove(); hoverTag = null; }
  }

  // Odscrolluje k prvkům a blikne na nich (SPEC §2.5). Nic víc — kód ani styly se neukazují.
  function flash(els) {
    if (!els.length) return false;
    els[0].scrollIntoView({ block: "center", inline: "nearest", behavior: "smooth" });
    const draw = () => {
      // Výběr napřed, puls na něj: ukázaný prvek má zůstat čitelný i tam, kde
      // se s vybraným překrývá.
      drawSelection();
      for (const el of els) {
        const r = el.getBoundingClientRect();
        const b = document.createElement("div");
        b.className = "pulse";
        b.style.cssText = at(r.left, r.top, r.width, r.height);
        mShadow.appendChild(b);
        setTimeout(() => b.remove(), 900);
      }
    };
    // Až po dojezdu scrollu — jinak by rámeček zůstal tam, odkud stránka odjela.
    marks.style.display = "block";
    setTimeout(draw, 320);
    return true;
  }

  /*
   * Jak světlý je web pod námi. Rozhoduje o lemu rámečku a o síle clony —
   * jediná sada barev vyjde dobře jen na jednom z obou.
   */
  function pageIsDark() {
    for (const el of [document.body, document.documentElement]) {
      if (!el) continue;
      const bg = getComputedStyle(el).backgroundColor;
      const m = bg && bg.match(/rgba?\(([^)]+)\)/);
      if (!m) continue;
      const [r, g, b, a] = m[1].split(",").map((n) => parseFloat(n));
      if (a === 0) continue;
      return (0.2126 * r + 0.7152 * g + 0.0722 * b) < 128;
    }
    return false;
  }

  /*
   * Clona přes celou stránku s dírou na každém vybraném prvku. Díry se vyrábí
   * maskou, ne čtyřmi obdélníky kolem: prvky bývají rozházené a obdélníkem kolem
   * všech by se zatmavilo i to, co je mezi nimi.
   */
  /* O kolik clona přetéká za okraje stránky — hlavička appky, safe area, pružení. */
  const SCRIM_BLEED = 200;

  function drawScrim(boxes) {
    const old = mShadow.querySelector(".scrim");
    if (old) old.remove();
    if (!boxes.length) return;
    const dark = marks.hasAttribute("data-dark");
    /*
     * Celý dokument, ne displej: boxy chodí ve viewport souřadnicích, tak se
     * o scroll posunou. A ještě o kus dál za každý okraj — pod hlavičkou appky,
     * v safe areách telefonu a při pružení na konci stránky se jinak odhalí
     * nezatmavený pruh a výběr vypadá, že končí dřív, než končí.
     */
    const root = document.documentElement;
    const w = Math.max(root.scrollWidth, innerWidth) + SCRIM_BLEED * 2;
    const h = Math.max(root.scrollHeight, innerHeight) + SCRIM_BLEED * 2;
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("class", "scrim");
    svg.setAttribute("width", w);
    svg.setAttribute("height", h);
    svg.style.cssText = at(-scrollX - SCRIM_BLEED, -scrollY - SCRIM_BLEED, w, h);
    const id = "weed-holes";
    const holes = boxes.map((r) =>
      `<rect x="${r.left + scrollX + SCRIM_BLEED}" y="${r.top + scrollY + SCRIM_BLEED}" width="${r.width}" height="${r.height}" rx="4" fill="black"/>`).join("");
    svg.innerHTML =
      `<defs><mask id="${id}"><rect width="100%" height="100%" fill="white"/>${holes}</mask></defs>` +
      `<rect width="100%" height="100%" fill="rgba(0,0,0,${dark ? 0.62 : 0.45})" mask="url(#${id})"/>`;
    // Před rámečky, ať je nepřekryje.
    mShadow.insertBefore(svg, mShadow.firstChild);
  }

  /*
   * Kolik stránky zůstane kolem vybraného prvku. Je to jedno číslo pro díru
   * v cloně i pro ořez (`bounds`), protože je to totéž sdělení: tohle je cíl a
   * tohle uvidí agent na příloze. Kdyby se čísla rozešla, uživatel by mířil na
   * jeden výřez a vyfotil jiný.
   */
  const SEL_PAD = 16;

  /*
   * Vybraný prvek se neobkresluje. Clona kolem něj řekne totéž a řekne to líp:
   * rámeček je čára navíc přes cizí design, kdežto díra ve cloně je přesně to,
   * co uvidí agent na příloze.
   */
  function drawSelection() {
    marks.toggleAttribute("data-dark", pageIsDark());
    const boxes = [];
    for (const el of state.selection) {
      const r = el.getBoundingClientRect();
      // Rámeček i díra v cloně sedí na odsazeném obdélníku: prvek pak zůstane
      // celý vidět a kolem něj je kousek stránky, ve které stojí.
      const box = {
        left: r.left - SEL_PAD, top: r.top - SEL_PAD,
        width: r.width + SEL_PAD * 2, height: r.height + SEL_PAD * 2,
      };
      boxes.push(box);
    }
    drawScrim(boxes);
    drawQuotes();
    drawBrush();
  }

  function describe(el) {
    const r = el.getBoundingClientRect();
    const cls = el.className && typeof el.className === "string"
      ? "." + el.className.trim().split(/\s+/).slice(0, 2).join(".")
      : "";
    return `${el.tagName.toLowerCase()}${el.id ? "#" + el.id : cls}  ${Math.round(r.width)}×${Math.round(r.height)}`;
  }

  /*
   * Na co uživatel ukázal. Pod bodem leží nejhlubší uzel a ten bývá kus prvku,
   * ne prvek — proto se vrací celek ve dvou smyslech.
   *
   * `elementFromPoint` uvnitř SVG vrátí `<path>` — tvar, na který nikdo
   * necílil: na obrazovce je vidět ikona a prst mířil na ikonu. Tvary uvnitř
   * nejsou prvky stránky, ale kresba jednoho prvku, a zadání nad jedním z nich
   * rozbije zbytek: RSS ikona bývá ze tří `<path>` a zmenšit první z nich
   * znamená ikonu na kusy. Míří se proto na celé `<svg>`.
   *
   * `<foreignObject>` je výjimka — uvnitř je normální HTML a tam se ukazuje na
   * prvek, ne na kresbu.
   *
   * V HTML dělá totéž `Core.meaningful` (SPEC §2.1): holý inline obal kolem
   * slova není cíl, cíl je odstavec, odkaz nebo tlačítko kolem něj.
   */
  function whole(el) {
    const svg = el.closest && el.closest("svg");
    if (!svg || svg === el) return Core.meaningful(el);
    const fo = el.closest("foreignObject");
    if (fo && svg.contains(fo)) return Core.meaningful(el);
    return svg;
  }

  function elementAt(x, y) {
    overlay.style.pointerEvents = "none";
    const el = document.elementFromPoint(x, y);
    overlay.style.pointerEvents = "auto";
    if (!el || el === host || el === overlay || el === marks || host.contains(el)) return null;
    return whole(el);
  }


  // --------------------------------------------------------- úseky textu

  /*
   * Uvnitř vybraného prvku jde označit i kus textu (SPEC §2.1). Ťuknutí dál
   * vybírá celý odstavec — úsek je vrstva nad tím, pro zadání typu „tohle slovo
   * změň na jiné“, kde by celý odstavec poslal agenta přepsat víc, než měl.
   *
   * Úsek se drží jako živý `Range`, ne jako řetězec: podle něj se kreslí
   * zvýraznění a teprve při sestavení požadavku se z něj spočítá, o kolikátý
   * výskyt v prvku jde. Vedou k němu dvě cesty a obě končí tady:
   *
   * - **nativní výběr prohlížeče** (tap-hold, dvojklik) mimo zadávání, odkud ho
   *   povrch podá přes `weed.quote()` — je to jeho vlastní nabídka nad výběrem
   * - **tah prstem po vybraném prvku** v zadávání, kde nativní výběr není:
   *   vrstva zaměřovače ťuknutí ke stránce nepustí
   */

  const quoteString = (range) => String(range).replace(/\s+/g, " ").trim();

  /** Úseky prvku, co jich v dokumentu zbylo — SPA vymění text pod rukama. */
  function quotesOf(el) {
    const list = state.quotes.get(el);
    if (!list) return [];
    const live = list.filter((r) => r.startContainer.isConnected && r.endContainer.isConnected && quoteString(r));
    if (live.length !== list.length) setQuotes(el, live);
    return live;
  }

  function setQuotes(el, list) {
    if (list.length) state.quotes.set(el, list);
    else state.quotes.delete(el);
  }

  /** Kolik úseků je označeno dohromady — povrch s vlastním rozhraním to ukazuje sám. */
  function tellQuotes() {
    let n = 0;
    for (const el of state.selection) n += quotesOf(el).length;
    tell("weed:quotes", n);
  }

  /** Rozsahy v pořadí dokumentu; co se překrývá nebo dělí jen mezera, je jeden úsek. */
  function mergeQuotes(list) {
    const sorted = [...list].sort((a, b) => a.compareBoundaryPoints(Range.START_TO_START, b));
    const out = [];
    for (const range of sorted) {
      const last = out[out.length - 1];
      const touches = last && last.compareBoundaryPoints(Range.START_TO_END, range) >= 0;
      const gap = last && !touches && document.createRange();
      if (gap) {
        gap.setStart(last.endContainer, last.endOffset);
        gap.setEnd(range.startContainer, range.startOffset);
      }
      if (last && (touches || !String(gap).trim())) {
        if (last.compareBoundaryPoints(Range.END_TO_END, range) < 0) last.setEnd(range.endContainer, range.endOffset);
        continue;
      }
      out.push(range.cloneRange());
    }
    return out;
  }

  /*
   * Úsek jako data požadavku: co je označené a o kolikátý výskyt v prvku jde.
   * Pořadí výskytu je tu proto, že „cena“ bývá v odstavci třikrát — a agent,
   * který to nepozná, přepíše první (zásada 8).
   */
  function serializeQuotes(el) {
    const out = [];
    for (const range of mergeQuotes(quotesOf(el))) {
      const text = quoteString(range);
      if (!text) continue;
      let nth = 1;
      try {
        const before = document.createRange();
        before.setStart(el, 0);
        before.setEnd(range.startContainer, range.startOffset);
        const prefix = String(before).replace(/\s+/g, " ");
        for (let at = prefix.indexOf(text); at >= 0; at = prefix.indexOf(text, at + 1)) nth++;
      } catch (_) { nth = 1; }
      out.push({ text, nth });
    }
    return out;
  }

  /** Označené texty napříč výběrem — úryvek, na který uživatel ukázal uvnitř cíle (§2.1). */
  function quoteTexts() {
    const out = [];
    for (const el of state.selection) for (const q of serializeQuotes(el)) out.push(q.text);
    return out;
  }

  function drawQuotes() {
    mShadow.querySelectorAll(".mark").forEach((n) => n.remove());
    for (const el of state.selection) {
      for (const range of quotesOf(el)) {
        for (const r of range.getClientRects()) {
          if (!r.width || !r.height) continue;
          const mark = document.createElement("div");
          mark.className = "mark";
          mark.style.cssText = at(r.left, r.top, r.width, r.height);
          mShadow.appendChild(mark);
        }
      }
    }
  }

  /** Plocha, na které prst maluje po slovech — jen nad vybranými prvky. */
  function drawBrush() {
    oShadow.querySelectorAll(".brush").forEach((n) => n.remove());
    if (!state.picking) return;
    for (const el of state.selection) {
      const r = el.getBoundingClientRect();
      if (!r.width || !r.height) continue;
      const b = document.createElement("div");
      b.className = "brush";
      b.style.cssText = onOverlay(r);
      oShadow.appendChild(b);
    }
  }

  /*
   * Nejbližší prvek s vlastním boxem (SPEC §2.1). Výběr textu uvnitř `<b>` nebo
   * `<span>` míří na odstavec kolem — holý inline obal není cíl, o kterém by
   * uživatel mluvil.
   */
  /*
   * Prvek, který nese text sám — odstavec, nadpis, položka, tlačítko. Na takovém
   * se po výběru označují slova; blok, ve kterém text jen leží (karta, sekce),
   * zůstává obyčejným cílem a druhé ťuknutí ho odznačí.
   */
  const hasOwnText = (el) =>
    Array.prototype.some.call(el.childNodes, (n) => n.nodeType === 3 && n.data.trim());

  /** Slovo pod prstem uvnitř vybraného textového prvku — jinak nic. */
  function wordInSelection(x, y) {
    const word = wordAt(x, y);
    const el = word && selectedAncestor(word.startContainer);
    return el && hasOwnText(el) ? { el, word } : null;
  }

  /** Označí, nebo odznačí slovo. Vrací, co se stalo — pro popisek vráceného kroku. */
  function toggleWord(el, word) {
    const list = quotesOf(el);
    const has = list.some((r) => covers(r, word));
    rememberQuotes(has ? "odznačený text" : "označený text");
    setQuotes(el, has ? withoutWord(list, word) : mergeQuotes([...list, word]));
    return !has;
  }

  /** Vybraný prvek, pod který spadá tenhle uzel — v něm se text označuje. */
  function selectedAncestor(node) {
    for (let n = node && node.nodeType === 1 ? node : node && node.parentElement; n; n = n.parentElement) {
      if (state.selection.includes(n)) return n;
    }
    return null;
  }

  /** Slovo pod prstem. Vrstva zaměřovače se na chvíli odpojí — kradla by hit test. */
  function wordAt(x, y) {
    overlay.style.pointerEvents = "none";
    let range = null;
    try {
      if (document.caretRangeFromPoint) {
        range = document.caretRangeFromPoint(x, y);
      } else if (document.caretPositionFromPoint) {
        const pos = document.caretPositionFromPoint(x, y);
        if (pos) {
          range = document.createRange();
          range.setStart(pos.offsetNode, pos.offset);
          range.collapse(true);
        }
      }
    } catch (_) { range = null; }
    overlay.style.pointerEvents = "auto";
    const node = range && range.startContainer;
    if (!node || node.nodeType !== 3) return null;
    const data = node.data;
    let start = range.startOffset, end = range.startOffset;
    // Prst mezi slovy neoznačuje nic — jinak by tah přes mezeru spolkl obě sousední slova.
    if (!/\S/.test(data.slice(Math.max(0, start - 1), start + 1))) return null;
    while (start > 0 && /\S/.test(data[start - 1])) start--;
    while (end < data.length && /\S/.test(data[end])) end++;
    // Tečka za slovem není slovo. Do úseku by se dostala a agent by na ni grepoval.
    const letter = /[\p{L}\p{N}]/u;
    while (end > start && !letter.test(data[end - 1])) end--;
    while (start < end && !letter.test(data[start])) start++;
    if (start === end) return null;
    const word = document.createRange();
    word.setStart(node, start);
    word.setEnd(node, end);
    /*
     * `caretRangeFromPoint` vrací nejbližší pozici i pro bod, kde žádný text není —
     * v odsazení bloku nebo vedle posledního řádku. Slovo proto platí jen tehdy,
     * když prst leží opravdu na něm; jinak je to ťuknutí na prvek, ne na text.
     */
    const on = Array.from(word.getClientRects()).some((r) =>
      x >= r.left - 2 && x <= r.right + 2 && y >= r.top - 2 && y <= r.bottom + 2);
    return on ? word : null;
  }

  const covers = (range, word) =>
    range.compareBoundaryPoints(Range.START_TO_START, word) <= 0 &&
    range.compareBoundaryPoints(Range.END_TO_END, word) >= 0;

  /** Odznačené slovo uprostřed úseku ho rozdělí na dva — proto se ořezává, nemaže. */
  function withoutWord(list, word) {
    const out = [];
    for (const range of list) {
      const apart = range.compareBoundaryPoints(Range.START_TO_END, word) <= 0 ||
                    range.compareBoundaryPoints(Range.END_TO_START, word) >= 0;
      if (apart) { out.push(range); continue; }
      const left = range.cloneRange();
      left.setEnd(word.startContainer, word.startOffset);
      const right = range.cloneRange();
      right.setStart(word.endContainer, word.endOffset);
      for (const part of [left, right]) if (quoteString(part)) out.push(part);
    }
    return out;
  }

  /** Označený text se vrací celý — tah přes pět slov je jedna akce, ne pět. */
  function rememberQuotes(label) {
    const before = new Map([...state.quotes].map(([el, list]) => [el, list.map((r) => r.cloneRange())]));
    remember(label, () => { state.quotes = before; });
  }

  /*
   * Tah prstem po vybraném prvku. Co tah dělá, rozhodne první slovo pod ním:
   * začátek na označeném odznačuje, jinde označuje. Jeden tah tedy nikdy
   * neudělá obojí — prst, který přejede přes hranici, by jinak přepínal.
   */
  function brushAt(e) {
    const word = wordAt(e.clientX, e.clientY);
    if (!word) return;
    const el = selectedAncestor(word.startContainer);
    if (!el || !hasOwnText(el) || (brush && brush.el !== el)) return;
    const list = quotesOf(el);
    const has = list.some((r) => covers(r, word));
    if (!brush) {
      rememberQuotes(has ? "odznačený text" : "označený text");
      brush = { el, off: has };
    }
    if (brush.off !== has) return;
    setQuotes(el, brush.off ? withoutWord(list, word) : mergeQuotes([...list, word]));
    drawSelection();
    tellQuotes();
  }

  // Pointer, ne myš: na telefonu je ťuknutí a tah prstem totéž co klik a tažení.
  overlay.addEventListener("pointermove", (e) => {
    // Tah po vybraném prvku označuje text, tah jinde dělá rámeček. Rozhodne se
    // až podle pohybu — ťuknutí na vybraný prvek ho pořád odznačí.
    if (dragStart && (brush || (dragStart.on && (Math.abs(e.clientX - dragStart.x) > 4 || Math.abs(e.clientY - dragStart.y) > 4)))) {
      clearHover();
      brushAt(e);
      return;
    }
    if (dragStart) {
      const x = Math.min(dragStart.x, e.clientX), y = Math.min(dragStart.y, e.clientY);
      const w = Math.abs(e.clientX - dragStart.x), h = Math.abs(e.clientY - dragStart.y);
      if (!marquee) {
        marquee = document.createElement("div");
        marquee.className = "marquee";
        mShadow.appendChild(marquee);
      }
      marquee.style.cssText = at(x, y, w, h);
      return;
    }
    const el = elementAt(e.clientX, e.clientY);
    clearHover();
    if (!el) return;
    const r = el.getBoundingClientRect();
    hoverBox = document.createElement("div");
    hoverBox.className = "box";
    hoverBox.style.cssText = at(r.left, r.top, r.width, r.height);
    hoverTag = document.createElement("div");
    hoverTag.className = "tag";
    hoverTag.textContent = describe(el);
    hoverTag.style.cssText = at(r.left, Math.max(2, r.top - 20));
    mShadow.append(hoverBox, hoverTag);
  });

  overlay.addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    brush = null;
    const under = selectedAncestor(elementAt(e.clientX, e.clientY));
    dragStart = { x: e.clientX, y: e.clientY, on: under && hasOwnText(under) ? under : null };
    e.preventDefault();
  });

  // Vrstva po ťuknutí zmizí a iOS by pak poslal klik na odkaz pod ní — stránka by odešla jinam.
  overlay.addEventListener("touchend", (e) => e.preventDefault(), { passive: false });

  /*
   * Ťuknutí při míření patří nám. Vrstva po něm mizí a prohlížeč pak doručí
   * click — ve WKWebView i myší události — prvku pod ní: Wikimedia na nadpis
   * rozbalí sekci, odkaz odvede jinam. Proto se na window v capture fázi, dřív
   * než to uvidí stránka, spolknou dokončovací události mimo naše UI, a ještě
   * chvíli po skončení míření, kdy dojíždějí.
   */
  const SWALLOW_MS = 400;
  let swallowUntil = 0;
  const swallow = (e) => {
    if (!state.picking && performance.now() > swallowUntil) return;
    const path = e.composedPath();
    // UI palety funguje dál; na vrstvě jen pointerup, na kterém stojí výběr — zbytek by
    // stránka viděla přes posluchače na document (Wikimedia tak deleguje kliky).
    if (path.includes(host)) return;
    if (e.type === "pointerup" && (path.includes(overlay) || path.includes(marks))) return;
    e.preventDefault();
    e.stopImmediatePropagation();
  };
  for (const type of ["click", "dblclick", "auxclick", "contextmenu", "pointerup", "mouseup", "touchend"]) {
    window.addEventListener(type, swallow, { capture: true, passive: false });
  }

  // Prst stránku posouvá — i při míření se dá dojet k dalšímu prvku.
  overlay.addEventListener("pointercancel", () => {
    dragStart = null;
    brush = null;
    if (marquee) { marquee.remove(); marquee = null; }
    clearHover();
  });

  window.addEventListener("scroll", () => {
    if (!state.picking) return;
    clearHover();
    drawSelection();
  }, { capture: true, passive: true });

  overlay.addEventListener("pointerup", (e) => {
    const start = dragStart;
    const brushed = brush;
    dragStart = null;
    brush = null;
    if (marquee) { marquee.remove(); marquee = null; }
    if (!start) return;
    // Tah po textu je označení úseku, ne výběr prvků — výběru se nedotkne.
    if (brushed) { changed(); return; }

    const moved = Math.abs(e.clientX - start.x) > 4 || Math.abs(e.clientY - start.y) > 4;

    /*
     * Vybraný odstavec je od téhle chvíle plocha pro slova: další ťuknutí do jeho
     * textu slovo označí a další ho odznačí (SPEC §2.1). Vidět je to hned —
     * zvýraznění se překreslí pod prstem. Celý prvek se odznačuje křížkem
     * u náhledu ve větě; na textu má ťuknutí důležitější práci.
     */
    const mark = moved ? null : wordInSelection(e.clientX, e.clientY);
    if (mark) {
      toggleWord(mark.el, mark.word);
      changed();
      return;
    }

    // Krok se pamatuje dřív, než se výběr změní — a popisek se pozná z toho,
    // co ťuknutí udělá: tažení jen přidává, ťuknutí na vybraný prvek ho bere.
    const hit = moved ? null : elementAt(e.clientX, e.clientY);
    if (moved || hit) rememberSelection(!moved && state.stay && state.selection.includes(hit) ? "odznačený prvek" : "vybraný prvek");

    if (moved) {
      // tažení — rámeček vybere všechny elementy, které protne
      const box = {
        left: Math.min(start.x, e.clientX), top: Math.min(start.y, e.clientY),
        right: Math.max(start.x, e.clientX), bottom: Math.max(start.y, e.clientY),
      };
      const hits = [];
      for (const el of document.body.querySelectorAll("*")) {
        if (el === host || el === overlay || host.contains(el)) continue;
        // Jen celky: tvary uvnitř SVG a holé obaly kolem slov se přeskočí —
        // jinak rámeček vybere hrst <path> místo ikony a <span> místo odstavce.
        // Prvek, na který se vystoupalo, do rámečku spadne sám.
        if (whole(el) !== el) continue;
        const r = el.getBoundingClientRect();
        if (r.width === 0 || r.height === 0) continue;
        const intersects = !(r.right < box.left || r.left > box.right || r.bottom < box.top || r.top > box.bottom);
        if (!intersects) continue;
        // jen nejvnitřnější — ať se nevybere celý <body>
        if (hits.some((h) => h.contains(el))) hits.splice(hits.findIndex((h) => h.contains(el)), 1);
        if (!hits.some((h) => el.contains(h))) hits.push(el);
      }
      for (const el of hits) if (!state.selection.includes(el)) state.selection.push(el);
    } else {
      // Výběr jen přibývá — odebírá se křížkem na chipu, jinak by další míření smazalo to předchozí.
      // Při trvalém míření (appka, kde chipy nejsou) odebere vybraný prvek druhé ťuknutí.
      const el = elementAt(e.clientX, e.clientY);
      const i = el ? state.selection.indexOf(el) : -1;
      if (el && i < 0) state.selection.push(el);
      else if (el && state.stay) state.selection.splice(i, 1);
    }
    if (state.stay) changed();
    else stopPicking();
  });

  // ------------------------------------------------------------- ovládání

  /*
   * Paleta drží místo a velikost na displeji, ne ve stránce. Web bez
   * viewport meta je na telefonu 980 px široký a zmenšený — řádek palety by
   * měl pár bodů a iOS by při psaní stránku přiblížil a paletu odsunul z
   * displeje. Stejně tak při přiblížení prsty a nad klávesnicí.
   */
  const vv = window.visualViewport;

  /*
   * Kam si paletu uživatel odtáhl (SPEC §2.6). Dole uprostřed je dobré místo,
   * dokud tam web nemá cookie lištu, chat nebo zrovna ten prvek, na který se
   * ukazuje — pak paleta překáží zrovna tomu, kvůli čemu je otevřená.
   *
   * Drží se odsazení od levého horního rohu displeje, ne od stránky: paleta
   * stojí na displeji (viz `pin`), takže se nesmí rozejít při scrollu ani při
   * přiblížení prsty. `null` znamená „nikam odtaženo“ — výchozí místo.
   *
   * Do cizího dokumentu se pozice neukládá (zásada 2), takže po načtení
   * stránky stojí paleta zase dole. Je to vědomá výměna: pamatovat si ji
   * jinde než v paměti by znamenalo zapsat do stránky, kterou neměníme.
   */
  const spot = { x: null, y: null };

  function pin() {
    if (!vv || panel.dataset.open !== "true") return;
    const t = 1 / vv.scale;
    const width = Math.min(640, vv.width * vv.scale - 32);
    const size = `bottom:auto;width:${width}px;transform-origin:0 0;`;
    if (spot.x === null) {
      panel.style.cssText =
        `left:${vv.offsetLeft + vv.width / 2}px;top:${vv.offsetTop + vv.height - 40 * t}px;` + size +
        `transform:scale(${t}) translate(-50%,-100%);`;
      return;
    }
    /* Panel musí zůstat celý na displeji: odtažený za okraj by se nedal chytit
       zpátky, a po otočení telefonu nebo zmenšení okna by zmizel sám od sebe. */
    const edge = 8;
    const w = width * t, h = panel.offsetHeight * t || 0;
    const x = Math.min(Math.max(spot.x, edge), Math.max(edge, vv.width - w - edge));
    const y = Math.min(Math.max(spot.y, edge), Math.max(edge, vv.height - h - edge));
    panel.style.cssText =
      `left:${vv.offsetLeft + x}px;top:${vv.offsetTop + y}px;` + size + `transform:scale(${t});`;
  }

  /*
   * Tažení palety. Chytá se za plochu panelu — ne za zvláštní úchyt, protože
   * ten by zabral místo v řádku, který má jen tři prvky. Co se ovládá nebo
   * v čem se píše, tažení nezačíná: jinak by se ve vstupu nedalo označit slovo
   * a tlačítko by se při nepatrném pohybu ruky nespustilo.
   */
  const DRAG_SKIP = "input, textarea, button, a, select, [contenteditable]";
  let drag = null;

  panel.addEventListener("pointerdown", (e) => {
    if (e.pointerType === "mouse" && e.button !== 0) return;
    const hit = e.composedPath()[0];
    if (hit && hit.closest && hit.closest(DRAG_SKIP)) return;
    const r = panel.getBoundingClientRect();
    drag = { id: e.pointerId, dx: e.clientX - r.left, dy: e.clientY - r.top };
    panel.dataset.dragging = "true";
    try { panel.setPointerCapture(e.pointerId); } catch (_) { /* bez zachycení jede dál */ }
  });

  panel.addEventListener("pointermove", (e) => {
    if (!drag || e.pointerId !== drag.id) return;
    e.preventDefault();
    const left = vv ? vv.offsetLeft : 0, top = vv ? vv.offsetTop : 0;
    spot.x = e.clientX - drag.dx - left;
    spot.y = e.clientY - drag.dy - top;
    pin();
  });

  const dragEnd = (e) => {
    if (!drag || e.pointerId !== drag.id) return;
    try { panel.releasePointerCapture(drag.id); } catch (_) { /* už uvolněné */ }
    delete panel.dataset.dragging;
    drag = null;
  };
  panel.addEventListener("pointerup", dragEnd);
  panel.addEventListener("pointercancel", dragEnd);
  if (vv) {
    vv.addEventListener("resize", pin);
    vv.addEventListener("scroll", pin);
  }

  function open(focus) {
    state.open = true;
    panel.dataset.open = "true";
    pin();
    if (focus !== false) input.focus();
    save();
  }
  function close() {
    state.open = false;
    panel.dataset.open = "false";
    stopPicking();
    save();
  }
  function toggle() { state.open ? close() : open(); }

  // stay: míření trvá, dokud ho povrch nevypne — appka tak vybírá víc prvků a mezitím se diktuje.
  function startPicking(opts) {
    state.picking = true;
    state.stay = !!(opts && opts.stay);
    aim.dataset.active = "true";
    panel.dataset.open = "false";
    overlay.style.display = "block";
    marks.style.display = "block";
    drawSelection();
  }
  function stopPicking() {
    if (state.picking) swallowUntil = performance.now() + SWALLOW_MS;
    state.picking = false;
    state.stay = false;
    aim.dataset.active = "false";
    overlay.style.display = "none";
    marks.style.display = "none";
    clearHover();
    mShadow.querySelectorAll(".box.sel, .scrim, .mark").forEach((n) => n.remove());
    oShadow.querySelectorAll(".brush").forEach((n) => n.remove());
    if (state.open) { panel.dataset.open = "true"; pin(); input.focus(); }
    renderChips();
  }

  function changed() {
    if (state.picking) drawSelection();
    renderChips();
    if (state.open) input.focus();
  }

  function renderChips() {
    // Panel povyroste o řádek chipů; odtažený by jinak přerostl spodní okraj.
    if (spot.x !== null) requestAnimationFrame(pin);
    // Turbo a SPA vymění stránku pod rukama — prvek, který už v ní není, nevisí na promptu.
    state.selection = state.selection.filter((el) => el.isConnected);
    // Úsek textu patří prvku: odznačený prvek si ho bere s sebou.
    for (const el of [...state.quotes.keys()]) if (!state.selection.includes(el)) state.quotes.delete(el);
    chips.innerHTML = "";
    state.selection.forEach((el, i) => {
      const chip = document.createElement("span");
      chip.className = "chip";
      const text = (el.textContent || "").trim().replace(/\s+/g, " ").slice(0, 28);
      chip.innerHTML = `<b>${el.tagName.toLowerCase()}</b><i>${text}</i>`;
      const x = document.createElement("button");
      x.textContent = "×";
      x.setAttribute("aria-label", "odebrat");
      x.addEventListener("click", () => {
        rememberSelection("odznačený prvek");
        state.selection.splice(i, 1);
        changed();
      });
      chip.appendChild(x);
      chips.appendChild(chip);
    });
    tell("weed:selection", state.selection.length);
    tellQuotes();
  }

  /*
   * Jediné místo, kde vzniká požadavek z palety — aby označený text nemohl
   * vypadnout tím, že si ho jedna cesta nepřibalí.
   */
  function requestFor(opts) {
    const els = opts.elements || [];
    return Prompt.request({ ...opts, mcp: state.mcp, quotes: els.map(serializeQuotes) });
  }

  function report(result) {
    const labels = { kill: "zabito", ask: "doplň" };
    status.dataset.kind = result.verdict || "";
    let body;
    if (result.zip) body = `balíček · ${result.zip} ${result.zip < 5 ? "soubory" : "souborů"} · ${result.chars} znaků`;
    else if (result.verdict === "prompt") {
      const what = result.count ? `${result.count} zadání` : "prompt";
      body = result.copied == null ? `pro agenta · ${result.chars} znaků`
        : result.copied ? `${what} ve schránce · ${result.chars} znaků` : "schránka odmítla — zkopíruj označený text ručně";
      if (result.reason) body += ` · ${result.reason}`;
    } else body = result.reason || result.question || "";
    msg.textContent = "";
    msg.append([labels[result.verdict], body].filter(Boolean).join(" "));
    syncButtons();
  }

  function syncButtons() {
    clearBtn.hidden = state.list.length === 0;
    // Prázdný balíček se nenabízí: tlačítko, které jen vynadá, je tlačítko navíc.
    packBtn.hidden = state.list.length === 0;
    tell("weed:list", state.list.length);
  }

  /** Povrch s vlastním rozhraním (appka) se dozví, kolik je vybráno a kolik je v seznamu. */
  function tell(name, n) {
    events.dispatchEvent(new CustomEvent(name, { detail: String(n) }));
  }

  /*
   * Vrácení poslední akce (SPEC §2.6). Zásobník drží jádro, ne povrch: tlačítko
   * v appce, ⌘Z v paletě a shake na telefonu vracejí tutéž věc.
   *
   * V zásobníku je jen to, co uživatel udělal v zadávání a co jde vrátit beze
   * zbytku: vybraný a odznačený prvek, přidané zadání, přepsaný text zadání.
   * Tři věci v něm schválně nejsou, a ne „zatím":
   *
   * - **smazání zadání a zahození seznamu** — obojí je za potvrzením, a dvě
   *   pojistky na jednu akci si odporují: s vrácením je potvrzení navíc,
   *   s potvrzením vrácení mate.
   * - **přílohy** — odebrat přílohu znamená smazat soubor z disku, a to je jiná
   *   třída rizika než vrátit výběr nebo text. Zásobník, ve kterém jeden krok
   *   přepne zvýraznění a druhý nenávratně smaže obrázek, je zásobník, kterému
   *   uživatel přestane věřit. Mínus v přehledu je přitom jedno ťuknutí daleko.
   * - **text ve vstupu** — tam vrácení patří klávesnici a systémovému shake,
   *   a diktování text přepisuje průběžně; společný zásobník by znamenal, že
   *   ⌘Z jednou smaže slovo a jednou odebere prvek.
   *
   * Zásobník **nepřežije načtení stránky**: prvky po něm nejsou tytéž a vracet
   * výběr, který se možná netrefí, je horší než nevracet nic.
   *
   * Až bude přímá úprava (§2.2), přidá si sem krok, který ji vrátí — proto je
   * krok obyčejná dvojice popisek a funkce, ne výčet druhů akcí.
   */
  const UNDO_DEPTH = 20;
  let undoing = false;

  function remember(label, undo, text) {
    if (undoing) return;
    // Nová akce po vrácení ruší cestu vpřed — od téhle chvíle vede jinudy.
    if (state.redoStack.length) { state.redoStack = []; tell("weed:redo", 0); }
    state.undoStack.push({ label, undo, text });
    if (state.undoStack.length > UNDO_DEPTH) state.undoStack.shift();
    tell("weed:undo", state.undoStack.length);
  }

  /*
   * Stav, na který se dá vrátit. Jednotlivé kroky umějí jen krok zpátky — dopředu
   * by každý musel umět i svůj opak, a to je dvojnásob kódu na každé akci. Otisk
   * stavu je jeden a platí pro všechny.
   *
   * Výběr jsou živé prvky stránky, ty se kopírovat nesmějí — kopíruje se pole.
   * Seznam ano: `rewrite` a `attach` sahají do `req`, takže mělká kopie pole by
   * změnu nezachytila.
   */
  function snapshot() {
    return {
      selection: [...state.selection],
      quotes: new Map([...state.quotes].map(([el, list]) => [el, list.map((r) => r.cloneRange())])),
      list: state.list.map((it) => ({ ...it, req: { ...it.req, shots: [...(it.req.shots || [])] } })),
      text: input.value,
    };
  }

  function rewind(shot) {
    state.selection = [...shot.selection];
    state.quotes = new Map([...shot.quotes].map(([el, list]) => [el, list.map((r) => r.cloneRange())]));
    state.list = shot.list.map((it) => ({ ...it, req: { ...it.req, shots: [...(it.req.shots || [])] } }));
    input.value = shot.text;
    state.lastPrompt = renderAll();
    save();
    syncButtons();
  }

  /*
   * Výběr se vrací celý — pořadí v něm je pořadí zadání a u přesunu i cíl.
   * S ním i označené úseky: odznačený prvek si je bere s sebou, takže bez nich
   * by se vrátil prvek bez toho, co v něm bylo označené.
   */
  function rememberSelection(label) {
    const before = [...state.selection];
    const quotes = new Map([...state.quotes].map(([el, list]) => [el, list.map((r) => r.cloneRange())]));
    remember(label, () => { state.selection = before; state.quotes = quotes; });
  }

  async function toClipboard(text) {
    // Povrch s vlastní schránkou (appka) si text vezme sám; navigator.clipboard na http neexistuje.
    if (!events.dispatchEvent(new CustomEvent("weed:copy", { detail: text, cancelable: true }))) return true;
    if (navigator.clipboard && window.isSecureContext) {
      try { await navigator.clipboard.writeText(text); return true; } catch (_) { /* bez gesta nebo povolení — zkusí se postaru */ }
    }
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("aria-hidden", "true");
    ta.style.cssText = "position:fixed;top:0;left:0;width:1px;height:1px;opacity:0;";
    shadow.appendChild(ta);
    ta.focus();
    ta.select();
    let ok = false;
    try { ok = document.execCommand("copy"); } catch (_) { ok = false; }
    ta.remove();
    if (state.open) input.focus();
    return ok;
  }

  /**
   * Konec každého běhu: ukázat výsledek a zapsat záznam (SPEC §7.4) —
   * verdikt, délka, nikdy obsah. Záznam jen vysíláme; ukládá ho
   * rozšíření ve svém světě, jádro k úložišti nesahá.
   */
  function finish(req, run, status) {
    report(status);
    events.dispatchEvent(new CustomEvent("weed:run", { detail: JSON.stringify(Prompt.record(req, run)) }));
    events.dispatchEvent(new CustomEvent("weed:result", { detail: status }));
    return status;
  }

  /** Běh k požadavku — totéž id, aby šly spárovat (§7.3). */
  const runOf = (req, result, verdict) =>
    Prompt.run({ id: req.id, verdict: verdict || (result && result.verdict) });

  /*
   * Prompt celého seznamu. Podklady se přidávají prvnímu zadání, protože vrstva
   * `papers` je společná — stojí nad seznamem, ne v něm, a čte se z něj jednou.
   */
  function renderAll() {
    if (!state.list.length) return null;
    // Síť se lepí jen k té stránce, na které zrovna stojíme: entries jiné stránky
    // už prohlížeč nemá a přilepit je pod cizí adresu by bylo hádání (zásada 8).
    let here = null, net = null;
    if (state.network) {
      // Chyba jedné vrstvy nesmí shodit celek (zásada 5) — bez sítě jde prompt dál.
      try { here = location.href; net = Prompt.network(window); } catch (_) { here = null; net = null; }
    }
    let attached = false;
    const items = state.list.map((it, i) => {
      const req = i ? { ...it.req } : { ...it.req, papers: state.papers };
      if (net && !attached && it.req.web && it.req.web.url === here) {
        req.network = net;
        attached = true;
      }
      return { ...it, req };
    });
    return Prompt.renderList(items);
  }

  async function copyList() {
    const list = renderAll();
    // Do schránky jde sebenosná verze (SPEC §7.9): agent se nemůže doptat.
    // Appka má vlastní rámec, a v něm i text, který si uživatel napsal k webu
    // — tam by šel dvakrát. Měří se to, co odešlo, ne to, co se složilo.
    const built = Core.surface === "app" ? list : Prompt.frame(list);
    state.lastPrompt = built;
    const copied = await toClipboard(built);
    manualCopy.hidden = copied;
    manualCopy.value = copied ? "" : built;
    if (!copied) { manualCopy.focus(); manualCopy.select(); }
    return { copied, chars: built.length, count: state.list.length };
  }

  /**
   * Enter přidá zadání do rozepsaného seznamu (SPEC §2.6) a do schránky jde
   * celý seznam — další Enter ho přepíše delší verzí. Zadání nejde do modelu,
   * jde ven jako balíček (§2.4) a věta v něm zůstává doslova (§7.1). Stránku
   * Web Editor neupravuje — to udělá agent, kterému uživatel prompt odnese.
   */
  async function submit() {
    const text = input.value.trim();
    if (!text && !state.selection.length) {
      if (!state.list.length) return report({ verdict: "kill", reason: "Není co poslat — vyber elementy nebo napiš zadání." });
      const copy = await copyList();
      return report({ verdict: "prompt", ...copy });
    }
    input.value = "";
    const added = addToList(text);
    await shotFor(added.req.id);
    const copy = await copyList();
    return finish(added.req, added.run, { verdict: "prompt", ...copy, reason: added.reason });
  }

  function addToList(text, attachments) {
    // Vrácení dá zpátky položku, výběr i text — zadání se rozepsalo znovu, ne od nuly.
    const selection = [...state.selection];
    remember("přidané zadání", () => {
      state.list.pop();
      state.selection = selection;
      state.lastPrompt = renderAll();
      save();
      syncButtons();
    }, String(text || ""));
    const result = Core.run(text, state.selection);
    const req = requestFor({ text, elements: state.selection, doc: document, origin: "palette", attachments });
    const run = runOf(req, result, "prompt");
    run.chars = Prompt.render(req, run).length;
    state.list.push({ req, run });
    save();
    state.selection = [];
    changed();
    const reason = result.verdict === "prompt" ? null : result.reason || result.question || null;
    return { req, run, reason };
  }

  function discard() {
    state.list = [];
    state.lastPrompt = null;
    manualCopy.hidden = true;
    manualCopy.value = "";
    save();
    status.dataset.kind = "";
    msg.textContent = "zadání zahozena";
    syncButtons();
    if (state.open) input.focus();
  }

  /*
   * Rozepsaný seznam a otevřená paleta přežijí přechod na další stránku
   * webu. Drží je rozšíření ve svém světě, pro každý web zvlášť; jádro k
   * úložišti nesahá. Bez rozšíření se nic neukládá a paleta jede jen v paměti.
   * Seznam může přijít znovu i později — appka ho tak rozdá kartám téhož projektu.
   */
  let restored = false;

  function save() {
    if (!restored) return;
    events.dispatchEvent(new CustomEvent("weed:draft:set", { detail: JSON.stringify({ open: state.open, list: state.list }) }));
  }

  function restore() {
    events.addEventListener("weed:draft", (e) => {
      let d = {};
      try { d = JSON.parse(e.detail) || {}; } catch (_) { d = {}; }
      const stored = Array.isArray(d.list) ? d.list : [];
      if (restored) {
        state.list = stored;
      } else {
        // co přibylo, než rozšíření odpovědělo, se neztratí
        const known = new Set(stored.map((x) => x.req && x.req.id));
        state.list = [...stored, ...state.list.filter((x) => !known.has(x.req.id))];
        restored = true;
        if (d.open && !state.open) open(false);
        save();
      }
      if (state.list.length) {
        status.dataset.kind = "";
        msg.textContent = `${state.list.length} zadání rozepsáno`;
      }
      syncButtons();
    });
    events.dispatchEvent(new CustomEvent("weed:draft:get"));
  }

  function download(name, data, type) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([data], { type: type || "application/json" }));
    a.download = name;
    shadow.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }

  /*
   * Agregáty měření (§7.3) — čísla bez obsahu a bez časové osy. Drží je povrch;
   * jádro si o ně řekne a počká, jako u záznamu běhů.
   */
  function stats() {
    return new Promise((resolve) => {
      const onStats = (e) => {
        clearTimeout(timer);
        events.removeEventListener("weed:stats", onStats);
        let s = null;
        try { s = JSON.parse(e.detail); } catch (_) { s = null; }
        resolve(s && typeof s === "object" ? s : false);
      };
      /* `false` znamená „nepodařilo se přečíst“, ne „nic tam není“: nula zadání
         a mlčící úložiště vypadají v čísle stejně, ale pro člověka je to rozdíl
         mezi „ještě jsem nezačal“ a „měření je rozbité“ (zásada 8). */
      const timer = setTimeout(() => { events.removeEventListener("weed:stats", onStats); resolve(false); }, 1000);
      events.addEventListener("weed:stats", onStats);
      events.dispatchEvent(new CustomEvent("weed:stats:get"));
    });
  }

  const num = (n) => Math.round(n).toLocaleString("cs-CZ");

  /*
   * Čísla jako text, ne jako soubor. **Export není funkce** (§7.3): kdo chce
   * vědět, jak si Web Editor vede, si to přečte a může to někam vložit; formát, který
   * by něco strojově přijímalo, by z měření udělal rozhraní a z rozhraní závazek.
   */
  function statsText(s) {
    if (s === false) return "Web Editor — měření\nměření se nepodařilo přečíst";
    if (!s || !s.runs) return "Web Editor — měření\nzatím žádné zadání";
    const per = (v) => num(v / s.runs);
    const den = s.since ? new Date(s.since).toLocaleDateString("cs-CZ") : null;
    const verdicts = Object.entries(s.verdicts || {}).sort((a, b) => b[1] - a[1])
      .map(([k, v]) => `${k} ${num(v)}`).join(" · ");
    return [
      `Web Editor — měření${den ? ` (od ${den})` : ""}`,
      `zadání: ${num(s.runs)}`,
      `průměrná délka promptu: ${per(s.chars)} znaků`,
      `průměrná velikost snímku: ${per(s.snap)} znaků`,
      `průměrně cílů na zadání: ${(s.targets / s.runs).toFixed(1).replace(".", ",")}`,
      verdicts ? `verdikty: ${verdicts}` : null,
      "",
      "Obsah stránky se nezaznamenává a nikam odsud nic neodchází.",
    ].filter((l) => l !== null).join("\n");
  }

  /** Záznamy drží rozšíření ve svém světě; jádro si o ně řekne událostí a počká na odpověď. */
  function runs() {
    return new Promise((resolve) => {
      const onRuns = (e) => {
        clearTimeout(timer);
        events.removeEventListener("weed:runs", onRuns);
        let list = [];
        try { list = JSON.parse(e.detail); } catch (_) { list = []; }
        resolve(Array.isArray(list) ? list : []);
      };
      const timer = setTimeout(() => { events.removeEventListener("weed:runs", onRuns); resolve([]); }, 1000);
      events.addEventListener("weed:runs", onRuns);
      events.dispatchEvent(new CustomEvent("weed:runs:get"));
    });
  }

  /*
   * Ořez cíle pořizuje povrch a chvíli to trvá (§7.6). Enter zadání přidá a
   * hned zkopíruje, takže se na snímek počká — jinak by měl uživatel ve
   * schránce prompt bez obrázku, který o vteřinu později v zipu je.
   *
   * Čeká se jen tam, kde se povrch přihlásil (`shots(true)`). Kdo ořezy neumí,
   * nesmí platit čekáním na něco, co nepřijde.
   */
  const SHOT_WAIT = 2500;

  function shotFor(id) {
    if (!state.shots) return Promise.resolve();
    return new Promise((resolve) => {
      const done = () => { clearTimeout(timer); events.removeEventListener("weed:shot:done", done); resolve(); };
      const timer = setTimeout(done, SHOT_WAIT);
      events.addEventListener("weed:shot:done", done);
      events.dispatchEvent(new CustomEvent("weed:shot:want", { detail: String(id) }));
    });
  }

  /*
   * Přílohy drží povrch — appka je má v Dokumentech, rozšíření si ořez pořídí
   * samo (`shot.js`). Jádro si o ně řekne a počká; když nepřijdou, je v zipu
   * prompt sám. To je pořád archiv, ne chyba.
   */
  function attachments() {
    return new Promise((resolve) => {
      const done = (list) => {
        clearTimeout(timer);
        events.removeEventListener("weed:files", onFiles);
        resolve(list);
      };
      const onFiles = (e) => {
        let list = [];
        try { list = JSON.parse(e.detail); } catch (_) { list = []; }
        done((Array.isArray(list) ? list : [])
          .filter((f) => f && f.name && typeof f.data === "string")
          .map((f) => ({ name: String(f.name), bytes: Uint8Array.from(atob(f.data), (c) => c.charCodeAt(0)) })));
      };
      const timer = setTimeout(() => done([]), 1000);
      events.addEventListener("weed:files", onFiles);
      events.dispatchEvent(new CustomEvent("weed:files:get"));
    });
  }

  /*
   * Balíček jako soubor (SPEC §7.6). Je to **vlastní akce, ne tichá náhrada
   * sdílení**: kdo chce poslat obrázek jako obrázek, musí ho poslat jako
   * obrázek. Zip je cesta k druhému agentovi, archiv a záloha, když napojení
   * selže — proto stojí vedle schránky, ne místo ní.
   */
  async function pack() {
    const prompt = renderAll();
    const fail = (reason) => { report({ verdict: "kill", reason }); return { verdict: "kill", reason }; };
    if (!prompt) return fail("Není co balit — přidej zadání.");
    const files = await attachments();
    const day = new Date().toISOString().slice(0, 10);
    const folder = `weed-${Core.project(location.hostname, location.port)}-${day}`;
    const bytes = safeZip(prompt, files, folder);
    if (!bytes) return fail("Balíček se nepodařilo složit.");
    download(`${folder}.zip`, bytes, "application/zip");
    const status = { verdict: "prompt", zip: files.length + 1, chars: prompt.length, name: `${folder}.zip` };
    report(status);
    return status;
  }

  const safeZip = (prompt, files, folder) => {
    try { return Prompt.pack(prompt, files, folder); } catch (_) { return null; }
  };

  input.addEventListener("keydown", (e) => {
    if (e.isComposing) return;
    if (e.key === "Enter") { e.preventDefault(); submit(); }
    if (e.key === "Escape") { e.preventDefault(); close(); }
  });
  aim.addEventListener("click", () => (state.picking ? stopPicking() : startPicking()));
  copyBtn.addEventListener("click", () => submit());
  runsBtn.addEventListener("click", async () => {
    const s = await stats();
    const text = statsText(s);
    const copied = await toClipboard(text);
    manualCopy.hidden = copied;
    manualCopy.value = copied ? "" : text;
    if (!copied) { manualCopy.focus(); manualCopy.select(); }
    /*
     * Ve schránce je výpis čísel, ne zadání pro agenta — délka textu tu nikomu
     * nic neřekne, počet zadání ano. A hlavně: že je měření prázdné, se musí
     * poznat z lišty. Hláška „ve schránce“ nad výpisem, ve kterém nic není,
     * pošle člověka pro odpověď tam, kde ji nenajde.
     */
    if (!copied) return report({ verdict: "kill", reason: "schránka odmítla — zkopíruj označený text ručně" });
    if (s === false) return report({ verdict: "ask", reason: "měření se nepodařilo přečíst" });
    if (!s.runs) return report({ verdict: "done", reason: "měření je prázdné — zatím žádné zadání" });
    report({ verdict: "done", reason: `měření ve schránce · ${num(s.runs)} zadání` });
  });
  packBtn.addEventListener("click", () => pack());
  clearBtn.addEventListener("click", discard);

  window.addEventListener("keydown", (e) => {
    if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.code === "KeyE") {
      e.preventDefault();
      toggle();
    }
    // ⌘Z vrací, dokud je co: druhá cesta k témuž zásobníku, kterým je tlačítko v appce.
    // Jen při míření nebo s otevřenou paletou — jinak patří ⌘Z stránce.
    if ((e.metaKey || e.ctrlKey) && !e.shiftKey && e.code === "KeyZ" && (state.picking || state.open)
        && state.undoStack.length && e.target !== input) {
      e.preventDefault();
      e.stopPropagation();
      const done = window.weed.undo();
      if (done) {
        status.dataset.kind = "";
        msg.textContent = `vráceno: ${done.label}`;
      }
    }
    // Schovaný řádek palety drží fokus — bez zastavení by týž Esc paletu hned i zavřel.
    if (e.key === "Escape" && state.picking) {
      e.preventDefault();
      e.stopPropagation();
      stopPicking();
    }
  }, true);

  // Seznam mohl přibýt v jiné kartě téhož webu.
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && restored) restore();
  });

  // --------------------------------------------------- rozhraní pro agenta

  /**
   * Stejné nástroje, jaké má agent přes MCP (SPEC §1 a §9). Rozšíření je
   * vystavuje jednou a používá je i paleta — jedno rozhraní, jedna
   * implementace.
   */
  window.weed = {
    open, close, toggle, startPicking, stopPicking,

    target(selector) {
      const elements = selector == null
        ? state.selection
        : Array.from(document.querySelectorAll(selector));
      return requestFor({ elements, doc: document, origin: "mcp" }).targets;
    },

    snapshot(selectorOrNull) {
      const els = selectorOrNull
        ? Array.from(document.querySelectorAll(selectorOrNull))
        : state.selection.length ? state.selection : [document.body];
      return els.map((el) => ({
        anchor: Core.anchorFor(el),
        html: el.outerHTML.slice(0, 4000),
        styles: pickStyles(el),
      }));
    },

    selection() {
      return state.selection.map((el) => ({
        anchor: Core.anchorFor(el),
        text: (el.textContent || "").trim().slice(0, 120),
        quotes: serializeQuotes(el).map((q) => q.text),
      }));
    },

    /*
     * Nativní výběr prohlížeče (tap-hold, dvojklik) jako úsek v cíli — pro
     * povrch, který si ho ve své nabídce nad výběrem vyzvedne. Prvek kolem textu
     * se vybere sám: bez cíle by samotný úsek neměl kam patřit.
     */
    quote() {
      const sel = window.getSelection && window.getSelection();
      if (!sel || !sel.rangeCount || sel.isCollapsed) return null;
      const range = sel.getRangeAt(0);
      const text = quoteString(range);
      const node = range.commonAncestorContainer;
      // Cíl kolem textu je tentýž smysluplný prvek jako při ukázání prstem
      // (SPEC §2.1) — jinak by táž věta měla jednou cíl odstavec a podruhé
      // obal kolem slova, podle toho, kudy se k ní uživatel dostal.
      const el = text && Core.meaningful(node.nodeType === 1 ? node : node.parentElement);
      if (!el || el === host || host.contains(el) || el === document.documentElement) return null;
      rememberQuotes("označený text");
      if (!state.selection.includes(el)) state.selection.push(el);
      setQuotes(el, mergeQuotes([...quotesOf(el), range.cloneRange()]));
      // Nativní výběr zmizí — zvýrazňuje si to Web Editor sám a dvě zvýraznění přes sebe matou.
      sel.removeAllRanges();
      changed();
      return { text, index: state.selection.indexOf(el), anchor: Core.anchorFor(el) };
    },

    /*
     * Odkaz z nabídky prohlížeče nad ním (tap-hold s náhledem stránky). Cílový
     * prvek se hledá podle adresy, kam odkaz vede: pozici ťuknutí nám WebKit
     * v nabídce nedá, adresu ano. Když takový odkaz na stránce není, nevybere
     * se nic — podobný se nehledá (zásada 8).
     */
    link(href) {
      const want = String(href || "");
      if (!want) return null;
      const hit = Array.from(document.querySelectorAll("a[href]")).find((a) => a.href === want);
      if (!hit) return null;
      rememberSelection("vybraný prvek");
      if (!state.selection.includes(hit)) state.selection.push(hit);
      changed();
      return {
        index: state.selection.indexOf(hit),
        anchor: Core.anchorFor(hit),
        text: (hit.textContent || "").trim().replace(/\s+/g, " ").slice(0, 120),
      };
    },

    /** Označený text pryč — z jednoho cíle, nebo ze všech. */
    unquote(index) {
      const el = index == null ? null : state.selection[index];
      if (index != null && !el) return false;
      rememberQuotes("odznačený text");
      if (el) state.quotes.delete(el);
      else state.quotes = new Map();
      changed();
      return true;
    },

    /*
     * Obal výběru v souřadnicích dokumentu — povrch si podle něj ořízne snímek.
     * Odsazení je už v něm (`SEL_PAD`), takže ořez je přesně ta plocha, kterou
     * uživatel viděl vysvícenou. Povrch k tomu nesmí nic přidávat.
     */
    bounds() {
      const rects = state.selection.map((el) => el.getBoundingClientRect()).filter((r) => r.width || r.height);
      if (!rects.length) return null;
      const left = Math.min(...rects.map((r) => r.left)) - SEL_PAD;
      const top = Math.min(...rects.map((r) => r.top)) - SEL_PAD;
      const right = Math.max(...rects.map((r) => r.right)) + SEL_PAD;
      const bottom = Math.max(...rects.map((r) => r.bottom)) + SEL_PAD;
      return { x: left + scrollX, y: top + scrollY, width: right - left, height: bottom - top };
    },

    /*
     * Kolik stránky zůstane kolem cíle na ořezu. Povrch si ho nesmí zvolit sám:
     * díra ve cloně a vyfocená plocha musí být jedno a totéž, jinak uživatel
     * míří na jeden výřez a dostane jiný.
     */
    pad: SEL_PAD,

    /*
     * Povrch hlásí, že ořez cíle umí. Jádro pak na snímek počká, než pustí
     * prompt do schránky; bez toho by ve schránce byl prompt bez obrázku,
     * který je o chvíli později v zipu.
     */
    shots(on) {
      state.shots = !!on;
      return state.shots;
    },

    /*
     * Adresa vzdáleného MCP, kterou povrch potvrdil po úspěšném odeslání (§2.9).
     * Jádro si ji nedomýšlí: dokud ji nikdo nepotvrdí, v balíčku není a agent
     * nedostane odkaz na seznam, do kterého nic nechodí.
     */
    mcp(url) {
      state.mcp = typeof url === "string" && /^https?:\/\//.test(url) ? url : null;
      return state.mcp;
    },

    // Pořadí selektorů je pořadí výběru — u přesunu je poslední z nich cíl.
    /*
     * Ťuknutí prstem, jen selektorem: prvek do výběru přibude, a když už v něm
     * je, odejde z něj. `select` proti tomu výběr **nahrazuje** — a to je něco
     * jiného. Náhled odkazu (SPEC §2.10) je plocha k ukazování jako stránka
     * sama: co se v něm ťukne za běhu zadání, se k větě přidává, ne ji přepisuje.
     */
    pick(...selectors) {
      const picked = [];
      for (const selector of selectors) {
        for (const el of document.querySelectorAll(selector)) if (!picked.includes(el)) picked.push(el);
      }
      if (!picked.length) return state.selection.length;
      const off = picked.filter((el) => state.selection.includes(el));
      rememberSelection(off.length === picked.length ? "odznačený prvek" : "vybraný prvek");
      state.selection = off.length === picked.length
        ? state.selection.filter((el) => !picked.includes(el))
        : [...state.selection, ...picked.filter((el) => !state.selection.includes(el))];
      renderChips();
      return state.selection.length;
    },

    select(...selectors) {
      const picked = [];
      for (const selector of selectors) {
        for (const el of document.querySelectorAll(selector)) if (!picked.includes(el)) picked.push(el);
      }
      // `select()` bez selektorů je úklid povrchu (zavřené zadání), ne akce uživatele.
      if (selectors.length) rememberSelection(picked.length < state.selection.length ? "odznačený prvek" : "vybraný prvek");
      state.selection = picked;
      renderChips();
      return state.selection.length;
    },


    // Ťuknutí na prvek v rozepsané větě: odscrolluje k němu a blikne (SPEC §2.5).
    // Nic víc — kód ani styly se neukazují.
    reveal(index) {
      const el = state.selection[index || 0];
      return el ? flash([el]) : false;
    },

    // Zadání ze seznamu na svém cíli (SPEC §2.5): kotvy se hledají v téhle stránce,
    // a když tu nejsou, vrátí se false. Nejpodobnější prvek se nehledá — to by bylo
    // hádání a ukázalo by to na špatné místo.
    show(id) {
      const item = state.list.find(({ req }) => req.id === id);
      if (!item) return false;
      return flash(item.req.targets.map((t) => Core.resolve(t.anchor, document)).filter(Boolean));
    },

    // Chytrý přesun: ťuknutí ve viewportu → kam s výběrem (§2.2, tažení prvku).
    // Vrací { verdict, options: [{ label, text, position, axis, intent }] }; stránky se nedotkne.
    placement(x, y) {
      const result = Core.placement(state.selection, x, y, document);
      state.placing = result.options;
      return result;
    },

    // Zvolená možnost: cíl přibude do výběru jako poslední (u přesunu je cíl poslední)
    // a vrátí se věta do zadání — „přesuň pod položku menu „Ceník““.
    place(index) {
      const picked = state.placing[index || 0];
      const target = picked && Core.resolve(picked.intent.to, document);
      if (!target) return null;
      state.selection = [...state.selection.filter((el) => el !== target), target];
      state.placing = [];
      renderChips();
      return picked.text;
    },

    // Zadání nad výběrem. Stránky se nedotkne a věta se nepřekládá — složí se
    // prompt a ten jde ven, jak ho uživatel řekl.
    command(prompt) {
      const req = requestFor({ text: prompt, elements: state.selection, doc: document, origin: "mcp", context: false });
      const result = Core.run(prompt, state.selection);
      return finish(req, runOf(req, result), result);
    },

    // Balíček jako soubor — vlastní akce vedle schránky (SPEC §7.6).
    pack,

    // Totéž, co jde uživateli do schránky — pro agenta přes MCP (SPEC §7.9).
    prompt(text, channel) {
      const req = requestFor({ text: text == null ? input.value : text, elements: state.selection, doc: document, origin: "mcp" });
      const run = Prompt.run({ id: req.id, verdict: "prompt" });
      // Kanál si volí příjemce, ne my (§7.6): agent přes MCP si řekne o tenký
      // tvar, CLI o data, schránka zůstává výchozí a sebenosná.
      const built = Prompt.render(req, run, { channel });
      run.chars = built.length;
      finish(req, run, { verdict: "prompt", copied: null, chars: built.length });
      return built;
    },

    request(text) {
      return requestFor({ text: text == null ? input.value : text, elements: state.selection, doc: document, origin: "mcp" });
    },

    lastPrompt() { return state.lastPrompt; },

    // Totéž co Enter v paletě, pro povrch bez palety (appka). Schránku si povrch řeší sám.
    // Bez výběru a bez textu nic nepřidá a vrátí dosavadní seznam — ke zkopírování znovu.
    // attachments: řádky kódu, které povrch označil ({ type: "code", from, text }) — v appce cesta k nim není (SPEC §2.5).
    add(text, attachments) {
      const t = String(text || "").trim();
      const marked = Array.isArray(attachments) ? attachments : [];
      if (!t && !state.selection.length && !marked.length) {
        if (!state.list.length) return null;
        const again = renderAll();
        state.lastPrompt = again;
        return { count: state.list.length, chars: again.length, reason: null, prompt: again };
      }
      const added = addToList(t, marked);
      const prompt = renderAll();
      state.lastPrompt = prompt;
      finish(added.req, added.run, { verdict: "prompt", copied: null, chars: prompt.length, count: state.list.length, reason: added.reason });
      // `id` je tu kvůli příloze: povrch ji uloží až po přidání a bez něj by
      // neměl jak říct, ke kterému zadání ořez patří.
      return { id: added.req.id, count: state.list.length, chars: prompt.length, reason: added.reason, prompt };
    },

    /*
     * Podklady (§7.6): jména příloh, které povrch drží bez vazby na zadání — vybraný
     * obrázek, screenshot. Povrch hlásí celý seznam, ne přírůstek: co v něm není,
     * z promptu zmizí, protože kotva na soubor, který nepřijde, pošle agenta
     * hledat něco, co nemá (zásada 8). Drží se jen v paměti; po návratu na stránku
     * je povrch nahlásí znovu.
     */
    papers(names) {
      state.papers = (Array.isArray(names) ? names : []).map((n) => String(n || "").trim()).filter(Boolean);
      state.lastPrompt = renderAll();
      return state.papers.length;
    },

    /*
     * Přilepit k promptu síťový přenos stránky (§7.6). Volbu drží povrch,
     * jádro jen ví, jestli vrstvu skládat. Data se berou až při skládání
     * promptu — je to snímek okamžiku, ne záznam běhu.
     */
    network(on) {
      state.network = !!on;
      state.lastPrompt = renderAll();
      return state.network;
    },

    // Jméno obrázku, který povrch k zadání přiložil (SPEC §7.6). Soubor jde ven
    // vedle promptu; tady přibude jen jeho jméno, aby ho agent uměl přiřadit.
    attach(id, name) {
      const item = state.list.find(({ req }) => req.id === id);
      const shot = String(name || "").trim();
      if (!item || !shot) return false;
      if (!Array.isArray(item.req.shots)) item.req.shots = [];
      if (!item.req.shots.includes(shot)) item.req.shots.push(shot);
      state.lastPrompt = renderAll();
      save();
      return true;
    },

    // Smazaná příloha musí zmizet i z promptu: kotva na soubor, který nepřijde,
    // pošle agenta hledat něco, co nemá (zásada 8).
    detach(name) {
      const shot = String(name || "").trim();
      if (!shot) return false;
      let changed = false;
      for (const { req } of state.list) {
        if (!Array.isArray(req.shots)) continue;
        const left = req.shots.filter((s) => s !== shot);
        if (left.length !== req.shots.length) { req.shots = left; changed = true; }
      }
      if (!changed) return false;
      state.lastPrompt = renderAll();
      save();
      return true;
    },

    discard,

    // Odebere jedno zadání ze seznamu (přejetí v appce). Vrátí, kolik jich zbylo.
    remove(id) {
      state.list = state.list.filter(({ req }) => req.id !== id);
      state.lastPrompt = renderAll();
      save();
      syncButtons();
      return state.list.length;
    },

    // Přepíše text jednoho zadání; cíle a kontext zůstanou, jak byly ukázány.
    rewrite(id, text) {
      const item = state.list.find(({ req }) => req.id === id);
      if (!item) return null;
      const before = item.req.text;
      remember("přepsané zadání", () => {
        item.req.text = before;
        state.lastPrompt = renderAll();
        save();
      });
      item.req.text = String(text || "").trim();
      state.lastPrompt = renderAll();
      save();
      return window.weed.list();
    },

    // Rozepsaný seznam pro povrch bez palety: celý prompt a co v něm je.
    list() {
      return {
        prompt: renderAll(),
        items: state.list.map(({ req }) => ({
          // Titulek k adrese: povrch stránku pojmenuje tak, jak ji zná uživatel (§6.1).
          id: req.id, text: req.text, url: req.web.url, title: req.web.title || "",
          targets: req.targets.length,
          anchors: req.targets.map((t) => t.anchor),
        })),
      };
    },

    /*
     * Vrátí poslední akci. Povrch dostane, co se vrátilo (`label` do hlášky) a text,
     * který se tím uvolnil zpátky do vstupu (u zadání), nebo null, když není co vracet.
     */
    undo() {
      const step = state.undoStack.pop();
      if (!step) return null;
      // Stav před vrácením je přesně to, co vrátí cesta vpřed.
      const before = snapshot();
      undoing = true;
      try { step.undo(); } finally { undoing = false; }
      if (step.text != null) input.value = step.text;
      state.redoStack.push({ label: step.label, state: before });
      if (state.redoStack.length > UNDO_DEPTH) state.redoStack.shift();
      changed();
      tell("weed:undo", state.undoStack.length);
      tell("weed:redo", state.redoStack.length);
      return { label: step.label, text: step.text == null ? null : step.text, left: state.undoStack.length };
    },

    /*
     * Zpátky dopředu — pro vrácení omylem. Vrací se celý otisk stavu, ne opak
     * kroku: krok svůj opak nezná.
     */
    redo() {
      const step = state.redoStack.pop();
      if (!step) return null;
      const before = snapshot();
      undoing = true;
      try { rewind(step.state); } finally { undoing = false; }
      state.undoStack.push({ label: step.label, undo: () => rewind(before), text: null });
      if (state.undoStack.length > UNDO_DEPTH) state.undoStack.shift();
      changed();
      tell("weed:undo", state.undoStack.length);
      tell("weed:redo", state.redoStack.length);
      return { label: step.label, left: state.redoStack.length };
    },

    /** Co by vrátilo `undo`, bez vracení — pro popisek tlačítka a jeho zhasnutí. */
    undoable() {
      const step = state.undoStack[state.undoStack.length - 1];
      return step ? { label: step.label, left: state.undoStack.length } : null;
    },

    /** Totéž pro cestu vpřed. */
    redoable() {
      const step = state.redoStack[state.redoStack.length - 1];
      return step ? { label: step.label, left: state.redoStack.length } : null;
    },

    runs,
    stats,

    metadata() {
      const stack = Prompt.stack(document);
      return {
        url: location.href,
        title: document.title,
        framework: stack.length ? stack[0].toLowerCase() : null,
        stack,
        elements: document.querySelectorAll("*").length,
        spa: stack.some((s) => ["Next", "React", "Nuxt", "Vue", "Angular", "Svelte"].includes(s)),
      };
    },
  };

  function pickStyles(el) {
    const cs = getComputedStyle(el);
    const out = {};
    for (const p of ["color", "background-color", "font-size", "font-weight", "display", "text-align", "padding", "border-radius"]) {
      out[p] = cs.getPropertyValue(p);
    }
    return out;
  }

  renderChips();
  restore();
})();
