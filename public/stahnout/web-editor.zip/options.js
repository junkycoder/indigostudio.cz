/* Stránka Napojení. Ukládá se hned — tlačítko *Uložit* by vyrobilo stav, ve
   kterém je na obrazovce něco jiného než v úložišti (SPEC §9). */

const el = (id) => document.getElementById(id);
const fields = { endpoint: el("endpoint"), key: el("key"), on: el("on") };

/** Načíst `connection.js` do stránky by znamenalo druhý `<script>` kvůli třem
    hodnotám. Čte se rovnou z úložiště; tvar drží jedno místo — background.
    Výchozí adresa tu není schválně, důvod je v `connection.js`. */
const read = async () => {
  const stored = (await chrome.storage.local.get("connection")).connection || {};
  return { ...stored, endpoint: stored.endpoint || "" };
};
const write = async (patch) => {
  const next = { ...(await read()), ...patch };
  await chrome.storage.local.set({ connection: next });
  return next;
};

function freshKey() {
  const bytes = crypto.getRandomValues(new Uint8Array(24));
  return btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function show(conn) {
  fields.endpoint.value = conn.endpoint || "";
  fields.key.value = conn.key || "";
  fields.on.checked = !!conn.on;

  const ready = conn.endpoint && conn.key;
  const url = ready ? `${conn.endpoint.replace(/\/+$/, "")}/s/${conn.key}/mcp` : "";
  /* Příkazy jsou hotové k vložení, ne šablony s <adresou>. Kdo si má řádek
     domýšlet, udělá v něm chybu — a to je kolo agenta navíc (zásada 6).
     Codex tu schválně není: jeho zápis neumíme doložit, a příkaz, který
     spadne, je horší než žádný (zásada 8). */
  const filled = {
    mcp: url,
    cmd: `claude mcp add --transport http weed ${url}`,
    json: `{ "mcpServers": { "weed": { "type": "http", "url": "${url}" } } }`,
  };
  for (const [id, text] of Object.entries(filled)) {
    el(id).textContent = ready ? text : "nejdřív vyplň adresu Workeru";
  }
  for (const button of document.querySelectorAll("[data-copy]")) button.disabled = !ready;

  // Stav říká, co se děje teď, ne co by šlo. Zapnuté bez adresy je slib, který
  // se nesplní — a mlčet o tom je horší než to napsat (zásada 8).
  const state = el("state");
  state.textContent = !conn.on ? "Vypnuto — ze zařízení neodchází nic."
    : ready ? "Zapnuto — zadání odcházejí do Workeru při každé změně."
    : "Zapnuto, ale chybí adresa nebo klíč — neodesílá se nic.";
  state.dataset.on = conn.on && ready ? "1" : "0";
}

// Klíč vznikne sám při prvním otevření: nechat pole prázdné by z uživatele
// udělalo generátor náhody.
const start = await read();
show(start.key ? start : await write({ key: freshKey() }));

fields.endpoint.addEventListener("input", async () => show(await write({ endpoint: fields.endpoint.value.trim() })));
/* Vypnutí je odvolání souhlasu, ne jen zastavení (§11): napřed se smaže, co
   na Workeru leží, a teprve pak se uloží přepínač — po uložení už by k tomu
   nebyla adresa ani klíč. Když Worker neodpoví, přepínač se vypne stejně a
   uživatel se dozví, že tam seznam zůstal; tvrdit opak by bylo horší. */
fields.on.addEventListener("change", async () => {
  if (fields.on.checked) return show(await write({ on: true }));
  const res = await chrome.runtime.sendMessage({ type: "weed:forget" });
  show(await write({ on: false }));
  if (res && !res.ok) {
    const state = el("state");
    state.textContent = `Vypnuto — ze zařízení už neodchází nic. Zadání na Workeru se smazat nepodařilo (${res.error}); zkusí se to znovu, až bude dostupný. Sám zmizí nejpozději za týden.`;
    state.dataset.on = "0";
  }
});

el("new").addEventListener("click", async () => {
  // Nový klíč odřízne starého agenta od seznamu — a tím je to taky odpojení.
  if (!confirm("Nový klíč odpojí agenta, který má ten starý. Adresu mu budeš muset dát znovu.")) return;
  show(await write({ key: freshKey() }));
});

// Potvrzení je v tlačítku samotném; hláška přes celou stránku by na jedno
// ťuknutí byla moc (viz Connections.swift v appce).
for (const button of document.querySelectorAll("[data-copy]")) {
  button.addEventListener("click", async () => {
    await navigator.clipboard.writeText(el(button.dataset.copy).textContent);
    button.textContent = "Zkopírováno";
    setTimeout(() => { button.textContent = "Kopírovat"; }, 3000);
  });
}
